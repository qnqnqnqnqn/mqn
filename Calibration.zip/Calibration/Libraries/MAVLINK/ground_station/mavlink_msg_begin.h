// MESSAGE begin PACKING

#define MAVLINK_MSG_ID_begin 220

typedef struct __mavlink_begin_t
{
 int32_t size; /*< code size*/
 int32_t msgid; /*< message id*/
} mavlink_begin_t;

#define MAVLINK_MSG_ID_begin_LEN 8
#define MAVLINK_MSG_ID_220_LEN 8

#define MAVLINK_MSG_ID_begin_CRC 40
#define MAVLINK_MSG_ID_220_CRC 40



#define MAVLINK_MESSAGE_INFO_begin { \
	"begin", \
	2, \
	{  { "size", NULL, MAVLINK_TYPE_INT32_T, 0, 0, offsetof(mavlink_begin_t, size) }, \
         { "msgid", NULL, MAVLINK_TYPE_INT32_T, 0, 4, offsetof(mavlink_begin_t, msgid) }, \
         } \
}


/**
 * @brief Pack a begin message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param size code size
 * @param msgid message id
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_begin_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       int32_t size, int32_t msgid)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_begin_LEN];
	_mav_put_int32_t(buf, 0, size);
	_mav_put_int32_t(buf, 4, msgid);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_begin_LEN);
#else
	mavlink_begin_t packet;
	packet.size = size;
	packet.msgid = msgid;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_begin_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_begin;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_begin_LEN, MAVLINK_MSG_ID_begin_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_begin_LEN);
#endif
}

/**
 * @brief Pack a begin message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param size code size
 * @param msgid message id
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_begin_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           int32_t size,int32_t msgid)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_begin_LEN];
	_mav_put_int32_t(buf, 0, size);
	_mav_put_int32_t(buf, 4, msgid);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_begin_LEN);
#else
	mavlink_begin_t packet;
	packet.size = size;
	packet.msgid = msgid;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_begin_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_begin;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_begin_LEN, MAVLINK_MSG_ID_begin_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_begin_LEN);
#endif
}

/**
 * @brief Encode a begin struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param begin C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_begin_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_begin_t* begin)
{
	return mavlink_msg_begin_pack(system_id, component_id, msg, begin->size, begin->msgid);
}

/**
 * @brief Encode a begin struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param begin C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_begin_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_begin_t* begin)
{
	return mavlink_msg_begin_pack_chan(system_id, component_id, chan, msg, begin->size, begin->msgid);
}

/**
 * @brief Send a begin message
 * @param chan MAVLink channel to send the message
 *
 * @param size code size
 * @param msgid message id
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_begin_send(mavlink_channel_t chan, int32_t size, int32_t msgid)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_begin_LEN];
	_mav_put_int32_t(buf, 0, size);
	_mav_put_int32_t(buf, 4, msgid);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_begin, buf, MAVLINK_MSG_ID_begin_LEN, MAVLINK_MSG_ID_begin_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_begin, buf, MAVLINK_MSG_ID_begin_LEN);
#endif
#else
	mavlink_begin_t packet;
	packet.size = size;
	packet.msgid = msgid;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_begin, (const char *)&packet, MAVLINK_MSG_ID_begin_LEN, MAVLINK_MSG_ID_begin_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_begin, (const char *)&packet, MAVLINK_MSG_ID_begin_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_begin_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_begin_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  int32_t size, int32_t msgid)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_int32_t(buf, 0, size);
	_mav_put_int32_t(buf, 4, msgid);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_begin, buf, MAVLINK_MSG_ID_begin_LEN, MAVLINK_MSG_ID_begin_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_begin, buf, MAVLINK_MSG_ID_begin_LEN);
#endif
#else
	mavlink_begin_t *packet = (mavlink_begin_t *)msgbuf;
	packet->size = size;
	packet->msgid = msgid;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_begin, (const char *)packet, MAVLINK_MSG_ID_begin_LEN, MAVLINK_MSG_ID_begin_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_begin, (const char *)packet, MAVLINK_MSG_ID_begin_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE begin UNPACKING


/**
 * @brief Get field size from begin message
 *
 * @return code size
 */
static inline int32_t mavlink_msg_begin_get_size(const mavlink_message_t* msg)
{
	return _MAV_RETURN_int32_t(msg,  0);
}

/**
 * @brief Get field msgid from begin message
 *
 * @return message id
 */
static inline int32_t mavlink_msg_begin_get_msgid(const mavlink_message_t* msg)
{
	return _MAV_RETURN_int32_t(msg,  4);
}

/**
 * @brief Decode a begin message into a struct
 *
 * @param msg The message to decode
 * @param begin C-struct to decode the message contents into
 */
static inline void mavlink_msg_begin_decode(const mavlink_message_t* msg, mavlink_begin_t* begin)
{
#if MAVLINK_NEED_BYTE_SWAP
	begin->size = mavlink_msg_begin_get_size(msg);
	begin->msgid = mavlink_msg_begin_get_msgid(msg);
#else
	memcpy(begin, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_begin_LEN);
#endif
}
