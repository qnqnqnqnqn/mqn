// MESSAGE dev1_location PACKING

#define MAVLINK_MSG_ID_dev1_location 215

typedef struct __mavlink_dev1_location_t
{
 float location_x; /*< +- location_x*/
 float location_y; /*< +- location_y*/
 float location_z; /*< +- location_z*/
} mavlink_dev1_location_t;

#define MAVLINK_MSG_ID_dev1_location_LEN 12
#define MAVLINK_MSG_ID_215_LEN 12

#define MAVLINK_MSG_ID_dev1_location_CRC 11
#define MAVLINK_MSG_ID_215_CRC 11



#define MAVLINK_MESSAGE_INFO_dev1_location { \
	"dev1_location", \
	3, \
	{  { "location_x", NULL, MAVLINK_TYPE_FLOAT, 0, 0, offsetof(mavlink_dev1_location_t, location_x) }, \
         { "location_y", NULL, MAVLINK_TYPE_FLOAT, 0, 4, offsetof(mavlink_dev1_location_t, location_y) }, \
         { "location_z", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_dev1_location_t, location_z) }, \
         } \
}


/**
 * @brief Pack a dev1_location message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param location_x +- location_x
 * @param location_y +- location_y
 * @param location_z +- location_z
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev1_location_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       float location_x, float location_y, float location_z)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_dev1_location_LEN];
	_mav_put_float(buf, 0, location_x);
	_mav_put_float(buf, 4, location_y);
	_mav_put_float(buf, 8, location_z);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev1_location_LEN);
#else
	mavlink_dev1_location_t packet;
	packet.location_x = location_x;
	packet.location_y = location_y;
	packet.location_z = location_z;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev1_location_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_dev1_location;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_dev1_location_LEN, MAVLINK_MSG_ID_dev1_location_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_dev1_location_LEN);
#endif
}

/**
 * @brief Pack a dev1_location message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param location_x +- location_x
 * @param location_y +- location_y
 * @param location_z +- location_z
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev1_location_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           float location_x,float location_y,float location_z)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_dev1_location_LEN];
	_mav_put_float(buf, 0, location_x);
	_mav_put_float(buf, 4, location_y);
	_mav_put_float(buf, 8, location_z);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev1_location_LEN);
#else
	mavlink_dev1_location_t packet;
	packet.location_x = location_x;
	packet.location_y = location_y;
	packet.location_z = location_z;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev1_location_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_dev1_location;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_dev1_location_LEN, MAVLINK_MSG_ID_dev1_location_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_dev1_location_LEN);
#endif
}

/**
 * @brief Encode a dev1_location struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param dev1_location C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev1_location_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_dev1_location_t* dev1_location)
{
	return mavlink_msg_dev1_location_pack(system_id, component_id, msg, dev1_location->location_x, dev1_location->location_y, dev1_location->location_z);
}

/**
 * @brief Encode a dev1_location struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param dev1_location C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev1_location_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_dev1_location_t* dev1_location)
{
	return mavlink_msg_dev1_location_pack_chan(system_id, component_id, chan, msg, dev1_location->location_x, dev1_location->location_y, dev1_location->location_z);
}

/**
 * @brief Send a dev1_location message
 * @param chan MAVLink channel to send the message
 *
 * @param location_x +- location_x
 * @param location_y +- location_y
 * @param location_z +- location_z
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_dev1_location_send(mavlink_channel_t chan, float location_x, float location_y, float location_z)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_dev1_location_LEN];
	_mav_put_float(buf, 0, location_x);
	_mav_put_float(buf, 4, location_y);
	_mav_put_float(buf, 8, location_z);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_location, buf, MAVLINK_MSG_ID_dev1_location_LEN, MAVLINK_MSG_ID_dev1_location_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_location, buf, MAVLINK_MSG_ID_dev1_location_LEN);
#endif
#else
	mavlink_dev1_location_t packet;
	packet.location_x = location_x;
	packet.location_y = location_y;
	packet.location_z = location_z;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_location, (const char *)&packet, MAVLINK_MSG_ID_dev1_location_LEN, MAVLINK_MSG_ID_dev1_location_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_location, (const char *)&packet, MAVLINK_MSG_ID_dev1_location_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_dev1_location_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_dev1_location_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  float location_x, float location_y, float location_z)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_float(buf, 0, location_x);
	_mav_put_float(buf, 4, location_y);
	_mav_put_float(buf, 8, location_z);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_location, buf, MAVLINK_MSG_ID_dev1_location_LEN, MAVLINK_MSG_ID_dev1_location_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_location, buf, MAVLINK_MSG_ID_dev1_location_LEN);
#endif
#else
	mavlink_dev1_location_t *packet = (mavlink_dev1_location_t *)msgbuf;
	packet->location_x = location_x;
	packet->location_y = location_y;
	packet->location_z = location_z;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_location, (const char *)packet, MAVLINK_MSG_ID_dev1_location_LEN, MAVLINK_MSG_ID_dev1_location_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_location, (const char *)packet, MAVLINK_MSG_ID_dev1_location_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE dev1_location UNPACKING


/**
 * @brief Get field location_x from dev1_location message
 *
 * @return +- location_x
 */
static inline float mavlink_msg_dev1_location_get_location_x(const mavlink_message_t* msg)
{
	return _MAV_RETURN_float(msg,  0);
}

/**
 * @brief Get field location_y from dev1_location message
 *
 * @return +- location_y
 */
static inline float mavlink_msg_dev1_location_get_location_y(const mavlink_message_t* msg)
{
	return _MAV_RETURN_float(msg,  4);
}

/**
 * @brief Get field location_z from dev1_location message
 *
 * @return +- location_z
 */
static inline float mavlink_msg_dev1_location_get_location_z(const mavlink_message_t* msg)
{
	return _MAV_RETURN_float(msg,  8);
}

/**
 * @brief Decode a dev1_location message into a struct
 *
 * @param msg The message to decode
 * @param dev1_location C-struct to decode the message contents into
 */
static inline void mavlink_msg_dev1_location_decode(const mavlink_message_t* msg, mavlink_dev1_location_t* dev1_location)
{
#if MAVLINK_NEED_BYTE_SWAP
	dev1_location->location_x = mavlink_msg_dev1_location_get_location_x(msg);
	dev1_location->location_y = mavlink_msg_dev1_location_get_location_y(msg);
	dev1_location->location_z = mavlink_msg_dev1_location_get_location_z(msg);
#else
	memcpy(dev1_location, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_dev1_location_LEN);
#endif
}
