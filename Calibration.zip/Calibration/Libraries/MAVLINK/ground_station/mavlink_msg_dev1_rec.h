// MESSAGE dev1_rec PACKING

#define MAVLINK_MSG_ID_dev1_rec 202

typedef struct __mavlink_dev1_rec_t
{
 float pitch; /*< pitch -180~180*/
 float roll; /*< roll -180~180*/
 float yaw; /*< yaw 0~360*/
 float temp; /*< temp*/
} mavlink_dev1_rec_t;

#define MAVLINK_MSG_ID_dev1_rec_LEN 16
#define MAVLINK_MSG_ID_202_LEN 16

#define MAVLINK_MSG_ID_dev1_rec_CRC 166
#define MAVLINK_MSG_ID_202_CRC 166



#define MAVLINK_MESSAGE_INFO_dev1_rec { \
	"dev1_rec", \
	4, \
	{  { "pitch", NULL, MAVLINK_TYPE_FLOAT, 0, 0, offsetof(mavlink_dev1_rec_t, pitch) }, \
         { "roll", NULL, MAVLINK_TYPE_FLOAT, 0, 4, offsetof(mavlink_dev1_rec_t, roll) }, \
         { "yaw", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_dev1_rec_t, yaw) }, \
         { "temp", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_dev1_rec_t, temp) }, \
         } \
}


/**
 * @brief Pack a dev1_rec message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param pitch pitch -180~180
 * @param roll roll -180~180
 * @param yaw yaw 0~360
 * @param temp temp
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev1_rec_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       float pitch, float roll, float yaw, float temp)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_dev1_rec_LEN];
	_mav_put_float(buf, 0, pitch);
	_mav_put_float(buf, 4, roll);
	_mav_put_float(buf, 8, yaw);
	_mav_put_float(buf, 12, temp);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev1_rec_LEN);
#else
	mavlink_dev1_rec_t packet;
	packet.pitch = pitch;
	packet.roll = roll;
	packet.yaw = yaw;
	packet.temp = temp;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev1_rec_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_dev1_rec;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_dev1_rec_LEN, MAVLINK_MSG_ID_dev1_rec_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_dev1_rec_LEN);
#endif
}

/**
 * @brief Pack a dev1_rec message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param pitch pitch -180~180
 * @param roll roll -180~180
 * @param yaw yaw 0~360
 * @param temp temp
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev1_rec_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           float pitch,float roll,float yaw,float temp)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_dev1_rec_LEN];
	_mav_put_float(buf, 0, pitch);
	_mav_put_float(buf, 4, roll);
	_mav_put_float(buf, 8, yaw);
	_mav_put_float(buf, 12, temp);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev1_rec_LEN);
#else
	mavlink_dev1_rec_t packet;
	packet.pitch = pitch;
	packet.roll = roll;
	packet.yaw = yaw;
	packet.temp = temp;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev1_rec_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_dev1_rec;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_dev1_rec_LEN, MAVLINK_MSG_ID_dev1_rec_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_dev1_rec_LEN);
#endif
}

/**
 * @brief Encode a dev1_rec struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param dev1_rec C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev1_rec_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_dev1_rec_t* dev1_rec)
{
	return mavlink_msg_dev1_rec_pack(system_id, component_id, msg, dev1_rec->pitch, dev1_rec->roll, dev1_rec->yaw, dev1_rec->temp);
}

/**
 * @brief Encode a dev1_rec struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param dev1_rec C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev1_rec_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_dev1_rec_t* dev1_rec)
{
	return mavlink_msg_dev1_rec_pack_chan(system_id, component_id, chan, msg, dev1_rec->pitch, dev1_rec->roll, dev1_rec->yaw, dev1_rec->temp);
}

/**
 * @brief Send a dev1_rec message
 * @param chan MAVLink channel to send the message
 *
 * @param pitch pitch -180~180
 * @param roll roll -180~180
 * @param yaw yaw 0~360
 * @param temp temp
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_dev1_rec_send(mavlink_channel_t chan, float pitch, float roll, float yaw, float temp)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_dev1_rec_LEN];
	_mav_put_float(buf, 0, pitch);
	_mav_put_float(buf, 4, roll);
	_mav_put_float(buf, 8, yaw);
	_mav_put_float(buf, 12, temp);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_rec, buf, MAVLINK_MSG_ID_dev1_rec_LEN, MAVLINK_MSG_ID_dev1_rec_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_rec, buf, MAVLINK_MSG_ID_dev1_rec_LEN);
#endif
#else
	mavlink_dev1_rec_t packet;
	packet.pitch = pitch;
	packet.roll = roll;
	packet.yaw = yaw;
	packet.temp = temp;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_rec, (const char *)&packet, MAVLINK_MSG_ID_dev1_rec_LEN, MAVLINK_MSG_ID_dev1_rec_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_rec, (const char *)&packet, MAVLINK_MSG_ID_dev1_rec_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_dev1_rec_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_dev1_rec_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  float pitch, float roll, float yaw, float temp)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_float(buf, 0, pitch);
	_mav_put_float(buf, 4, roll);
	_mav_put_float(buf, 8, yaw);
	_mav_put_float(buf, 12, temp);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_rec, buf, MAVLINK_MSG_ID_dev1_rec_LEN, MAVLINK_MSG_ID_dev1_rec_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_rec, buf, MAVLINK_MSG_ID_dev1_rec_LEN);
#endif
#else
	mavlink_dev1_rec_t *packet = (mavlink_dev1_rec_t *)msgbuf;
	packet->pitch = pitch;
	packet->roll = roll;
	packet->yaw = yaw;
	packet->temp = temp;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_rec, (const char *)packet, MAVLINK_MSG_ID_dev1_rec_LEN, MAVLINK_MSG_ID_dev1_rec_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_rec, (const char *)packet, MAVLINK_MSG_ID_dev1_rec_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE dev1_rec UNPACKING


/**
 * @brief Get field pitch from dev1_rec message
 *
 * @return pitch -180~180
 */
static inline float mavlink_msg_dev1_rec_get_pitch(const mavlink_message_t* msg)
{
	return _MAV_RETURN_float(msg,  0);
}

/**
 * @brief Get field roll from dev1_rec message
 *
 * @return roll -180~180
 */
static inline float mavlink_msg_dev1_rec_get_roll(const mavlink_message_t* msg)
{
	return _MAV_RETURN_float(msg,  4);
}

/**
 * @brief Get field yaw from dev1_rec message
 *
 * @return yaw 0~360
 */
static inline float mavlink_msg_dev1_rec_get_yaw(const mavlink_message_t* msg)
{
	return _MAV_RETURN_float(msg,  8);
}

/**
 * @brief Get field temp from dev1_rec message
 *
 * @return temp
 */
static inline float mavlink_msg_dev1_rec_get_temp(const mavlink_message_t* msg)
{
	return _MAV_RETURN_float(msg,  12);
}

/**
 * @brief Decode a dev1_rec message into a struct
 *
 * @param msg The message to decode
 * @param dev1_rec C-struct to decode the message contents into
 */
static inline void mavlink_msg_dev1_rec_decode(const mavlink_message_t* msg, mavlink_dev1_rec_t* dev1_rec)
{
#if MAVLINK_NEED_BYTE_SWAP
	dev1_rec->pitch = mavlink_msg_dev1_rec_get_pitch(msg);
	dev1_rec->roll = mavlink_msg_dev1_rec_get_roll(msg);
	dev1_rec->yaw = mavlink_msg_dev1_rec_get_yaw(msg);
	dev1_rec->temp = mavlink_msg_dev1_rec_get_temp(msg);
#else
	memcpy(dev1_rec, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_dev1_rec_LEN);
#endif
}
