// MESSAGE dev5 PACKING

#define MAVLINK_MSG_ID_dev5 209

typedef struct __mavlink_dev5_t
{
 uint16_t speed; /*< set speed 0~2399*/
} mavlink_dev5_t;

#define MAVLINK_MSG_ID_dev5_LEN 2
#define MAVLINK_MSG_ID_209_LEN 2

#define MAVLINK_MSG_ID_dev5_CRC 213
#define MAVLINK_MSG_ID_209_CRC 213



#define MAVLINK_MESSAGE_INFO_dev5 { \
	"dev5", \
	1, \
	{  { "speed", NULL, MAVLINK_TYPE_UINT16_T, 0, 0, offsetof(mavlink_dev5_t, speed) }, \
         } \
}


/**
 * @brief Pack a dev5 message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param speed set speed 0~2399
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev5_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint16_t speed)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_dev5_LEN];
	_mav_put_uint16_t(buf, 0, speed);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev5_LEN);
#else
	mavlink_dev5_t packet;
	packet.speed = speed;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev5_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_dev5;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_dev5_LEN, MAVLINK_MSG_ID_dev5_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_dev5_LEN);
#endif
}

/**
 * @brief Pack a dev5 message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param speed set speed 0~2399
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev5_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint16_t speed)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_dev5_LEN];
	_mav_put_uint16_t(buf, 0, speed);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev5_LEN);
#else
	mavlink_dev5_t packet;
	packet.speed = speed;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev5_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_dev5;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_dev5_LEN, MAVLINK_MSG_ID_dev5_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_dev5_LEN);
#endif
}

/**
 * @brief Encode a dev5 struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param dev5 C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev5_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_dev5_t* dev5)
{
	return mavlink_msg_dev5_pack(system_id, component_id, msg, dev5->speed);
}

/**
 * @brief Encode a dev5 struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param dev5 C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev5_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_dev5_t* dev5)
{
	return mavlink_msg_dev5_pack_chan(system_id, component_id, chan, msg, dev5->speed);
}

/**
 * @brief Send a dev5 message
 * @param chan MAVLink channel to send the message
 *
 * @param speed set speed 0~2399
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_dev5_send(mavlink_channel_t chan, uint16_t speed)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_dev5_LEN];
	_mav_put_uint16_t(buf, 0, speed);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev5, buf, MAVLINK_MSG_ID_dev5_LEN, MAVLINK_MSG_ID_dev5_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev5, buf, MAVLINK_MSG_ID_dev5_LEN);
#endif
#else
	mavlink_dev5_t packet;
	packet.speed = speed;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev5, (const char *)&packet, MAVLINK_MSG_ID_dev5_LEN, MAVLINK_MSG_ID_dev5_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev5, (const char *)&packet, MAVLINK_MSG_ID_dev5_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_dev5_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_dev5_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint16_t speed)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint16_t(buf, 0, speed);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev5, buf, MAVLINK_MSG_ID_dev5_LEN, MAVLINK_MSG_ID_dev5_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev5, buf, MAVLINK_MSG_ID_dev5_LEN);
#endif
#else
	mavlink_dev5_t *packet = (mavlink_dev5_t *)msgbuf;
	packet->speed = speed;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev5, (const char *)packet, MAVLINK_MSG_ID_dev5_LEN, MAVLINK_MSG_ID_dev5_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev5, (const char *)packet, MAVLINK_MSG_ID_dev5_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE dev5 UNPACKING


/**
 * @brief Get field speed from dev5 message
 *
 * @return set speed 0~2399
 */
static inline uint16_t mavlink_msg_dev5_get_speed(const mavlink_message_t* msg)
{
	return _MAV_RETURN_uint16_t(msg,  0);
}

/**
 * @brief Decode a dev5 message into a struct
 *
 * @param msg The message to decode
 * @param dev5 C-struct to decode the message contents into
 */
static inline void mavlink_msg_dev5_decode(const mavlink_message_t* msg, mavlink_dev5_t* dev5)
{
#if MAVLINK_NEED_BYTE_SWAP
	dev5->speed = mavlink_msg_dev5_get_speed(msg);
#else
	memcpy(dev5, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_dev5_LEN);
#endif
}
