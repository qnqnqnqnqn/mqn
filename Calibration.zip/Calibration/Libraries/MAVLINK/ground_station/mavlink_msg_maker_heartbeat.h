// MESSAGE MAKER_HEARTBEAT PACKING

#define MAVLINK_MSG_ID_MAKER_HEARTBEAT 200

typedef struct __mavlink_maker_heartbeat_t
{
 float voltage; /*< voltage*/
 uint16_t version; /*< version*/
 uint8_t devId; /*< devId*/
 uint8_t enable; /*< ENABLE_STAT*/
 uint8_t state; /*< b:0 ultrasonic   b:1 RGB  b:2  buzzer  b:3 infrared   b:4  photosensitive b:5  LED   b:6    b:7  */
} mavlink_maker_heartbeat_t;

#define MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN 9
#define MAVLINK_MSG_ID_200_LEN 9

#define MAVLINK_MSG_ID_MAKER_HEARTBEAT_CRC 111
#define MAVLINK_MSG_ID_200_CRC 111



#define MAVLINK_MESSAGE_INFO_MAKER_HEARTBEAT { \
	"MAKER_HEARTBEAT", \
	5, \
	{  { "voltage", NULL, MAVLINK_TYPE_FLOAT, 0, 0, offsetof(mavlink_maker_heartbeat_t, voltage) }, \
         { "version", NULL, MAVLINK_TYPE_UINT16_T, 0, 4, offsetof(mavlink_maker_heartbeat_t, version) }, \
         { "devId", NULL, MAVLINK_TYPE_UINT8_T, 0, 6, offsetof(mavlink_maker_heartbeat_t, devId) }, \
         { "enable", NULL, MAVLINK_TYPE_UINT8_T, 0, 7, offsetof(mavlink_maker_heartbeat_t, enable) }, \
         { "state", NULL, MAVLINK_TYPE_UINT8_T, 0, 8, offsetof(mavlink_maker_heartbeat_t, state) }, \
         } \
}


/**
 * @brief Pack a maker_heartbeat message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param devId devId
 * @param enable ENABLE_STAT
 * @param version version
 * @param state b:0 ultrasonic   b:1 RGB  b:2  buzzer  b:3 infrared   b:4  photosensitive b:5  LED   b:6    b:7  
 * @param voltage voltage
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_maker_heartbeat_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint8_t devId, uint8_t enable, uint16_t version, uint8_t state, float voltage)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN];
	_mav_put_float(buf, 0, voltage);
	_mav_put_uint16_t(buf, 4, version);
	_mav_put_uint8_t(buf, 6, devId);
	_mav_put_uint8_t(buf, 7, enable);
	_mav_put_uint8_t(buf, 8, state);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN);
#else
	mavlink_maker_heartbeat_t packet;
	packet.voltage = voltage;
	packet.version = version;
	packet.devId = devId;
	packet.enable = enable;
	packet.state = state;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_MAKER_HEARTBEAT;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN, MAVLINK_MSG_ID_MAKER_HEARTBEAT_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN);
#endif
}

/**
 * @brief Pack a maker_heartbeat message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param devId devId
 * @param enable ENABLE_STAT
 * @param version version
 * @param state b:0 ultrasonic   b:1 RGB  b:2  buzzer  b:3 infrared   b:4  photosensitive b:5  LED   b:6    b:7  
 * @param voltage voltage
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_maker_heartbeat_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint8_t devId,uint8_t enable,uint16_t version,uint8_t state,float voltage)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN];
	_mav_put_float(buf, 0, voltage);
	_mav_put_uint16_t(buf, 4, version);
	_mav_put_uint8_t(buf, 6, devId);
	_mav_put_uint8_t(buf, 7, enable);
	_mav_put_uint8_t(buf, 8, state);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN);
#else
	mavlink_maker_heartbeat_t packet;
	packet.voltage = voltage;
	packet.version = version;
	packet.devId = devId;
	packet.enable = enable;
	packet.state = state;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_MAKER_HEARTBEAT;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN, MAVLINK_MSG_ID_MAKER_HEARTBEAT_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN);
#endif
}

/**
 * @brief Encode a maker_heartbeat struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param maker_heartbeat C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_maker_heartbeat_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_maker_heartbeat_t* maker_heartbeat)
{
	return mavlink_msg_maker_heartbeat_pack(system_id, component_id, msg, maker_heartbeat->devId, maker_heartbeat->enable, maker_heartbeat->version, maker_heartbeat->state, maker_heartbeat->voltage);
}

/**
 * @brief Encode a maker_heartbeat struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param maker_heartbeat C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_maker_heartbeat_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_maker_heartbeat_t* maker_heartbeat)
{
	return mavlink_msg_maker_heartbeat_pack_chan(system_id, component_id, chan, msg, maker_heartbeat->devId, maker_heartbeat->enable, maker_heartbeat->version, maker_heartbeat->state, maker_heartbeat->voltage);
}

/**
 * @brief Send a maker_heartbeat message
 * @param chan MAVLink channel to send the message
 *
 * @param devId devId
 * @param enable ENABLE_STAT
 * @param version version
 * @param state b:0 ultrasonic   b:1 RGB  b:2  buzzer  b:3 infrared   b:4  photosensitive b:5  LED   b:6    b:7  
 * @param voltage voltage
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_maker_heartbeat_send(mavlink_channel_t chan, uint8_t devId, uint8_t enable, uint16_t version, uint8_t state, float voltage)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN];
	_mav_put_float(buf, 0, voltage);
	_mav_put_uint16_t(buf, 4, version);
	_mav_put_uint8_t(buf, 6, devId);
	_mav_put_uint8_t(buf, 7, enable);
	_mav_put_uint8_t(buf, 8, state);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_MAKER_HEARTBEAT, buf, MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN, MAVLINK_MSG_ID_MAKER_HEARTBEAT_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_MAKER_HEARTBEAT, buf, MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN);
#endif
#else
	mavlink_maker_heartbeat_t packet;
	packet.voltage = voltage;
	packet.version = version;
	packet.devId = devId;
	packet.enable = enable;
	packet.state = state;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_MAKER_HEARTBEAT, (const char *)&packet, MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN, MAVLINK_MSG_ID_MAKER_HEARTBEAT_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_MAKER_HEARTBEAT, (const char *)&packet, MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_maker_heartbeat_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t devId, uint8_t enable, uint16_t version, uint8_t state, float voltage)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_float(buf, 0, voltage);
	_mav_put_uint16_t(buf, 4, version);
	_mav_put_uint8_t(buf, 6, devId);
	_mav_put_uint8_t(buf, 7, enable);
	_mav_put_uint8_t(buf, 8, state);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_MAKER_HEARTBEAT, buf, MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN, MAVLINK_MSG_ID_MAKER_HEARTBEAT_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_MAKER_HEARTBEAT, buf, MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN);
#endif
#else
	mavlink_maker_heartbeat_t *packet = (mavlink_maker_heartbeat_t *)msgbuf;
	packet->voltage = voltage;
	packet->version = version;
	packet->devId = devId;
	packet->enable = enable;
	packet->state = state;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_MAKER_HEARTBEAT, (const char *)packet, MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN, MAVLINK_MSG_ID_MAKER_HEARTBEAT_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_MAKER_HEARTBEAT, (const char *)packet, MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE MAKER_HEARTBEAT UNPACKING


/**
 * @brief Get field devId from maker_heartbeat message
 *
 * @return devId
 */
static inline uint8_t mavlink_msg_maker_heartbeat_get_devId(const mavlink_message_t* msg)
{
	return _MAV_RETURN_uint8_t(msg,  6);
}

/**
 * @brief Get field enable from maker_heartbeat message
 *
 * @return ENABLE_STAT
 */
static inline uint8_t mavlink_msg_maker_heartbeat_get_enable(const mavlink_message_t* msg)
{
	return _MAV_RETURN_uint8_t(msg,  7);
}

/**
 * @brief Get field version from maker_heartbeat message
 *
 * @return version
 */
static inline uint16_t mavlink_msg_maker_heartbeat_get_version(const mavlink_message_t* msg)
{
	return _MAV_RETURN_uint16_t(msg,  4);
}

/**
 * @brief Get field state from maker_heartbeat message
 *
 * @return b:0 ultrasonic   b:1 RGB  b:2  buzzer  b:3 infrared   b:4  photosensitive b:5  LED   b:6    b:7  
 */
static inline uint8_t mavlink_msg_maker_heartbeat_get_state(const mavlink_message_t* msg)
{
	return _MAV_RETURN_uint8_t(msg,  8);
}

/**
 * @brief Get field voltage from maker_heartbeat message
 *
 * @return voltage
 */
static inline float mavlink_msg_maker_heartbeat_get_voltage(const mavlink_message_t* msg)
{
	return _MAV_RETURN_float(msg,  0);
}

/**
 * @brief Decode a maker_heartbeat message into a struct
 *
 * @param msg The message to decode
 * @param maker_heartbeat C-struct to decode the message contents into
 */
static inline void mavlink_msg_maker_heartbeat_decode(const mavlink_message_t* msg, mavlink_maker_heartbeat_t* maker_heartbeat)
{
#if MAVLINK_NEED_BYTE_SWAP
	maker_heartbeat->voltage = mavlink_msg_maker_heartbeat_get_voltage(msg);
	maker_heartbeat->version = mavlink_msg_maker_heartbeat_get_version(msg);
	maker_heartbeat->devId = mavlink_msg_maker_heartbeat_get_devId(msg);
	maker_heartbeat->enable = mavlink_msg_maker_heartbeat_get_enable(msg);
	maker_heartbeat->state = mavlink_msg_maker_heartbeat_get_state(msg);
#else
	memcpy(maker_heartbeat, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_MAKER_HEARTBEAT_LEN);
#endif
}
