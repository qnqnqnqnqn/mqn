#pragma once
// MESSAGE attitude_calibration_rec PACKING

#define MAVLINK_MSG_ID_attitude_calibration_rec 192

MAVPACKED(
typedef struct __mavlink_attitude_calibration_rec_t {
 float acc_x; /*< acc_x*/
 float acc_y; /*< acc_y*/
 float acc_z; /*< acc_z*/
 float gyro_x; /*< gyro_x*/
 float gyro_y; /*< gyro_y*/
 float gyro_z; /*< gyro_z*/
 uint8_t calculation_complete; /*< calculation complete*/
 uint8_t calculation_in; /*< calculation in*/
 uint8_t calculation_cnt; /*< calculation_cnt*/
 uint8_t calculation; /*< calculation*/
}) mavlink_attitude_calibration_rec_t;

#define MAVLINK_MSG_ID_attitude_calibration_rec_LEN 28
#define MAVLINK_MSG_ID_attitude_calibration_rec_MIN_LEN 28
#define MAVLINK_MSG_ID_192_LEN 28
#define MAVLINK_MSG_ID_192_MIN_LEN 28

#define MAVLINK_MSG_ID_attitude_calibration_rec_CRC 227
#define MAVLINK_MSG_ID_192_CRC 227



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_attitude_calibration_rec { \
    192, \
    "attitude_calibration_rec", \
    10, \
    {  { "calculation_complete", NULL, MAVLINK_TYPE_UINT8_T, 0, 24, offsetof(mavlink_attitude_calibration_rec_t, calculation_complete) }, \
         { "calculation_in", NULL, MAVLINK_TYPE_UINT8_T, 0, 25, offsetof(mavlink_attitude_calibration_rec_t, calculation_in) }, \
         { "calculation_cnt", NULL, MAVLINK_TYPE_UINT8_T, 0, 26, offsetof(mavlink_attitude_calibration_rec_t, calculation_cnt) }, \
         { "calculation", NULL, MAVLINK_TYPE_UINT8_T, 0, 27, offsetof(mavlink_attitude_calibration_rec_t, calculation) }, \
         { "acc_x", NULL, MAVLINK_TYPE_FLOAT, 0, 0, offsetof(mavlink_attitude_calibration_rec_t, acc_x) }, \
         { "acc_y", NULL, MAVLINK_TYPE_FLOAT, 0, 4, offsetof(mavlink_attitude_calibration_rec_t, acc_y) }, \
         { "acc_z", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_attitude_calibration_rec_t, acc_z) }, \
         { "gyro_x", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_attitude_calibration_rec_t, gyro_x) }, \
         { "gyro_y", NULL, MAVLINK_TYPE_FLOAT, 0, 16, offsetof(mavlink_attitude_calibration_rec_t, gyro_y) }, \
         { "gyro_z", NULL, MAVLINK_TYPE_FLOAT, 0, 20, offsetof(mavlink_attitude_calibration_rec_t, gyro_z) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_attitude_calibration_rec { \
    "attitude_calibration_rec", \
    10, \
    {  { "calculation_complete", NULL, MAVLINK_TYPE_UINT8_T, 0, 24, offsetof(mavlink_attitude_calibration_rec_t, calculation_complete) }, \
         { "calculation_in", NULL, MAVLINK_TYPE_UINT8_T, 0, 25, offsetof(mavlink_attitude_calibration_rec_t, calculation_in) }, \
         { "calculation_cnt", NULL, MAVLINK_TYPE_UINT8_T, 0, 26, offsetof(mavlink_attitude_calibration_rec_t, calculation_cnt) }, \
         { "calculation", NULL, MAVLINK_TYPE_UINT8_T, 0, 27, offsetof(mavlink_attitude_calibration_rec_t, calculation) }, \
         { "acc_x", NULL, MAVLINK_TYPE_FLOAT, 0, 0, offsetof(mavlink_attitude_calibration_rec_t, acc_x) }, \
         { "acc_y", NULL, MAVLINK_TYPE_FLOAT, 0, 4, offsetof(mavlink_attitude_calibration_rec_t, acc_y) }, \
         { "acc_z", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_attitude_calibration_rec_t, acc_z) }, \
         { "gyro_x", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_attitude_calibration_rec_t, gyro_x) }, \
         { "gyro_y", NULL, MAVLINK_TYPE_FLOAT, 0, 16, offsetof(mavlink_attitude_calibration_rec_t, gyro_y) }, \
         { "gyro_z", NULL, MAVLINK_TYPE_FLOAT, 0, 20, offsetof(mavlink_attitude_calibration_rec_t, gyro_z) }, \
         } \
}
#endif

/**
 * @brief Pack a attitude_calibration_rec message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param calculation_complete calculation complete
 * @param calculation_in calculation in
 * @param calculation_cnt calculation_cnt
 * @param calculation calculation
 * @param acc_x acc_x
 * @param acc_y acc_y
 * @param acc_z acc_z
 * @param gyro_x gyro_x
 * @param gyro_y gyro_y
 * @param gyro_z gyro_z
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_attitude_calibration_rec_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t calculation_complete, uint8_t calculation_in, uint8_t calculation_cnt, uint8_t calculation, float acc_x, float acc_y, float acc_z, float gyro_x, float gyro_y, float gyro_z)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_attitude_calibration_rec_LEN];
    _mav_put_float(buf, 0, acc_x);
    _mav_put_float(buf, 4, acc_y);
    _mav_put_float(buf, 8, acc_z);
    _mav_put_float(buf, 12, gyro_x);
    _mav_put_float(buf, 16, gyro_y);
    _mav_put_float(buf, 20, gyro_z);
    _mav_put_uint8_t(buf, 24, calculation_complete);
    _mav_put_uint8_t(buf, 25, calculation_in);
    _mav_put_uint8_t(buf, 26, calculation_cnt);
    _mav_put_uint8_t(buf, 27, calculation);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_attitude_calibration_rec_LEN);
#else
    mavlink_attitude_calibration_rec_t packet;
    packet.acc_x = acc_x;
    packet.acc_y = acc_y;
    packet.acc_z = acc_z;
    packet.gyro_x = gyro_x;
    packet.gyro_y = gyro_y;
    packet.gyro_z = gyro_z;
    packet.calculation_complete = calculation_complete;
    packet.calculation_in = calculation_in;
    packet.calculation_cnt = calculation_cnt;
    packet.calculation = calculation;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_attitude_calibration_rec_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_attitude_calibration_rec;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_attitude_calibration_rec_MIN_LEN, MAVLINK_MSG_ID_attitude_calibration_rec_LEN, MAVLINK_MSG_ID_attitude_calibration_rec_CRC);
}

/**
 * @brief Pack a attitude_calibration_rec message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param calculation_complete calculation complete
 * @param calculation_in calculation in
 * @param calculation_cnt calculation_cnt
 * @param calculation calculation
 * @param acc_x acc_x
 * @param acc_y acc_y
 * @param acc_z acc_z
 * @param gyro_x gyro_x
 * @param gyro_y gyro_y
 * @param gyro_z gyro_z
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_attitude_calibration_rec_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t calculation_complete,uint8_t calculation_in,uint8_t calculation_cnt,uint8_t calculation,float acc_x,float acc_y,float acc_z,float gyro_x,float gyro_y,float gyro_z)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_attitude_calibration_rec_LEN];
    _mav_put_float(buf, 0, acc_x);
    _mav_put_float(buf, 4, acc_y);
    _mav_put_float(buf, 8, acc_z);
    _mav_put_float(buf, 12, gyro_x);
    _mav_put_float(buf, 16, gyro_y);
    _mav_put_float(buf, 20, gyro_z);
    _mav_put_uint8_t(buf, 24, calculation_complete);
    _mav_put_uint8_t(buf, 25, calculation_in);
    _mav_put_uint8_t(buf, 26, calculation_cnt);
    _mav_put_uint8_t(buf, 27, calculation);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_attitude_calibration_rec_LEN);
#else
    mavlink_attitude_calibration_rec_t packet;
    packet.acc_x = acc_x;
    packet.acc_y = acc_y;
    packet.acc_z = acc_z;
    packet.gyro_x = gyro_x;
    packet.gyro_y = gyro_y;
    packet.gyro_z = gyro_z;
    packet.calculation_complete = calculation_complete;
    packet.calculation_in = calculation_in;
    packet.calculation_cnt = calculation_cnt;
    packet.calculation = calculation;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_attitude_calibration_rec_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_attitude_calibration_rec;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_attitude_calibration_rec_MIN_LEN, MAVLINK_MSG_ID_attitude_calibration_rec_LEN, MAVLINK_MSG_ID_attitude_calibration_rec_CRC);
}

/**
 * @brief Encode a attitude_calibration_rec struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param attitude_calibration_rec C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_attitude_calibration_rec_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_attitude_calibration_rec_t* attitude_calibration_rec)
{
    return mavlink_msg_attitude_calibration_rec_pack(system_id, component_id, msg, attitude_calibration_rec->calculation_complete, attitude_calibration_rec->calculation_in, attitude_calibration_rec->calculation_cnt, attitude_calibration_rec->calculation, attitude_calibration_rec->acc_x, attitude_calibration_rec->acc_y, attitude_calibration_rec->acc_z, attitude_calibration_rec->gyro_x, attitude_calibration_rec->gyro_y, attitude_calibration_rec->gyro_z);
}

/**
 * @brief Encode a attitude_calibration_rec struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param attitude_calibration_rec C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_attitude_calibration_rec_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_attitude_calibration_rec_t* attitude_calibration_rec)
{
    return mavlink_msg_attitude_calibration_rec_pack_chan(system_id, component_id, chan, msg, attitude_calibration_rec->calculation_complete, attitude_calibration_rec->calculation_in, attitude_calibration_rec->calculation_cnt, attitude_calibration_rec->calculation, attitude_calibration_rec->acc_x, attitude_calibration_rec->acc_y, attitude_calibration_rec->acc_z, attitude_calibration_rec->gyro_x, attitude_calibration_rec->gyro_y, attitude_calibration_rec->gyro_z);
}

/**
 * @brief Send a attitude_calibration_rec message
 * @param chan MAVLink channel to send the message
 *
 * @param calculation_complete calculation complete
 * @param calculation_in calculation in
 * @param calculation_cnt calculation_cnt
 * @param calculation calculation
 * @param acc_x acc_x
 * @param acc_y acc_y
 * @param acc_z acc_z
 * @param gyro_x gyro_x
 * @param gyro_y gyro_y
 * @param gyro_z gyro_z
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_attitude_calibration_rec_send(mavlink_channel_t chan, uint8_t calculation_complete, uint8_t calculation_in, uint8_t calculation_cnt, uint8_t calculation, float acc_x, float acc_y, float acc_z, float gyro_x, float gyro_y, float gyro_z)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_attitude_calibration_rec_LEN];
    _mav_put_float(buf, 0, acc_x);
    _mav_put_float(buf, 4, acc_y);
    _mav_put_float(buf, 8, acc_z);
    _mav_put_float(buf, 12, gyro_x);
    _mav_put_float(buf, 16, gyro_y);
    _mav_put_float(buf, 20, gyro_z);
    _mav_put_uint8_t(buf, 24, calculation_complete);
    _mav_put_uint8_t(buf, 25, calculation_in);
    _mav_put_uint8_t(buf, 26, calculation_cnt);
    _mav_put_uint8_t(buf, 27, calculation);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_attitude_calibration_rec, buf, MAVLINK_MSG_ID_attitude_calibration_rec_MIN_LEN, MAVLINK_MSG_ID_attitude_calibration_rec_LEN, MAVLINK_MSG_ID_attitude_calibration_rec_CRC);
#else
    mavlink_attitude_calibration_rec_t packet;
    packet.acc_x = acc_x;
    packet.acc_y = acc_y;
    packet.acc_z = acc_z;
    packet.gyro_x = gyro_x;
    packet.gyro_y = gyro_y;
    packet.gyro_z = gyro_z;
    packet.calculation_complete = calculation_complete;
    packet.calculation_in = calculation_in;
    packet.calculation_cnt = calculation_cnt;
    packet.calculation = calculation;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_attitude_calibration_rec, (const char *)&packet, MAVLINK_MSG_ID_attitude_calibration_rec_MIN_LEN, MAVLINK_MSG_ID_attitude_calibration_rec_LEN, MAVLINK_MSG_ID_attitude_calibration_rec_CRC);
#endif
}

/**
 * @brief Send a attitude_calibration_rec message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_attitude_calibration_rec_send_struct(mavlink_channel_t chan, const mavlink_attitude_calibration_rec_t* attitude_calibration_rec)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_attitude_calibration_rec_send(chan, attitude_calibration_rec->calculation_complete, attitude_calibration_rec->calculation_in, attitude_calibration_rec->calculation_cnt, attitude_calibration_rec->calculation, attitude_calibration_rec->acc_x, attitude_calibration_rec->acc_y, attitude_calibration_rec->acc_z, attitude_calibration_rec->gyro_x, attitude_calibration_rec->gyro_y, attitude_calibration_rec->gyro_z);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_attitude_calibration_rec, (const char *)attitude_calibration_rec, MAVLINK_MSG_ID_attitude_calibration_rec_MIN_LEN, MAVLINK_MSG_ID_attitude_calibration_rec_LEN, MAVLINK_MSG_ID_attitude_calibration_rec_CRC);
#endif
}

#if MAVLINK_MSG_ID_attitude_calibration_rec_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_attitude_calibration_rec_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t calculation_complete, uint8_t calculation_in, uint8_t calculation_cnt, uint8_t calculation, float acc_x, float acc_y, float acc_z, float gyro_x, float gyro_y, float gyro_z)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_float(buf, 0, acc_x);
    _mav_put_float(buf, 4, acc_y);
    _mav_put_float(buf, 8, acc_z);
    _mav_put_float(buf, 12, gyro_x);
    _mav_put_float(buf, 16, gyro_y);
    _mav_put_float(buf, 20, gyro_z);
    _mav_put_uint8_t(buf, 24, calculation_complete);
    _mav_put_uint8_t(buf, 25, calculation_in);
    _mav_put_uint8_t(buf, 26, calculation_cnt);
    _mav_put_uint8_t(buf, 27, calculation);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_attitude_calibration_rec, buf, MAVLINK_MSG_ID_attitude_calibration_rec_MIN_LEN, MAVLINK_MSG_ID_attitude_calibration_rec_LEN, MAVLINK_MSG_ID_attitude_calibration_rec_CRC);
#else
    mavlink_attitude_calibration_rec_t *packet = (mavlink_attitude_calibration_rec_t *)msgbuf;
    packet->acc_x = acc_x;
    packet->acc_y = acc_y;
    packet->acc_z = acc_z;
    packet->gyro_x = gyro_x;
    packet->gyro_y = gyro_y;
    packet->gyro_z = gyro_z;
    packet->calculation_complete = calculation_complete;
    packet->calculation_in = calculation_in;
    packet->calculation_cnt = calculation_cnt;
    packet->calculation = calculation;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_attitude_calibration_rec, (const char *)packet, MAVLINK_MSG_ID_attitude_calibration_rec_MIN_LEN, MAVLINK_MSG_ID_attitude_calibration_rec_LEN, MAVLINK_MSG_ID_attitude_calibration_rec_CRC);
#endif
}
#endif

#endif

// MESSAGE attitude_calibration_rec UNPACKING


/**
 * @brief Get field calculation_complete from attitude_calibration_rec message
 *
 * @return calculation complete
 */
static inline uint8_t mavlink_msg_attitude_calibration_rec_get_calculation_complete(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  24);
}

/**
 * @brief Get field calculation_in from attitude_calibration_rec message
 *
 * @return calculation in
 */
static inline uint8_t mavlink_msg_attitude_calibration_rec_get_calculation_in(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  25);
}

/**
 * @brief Get field calculation_cnt from attitude_calibration_rec message
 *
 * @return calculation_cnt
 */
static inline uint8_t mavlink_msg_attitude_calibration_rec_get_calculation_cnt(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  26);
}

/**
 * @brief Get field calculation from attitude_calibration_rec message
 *
 * @return calculation
 */
static inline uint8_t mavlink_msg_attitude_calibration_rec_get_calculation(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  27);
}

/**
 * @brief Get field acc_x from attitude_calibration_rec message
 *
 * @return acc_x
 */
static inline float mavlink_msg_attitude_calibration_rec_get_acc_x(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  0);
}

/**
 * @brief Get field acc_y from attitude_calibration_rec message
 *
 * @return acc_y
 */
static inline float mavlink_msg_attitude_calibration_rec_get_acc_y(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  4);
}

/**
 * @brief Get field acc_z from attitude_calibration_rec message
 *
 * @return acc_z
 */
static inline float mavlink_msg_attitude_calibration_rec_get_acc_z(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  8);
}

/**
 * @brief Get field gyro_x from attitude_calibration_rec message
 *
 * @return gyro_x
 */
static inline float mavlink_msg_attitude_calibration_rec_get_gyro_x(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  12);
}

/**
 * @brief Get field gyro_y from attitude_calibration_rec message
 *
 * @return gyro_y
 */
static inline float mavlink_msg_attitude_calibration_rec_get_gyro_y(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  16);
}

/**
 * @brief Get field gyro_z from attitude_calibration_rec message
 *
 * @return gyro_z
 */
static inline float mavlink_msg_attitude_calibration_rec_get_gyro_z(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  20);
}

/**
 * @brief Decode a attitude_calibration_rec message into a struct
 *
 * @param msg The message to decode
 * @param attitude_calibration_rec C-struct to decode the message contents into
 */
static inline void mavlink_msg_attitude_calibration_rec_decode(const mavlink_message_t* msg, mavlink_attitude_calibration_rec_t* attitude_calibration_rec)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    attitude_calibration_rec->acc_x = mavlink_msg_attitude_calibration_rec_get_acc_x(msg);
    attitude_calibration_rec->acc_y = mavlink_msg_attitude_calibration_rec_get_acc_y(msg);
    attitude_calibration_rec->acc_z = mavlink_msg_attitude_calibration_rec_get_acc_z(msg);
    attitude_calibration_rec->gyro_x = mavlink_msg_attitude_calibration_rec_get_gyro_x(msg);
    attitude_calibration_rec->gyro_y = mavlink_msg_attitude_calibration_rec_get_gyro_y(msg);
    attitude_calibration_rec->gyro_z = mavlink_msg_attitude_calibration_rec_get_gyro_z(msg);
    attitude_calibration_rec->calculation_complete = mavlink_msg_attitude_calibration_rec_get_calculation_complete(msg);
    attitude_calibration_rec->calculation_in = mavlink_msg_attitude_calibration_rec_get_calculation_in(msg);
    attitude_calibration_rec->calculation_cnt = mavlink_msg_attitude_calibration_rec_get_calculation_cnt(msg);
    attitude_calibration_rec->calculation = mavlink_msg_attitude_calibration_rec_get_calculation(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_attitude_calibration_rec_LEN? msg->len : MAVLINK_MSG_ID_attitude_calibration_rec_LEN;
        memset(attitude_calibration_rec, 0, MAVLINK_MSG_ID_attitude_calibration_rec_LEN);
    memcpy(attitude_calibration_rec, _MAV_PAYLOAD(msg), len);
#endif
}
