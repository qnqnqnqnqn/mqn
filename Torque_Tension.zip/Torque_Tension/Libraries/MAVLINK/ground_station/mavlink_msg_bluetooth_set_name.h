#pragma once
// MESSAGE BLUETOOTH_SET_NAME PACKING

#define MAVLINK_MSG_ID_BLUETOOTH_SET_NAME 219

MAVPACKED(
typedef struct __mavlink_bluetooth_set_name_t {
 int8_t BT_name[12]; /*< BT_name*/
}) mavlink_bluetooth_set_name_t;

#define MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_LEN 12
#define MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_MIN_LEN 12
#define MAVLINK_MSG_ID_219_LEN 12
#define MAVLINK_MSG_ID_219_MIN_LEN 12

#define MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_CRC 77
#define MAVLINK_MSG_ID_219_CRC 77

#define MAVLINK_MSG_BLUETOOTH_SET_NAME_FIELD_BT_NAME_LEN 12

#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_BLUETOOTH_SET_NAME { \
    219, \
    "BLUETOOTH_SET_NAME", \
    1, \
    {  { "BT_name", NULL, MAVLINK_TYPE_INT8_T, 12, 0, offsetof(mavlink_bluetooth_set_name_t, BT_name) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_BLUETOOTH_SET_NAME { \
    "BLUETOOTH_SET_NAME", \
    1, \
    {  { "BT_name", NULL, MAVLINK_TYPE_INT8_T, 12, 0, offsetof(mavlink_bluetooth_set_name_t, BT_name) }, \
         } \
}
#endif

/**
 * @brief Pack a bluetooth_set_name message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param BT_name BT_name
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_bluetooth_set_name_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               const int8_t *BT_name)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_LEN];

    _mav_put_int8_t_array(buf, 0, BT_name, 12);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_LEN);
#else
    mavlink_bluetooth_set_name_t packet;

    mav_array_memcpy(packet.BT_name, BT_name, sizeof(int8_t)*12);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_BLUETOOTH_SET_NAME;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_MIN_LEN, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_LEN, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_CRC);
}

/**
 * @brief Pack a bluetooth_set_name message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param BT_name BT_name
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_bluetooth_set_name_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   const int8_t *BT_name)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_LEN];

    _mav_put_int8_t_array(buf, 0, BT_name, 12);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_LEN);
#else
    mavlink_bluetooth_set_name_t packet;

    mav_array_memcpy(packet.BT_name, BT_name, sizeof(int8_t)*12);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_BLUETOOTH_SET_NAME;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_MIN_LEN, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_LEN, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_CRC);
}

/**
 * @brief Encode a bluetooth_set_name struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param bluetooth_set_name C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_bluetooth_set_name_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_bluetooth_set_name_t* bluetooth_set_name)
{
    return mavlink_msg_bluetooth_set_name_pack(system_id, component_id, msg, bluetooth_set_name->BT_name);
}

/**
 * @brief Encode a bluetooth_set_name struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param bluetooth_set_name C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_bluetooth_set_name_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_bluetooth_set_name_t* bluetooth_set_name)
{
    return mavlink_msg_bluetooth_set_name_pack_chan(system_id, component_id, chan, msg, bluetooth_set_name->BT_name);
}

/**
 * @brief Send a bluetooth_set_name message
 * @param chan MAVLink channel to send the message
 *
 * @param BT_name BT_name
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_bluetooth_set_name_send(mavlink_channel_t chan, const int8_t *BT_name)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_LEN];

    _mav_put_int8_t_array(buf, 0, BT_name, 12);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME, buf, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_MIN_LEN, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_LEN, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_CRC);
#else
    mavlink_bluetooth_set_name_t packet;

    mav_array_memcpy(packet.BT_name, BT_name, sizeof(int8_t)*12);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME, (const char *)&packet, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_MIN_LEN, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_LEN, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_CRC);
#endif
}

/**
 * @brief Send a bluetooth_set_name message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_bluetooth_set_name_send_struct(mavlink_channel_t chan, const mavlink_bluetooth_set_name_t* bluetooth_set_name)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_bluetooth_set_name_send(chan, bluetooth_set_name->BT_name);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME, (const char *)bluetooth_set_name, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_MIN_LEN, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_LEN, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_CRC);
#endif
}

#if MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_bluetooth_set_name_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  const int8_t *BT_name)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;

    _mav_put_int8_t_array(buf, 0, BT_name, 12);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME, buf, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_MIN_LEN, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_LEN, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_CRC);
#else
    mavlink_bluetooth_set_name_t *packet = (mavlink_bluetooth_set_name_t *)msgbuf;

    mav_array_memcpy(packet->BT_name, BT_name, sizeof(int8_t)*12);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME, (const char *)packet, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_MIN_LEN, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_LEN, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_CRC);
#endif
}
#endif

#endif

// MESSAGE BLUETOOTH_SET_NAME UNPACKING


/**
 * @brief Get field BT_name from bluetooth_set_name message
 *
 * @return BT_name
 */
static inline uint16_t mavlink_msg_bluetooth_set_name_get_BT_name(const mavlink_message_t* msg, int8_t *BT_name)
{
    return _MAV_RETURN_int8_t_array(msg, BT_name, 12,  0);
}

/**
 * @brief Decode a bluetooth_set_name message into a struct
 *
 * @param msg The message to decode
 * @param bluetooth_set_name C-struct to decode the message contents into
 */
static inline void mavlink_msg_bluetooth_set_name_decode(const mavlink_message_t* msg, mavlink_bluetooth_set_name_t* bluetooth_set_name)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_bluetooth_set_name_get_BT_name(msg, bluetooth_set_name->BT_name);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_LEN? msg->len : MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_LEN;
        memset(bluetooth_set_name, 0, MAVLINK_MSG_ID_BLUETOOTH_SET_NAME_LEN);
    memcpy(bluetooth_set_name, _MAV_PAYLOAD(msg), len);
#endif
}
