#pragma once
// MESSAGE car PACKING

#define MAVLINK_MSG_ID_car 224

MAVPACKED(
typedef struct __mavlink_car_t {
 int32_t num; /*< block num
					num == 1
						param1	(orientation)  0:forwards	1:backwards    2:swerve_left    4:swerve_right
						param2	(speed)	
						param3	(time)

					num == 2		wait
						param1	(time_wait)		wait time (>100ms)
											
					num == 3		_if
						param1	(relation)	0:>		1:less    2:= 		3:!=
						param2	(size)
						param3	(maxValue)
						param4	(minValue)
											
					num == 4	    _while
						param1	(count)
						param2	(size)

					num == 5		_function
						param1	(_function)
						param2	(size)
					
					num == 6		_invoke
						param1	(_function)

			*/
 int32_t param1; /*< param1*/
 int32_t param2; /*< param2*/
 int32_t param3; /*< param3*/
 int32_t param4; /*< param4*/
}) mavlink_car_t;

#define MAVLINK_MSG_ID_car_LEN 20
#define MAVLINK_MSG_ID_car_MIN_LEN 20
#define MAVLINK_MSG_ID_224_LEN 20
#define MAVLINK_MSG_ID_224_MIN_LEN 20

#define MAVLINK_MSG_ID_car_CRC 190
#define MAVLINK_MSG_ID_224_CRC 190



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_car { \
    224, \
    "car", \
    5, \
    {  { "num", NULL, MAVLINK_TYPE_INT32_T, 0, 0, offsetof(mavlink_car_t, num) }, \
         { "param1", NULL, MAVLINK_TYPE_INT32_T, 0, 4, offsetof(mavlink_car_t, param1) }, \
         { "param2", NULL, MAVLINK_TYPE_INT32_T, 0, 8, offsetof(mavlink_car_t, param2) }, \
         { "param3", NULL, MAVLINK_TYPE_INT32_T, 0, 12, offsetof(mavlink_car_t, param3) }, \
         { "param4", NULL, MAVLINK_TYPE_INT32_T, 0, 16, offsetof(mavlink_car_t, param4) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_car { \
    "car", \
    5, \
    {  { "num", NULL, MAVLINK_TYPE_INT32_T, 0, 0, offsetof(mavlink_car_t, num) }, \
         { "param1", NULL, MAVLINK_TYPE_INT32_T, 0, 4, offsetof(mavlink_car_t, param1) }, \
         { "param2", NULL, MAVLINK_TYPE_INT32_T, 0, 8, offsetof(mavlink_car_t, param2) }, \
         { "param3", NULL, MAVLINK_TYPE_INT32_T, 0, 12, offsetof(mavlink_car_t, param3) }, \
         { "param4", NULL, MAVLINK_TYPE_INT32_T, 0, 16, offsetof(mavlink_car_t, param4) }, \
         } \
}
#endif

/**
 * @brief Pack a car message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param num block num
					num == 1
						param1	(orientation)  0:forwards	1:backwards    2:swerve_left    4:swerve_right
						param2	(speed)	
						param3	(time)

					num == 2		wait
						param1	(time_wait)		wait time (>100ms)
											
					num == 3		_if
						param1	(relation)	0:>		1:less    2:= 		3:!=
						param2	(size)
						param3	(maxValue)
						param4	(minValue)
											
					num == 4	    _while
						param1	(count)
						param2	(size)

					num == 5		_function
						param1	(_function)
						param2	(size)
					
					num == 6		_invoke
						param1	(_function)

			
 * @param param1 param1
 * @param param2 param2
 * @param param3 param3
 * @param param4 param4
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_car_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               int32_t num, int32_t param1, int32_t param2, int32_t param3, int32_t param4)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_car_LEN];
    _mav_put_int32_t(buf, 0, num);
    _mav_put_int32_t(buf, 4, param1);
    _mav_put_int32_t(buf, 8, param2);
    _mav_put_int32_t(buf, 12, param3);
    _mav_put_int32_t(buf, 16, param4);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_car_LEN);
#else
    mavlink_car_t packet;
    packet.num = num;
    packet.param1 = param1;
    packet.param2 = param2;
    packet.param3 = param3;
    packet.param4 = param4;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_car_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_car;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_car_MIN_LEN, MAVLINK_MSG_ID_car_LEN, MAVLINK_MSG_ID_car_CRC);
}

/**
 * @brief Pack a car message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param num block num
					num == 1
						param1	(orientation)  0:forwards	1:backwards    2:swerve_left    4:swerve_right
						param2	(speed)	
						param3	(time)

					num == 2		wait
						param1	(time_wait)		wait time (>100ms)
											
					num == 3		_if
						param1	(relation)	0:>		1:less    2:= 		3:!=
						param2	(size)
						param3	(maxValue)
						param4	(minValue)
											
					num == 4	    _while
						param1	(count)
						param2	(size)

					num == 5		_function
						param1	(_function)
						param2	(size)
					
					num == 6		_invoke
						param1	(_function)

			
 * @param param1 param1
 * @param param2 param2
 * @param param3 param3
 * @param param4 param4
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_car_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   int32_t num,int32_t param1,int32_t param2,int32_t param3,int32_t param4)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_car_LEN];
    _mav_put_int32_t(buf, 0, num);
    _mav_put_int32_t(buf, 4, param1);
    _mav_put_int32_t(buf, 8, param2);
    _mav_put_int32_t(buf, 12, param3);
    _mav_put_int32_t(buf, 16, param4);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_car_LEN);
#else
    mavlink_car_t packet;
    packet.num = num;
    packet.param1 = param1;
    packet.param2 = param2;
    packet.param3 = param3;
    packet.param4 = param4;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_car_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_car;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_car_MIN_LEN, MAVLINK_MSG_ID_car_LEN, MAVLINK_MSG_ID_car_CRC);
}

/**
 * @brief Encode a car struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param car C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_car_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_car_t* car)
{
    return mavlink_msg_car_pack(system_id, component_id, msg, car->num, car->param1, car->param2, car->param3, car->param4);
}

/**
 * @brief Encode a car struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param car C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_car_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_car_t* car)
{
    return mavlink_msg_car_pack_chan(system_id, component_id, chan, msg, car->num, car->param1, car->param2, car->param3, car->param4);
}

/**
 * @brief Send a car message
 * @param chan MAVLink channel to send the message
 *
 * @param num block num
					num == 1
						param1	(orientation)  0:forwards	1:backwards    2:swerve_left    4:swerve_right
						param2	(speed)	
						param3	(time)

					num == 2		wait
						param1	(time_wait)		wait time (>100ms)
											
					num == 3		_if
						param1	(relation)	0:>		1:less    2:= 		3:!=
						param2	(size)
						param3	(maxValue)
						param4	(minValue)
											
					num == 4	    _while
						param1	(count)
						param2	(size)

					num == 5		_function
						param1	(_function)
						param2	(size)
					
					num == 6		_invoke
						param1	(_function)

			
 * @param param1 param1
 * @param param2 param2
 * @param param3 param3
 * @param param4 param4
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_car_send(mavlink_channel_t chan, int32_t num, int32_t param1, int32_t param2, int32_t param3, int32_t param4)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_car_LEN];
    _mav_put_int32_t(buf, 0, num);
    _mav_put_int32_t(buf, 4, param1);
    _mav_put_int32_t(buf, 8, param2);
    _mav_put_int32_t(buf, 12, param3);
    _mav_put_int32_t(buf, 16, param4);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_car, buf, MAVLINK_MSG_ID_car_MIN_LEN, MAVLINK_MSG_ID_car_LEN, MAVLINK_MSG_ID_car_CRC);
#else
    mavlink_car_t packet;
    packet.num = num;
    packet.param1 = param1;
    packet.param2 = param2;
    packet.param3 = param3;
    packet.param4 = param4;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_car, (const char *)&packet, MAVLINK_MSG_ID_car_MIN_LEN, MAVLINK_MSG_ID_car_LEN, MAVLINK_MSG_ID_car_CRC);
#endif
}

/**
 * @brief Send a car message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_car_send_struct(mavlink_channel_t chan, const mavlink_car_t* car)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_car_send(chan, car->num, car->param1, car->param2, car->param3, car->param4);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_car, (const char *)car, MAVLINK_MSG_ID_car_MIN_LEN, MAVLINK_MSG_ID_car_LEN, MAVLINK_MSG_ID_car_CRC);
#endif
}

#if MAVLINK_MSG_ID_car_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_car_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  int32_t num, int32_t param1, int32_t param2, int32_t param3, int32_t param4)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_int32_t(buf, 0, num);
    _mav_put_int32_t(buf, 4, param1);
    _mav_put_int32_t(buf, 8, param2);
    _mav_put_int32_t(buf, 12, param3);
    _mav_put_int32_t(buf, 16, param4);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_car, buf, MAVLINK_MSG_ID_car_MIN_LEN, MAVLINK_MSG_ID_car_LEN, MAVLINK_MSG_ID_car_CRC);
#else
    mavlink_car_t *packet = (mavlink_car_t *)msgbuf;
    packet->num = num;
    packet->param1 = param1;
    packet->param2 = param2;
    packet->param3 = param3;
    packet->param4 = param4;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_car, (const char *)packet, MAVLINK_MSG_ID_car_MIN_LEN, MAVLINK_MSG_ID_car_LEN, MAVLINK_MSG_ID_car_CRC);
#endif
}
#endif

#endif

// MESSAGE car UNPACKING


/**
 * @brief Get field num from car message
 *
 * @return block num
					num == 1
						param1	(orientation)  0:forwards	1:backwards    2:swerve_left    4:swerve_right
						param2	(speed)	
						param3	(time)

					num == 2		wait
						param1	(time_wait)		wait time (>100ms)
											
					num == 3		_if
						param1	(relation)	0:>		1:less    2:= 		3:!=
						param2	(size)
						param3	(maxValue)
						param4	(minValue)
											
					num == 4	    _while
						param1	(count)
						param2	(size)

					num == 5		_function
						param1	(_function)
						param2	(size)
					
					num == 6		_invoke
						param1	(_function)

			
 */
static inline int32_t mavlink_msg_car_get_num(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  0);
}

/**
 * @brief Get field param1 from car message
 *
 * @return param1
 */
static inline int32_t mavlink_msg_car_get_param1(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  4);
}

/**
 * @brief Get field param2 from car message
 *
 * @return param2
 */
static inline int32_t mavlink_msg_car_get_param2(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  8);
}

/**
 * @brief Get field param3 from car message
 *
 * @return param3
 */
static inline int32_t mavlink_msg_car_get_param3(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  12);
}

/**
 * @brief Get field param4 from car message
 *
 * @return param4
 */
static inline int32_t mavlink_msg_car_get_param4(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  16);
}

/**
 * @brief Decode a car message into a struct
 *
 * @param msg The message to decode
 * @param car C-struct to decode the message contents into
 */
static inline void mavlink_msg_car_decode(const mavlink_message_t* msg, mavlink_car_t* car)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    car->num = mavlink_msg_car_get_num(msg);
    car->param1 = mavlink_msg_car_get_param1(msg);
    car->param2 = mavlink_msg_car_get_param2(msg);
    car->param3 = mavlink_msg_car_get_param3(msg);
    car->param4 = mavlink_msg_car_get_param4(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_car_LEN? msg->len : MAVLINK_MSG_ID_car_LEN;
        memset(car, 0, MAVLINK_MSG_ID_car_LEN);
    memcpy(car, _MAV_PAYLOAD(msg), len);
#endif
}
