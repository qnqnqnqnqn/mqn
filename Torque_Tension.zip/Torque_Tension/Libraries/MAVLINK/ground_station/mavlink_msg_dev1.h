#pragma once
// MESSAGE dev1 PACKING

#define MAVLINK_MSG_ID_dev1 201

MAVPACKED(
typedef struct __mavlink_dev1_t {
 int16_t pitch; /*< pioth -500~500*/
 int16_t roll; /*< roll -500~500*/
 int16_t thro; /*< thro 0~500*/
 int16_t yaw; /*< yaw -500~500*/
 int8_t unlock; /*< cmd LOCK_STATE*/
 int8_t mode; /*< mode 0:normal    1:height*/
 int8_t cmd; /*< mode 0: default  1: take off  2:landing*/
 int8_t head; /*< 0: angle speed		1: angle*/
}) mavlink_dev1_t;

#define MAVLINK_MSG_ID_dev1_LEN 12
#define MAVLINK_MSG_ID_dev1_MIN_LEN 12
#define MAVLINK_MSG_ID_201_LEN 12
#define MAVLINK_MSG_ID_201_MIN_LEN 12

#define MAVLINK_MSG_ID_dev1_CRC 171
#define MAVLINK_MSG_ID_201_CRC 171



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_dev1 { \
    201, \
    "dev1", \
    8, \
    {  { "unlock", NULL, MAVLINK_TYPE_INT8_T, 0, 8, offsetof(mavlink_dev1_t, unlock) }, \
         { "mode", NULL, MAVLINK_TYPE_INT8_T, 0, 9, offsetof(mavlink_dev1_t, mode) }, \
         { "cmd", NULL, MAVLINK_TYPE_INT8_T, 0, 10, offsetof(mavlink_dev1_t, cmd) }, \
         { "head", NULL, MAVLINK_TYPE_INT8_T, 0, 11, offsetof(mavlink_dev1_t, head) }, \
         { "pitch", NULL, MAVLINK_TYPE_INT16_T, 0, 0, offsetof(mavlink_dev1_t, pitch) }, \
         { "roll", NULL, MAVLINK_TYPE_INT16_T, 0, 2, offsetof(mavlink_dev1_t, roll) }, \
         { "thro", NULL, MAVLINK_TYPE_INT16_T, 0, 4, offsetof(mavlink_dev1_t, thro) }, \
         { "yaw", NULL, MAVLINK_TYPE_INT16_T, 0, 6, offsetof(mavlink_dev1_t, yaw) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_dev1 { \
    "dev1", \
    8, \
    {  { "unlock", NULL, MAVLINK_TYPE_INT8_T, 0, 8, offsetof(mavlink_dev1_t, unlock) }, \
         { "mode", NULL, MAVLINK_TYPE_INT8_T, 0, 9, offsetof(mavlink_dev1_t, mode) }, \
         { "cmd", NULL, MAVLINK_TYPE_INT8_T, 0, 10, offsetof(mavlink_dev1_t, cmd) }, \
         { "head", NULL, MAVLINK_TYPE_INT8_T, 0, 11, offsetof(mavlink_dev1_t, head) }, \
         { "pitch", NULL, MAVLINK_TYPE_INT16_T, 0, 0, offsetof(mavlink_dev1_t, pitch) }, \
         { "roll", NULL, MAVLINK_TYPE_INT16_T, 0, 2, offsetof(mavlink_dev1_t, roll) }, \
         { "thro", NULL, MAVLINK_TYPE_INT16_T, 0, 4, offsetof(mavlink_dev1_t, thro) }, \
         { "yaw", NULL, MAVLINK_TYPE_INT16_T, 0, 6, offsetof(mavlink_dev1_t, yaw) }, \
         } \
}
#endif

/**
 * @brief Pack a dev1 message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param unlock cmd LOCK_STATE
 * @param mode mode 0:normal    1:height
 * @param cmd mode 0: default  1: take off  2:landing
 * @param head 0: angle speed		1: angle
 * @param pitch pioth -500~500
 * @param roll roll -500~500
 * @param thro thro 0~500
 * @param yaw yaw -500~500
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev1_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               int8_t unlock, int8_t mode, int8_t cmd, int8_t head, int16_t pitch, int16_t roll, int16_t thro, int16_t yaw)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev1_LEN];
    _mav_put_int16_t(buf, 0, pitch);
    _mav_put_int16_t(buf, 2, roll);
    _mav_put_int16_t(buf, 4, thro);
    _mav_put_int16_t(buf, 6, yaw);
    _mav_put_int8_t(buf, 8, unlock);
    _mav_put_int8_t(buf, 9, mode);
    _mav_put_int8_t(buf, 10, cmd);
    _mav_put_int8_t(buf, 11, head);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev1_LEN);
#else
    mavlink_dev1_t packet;
    packet.pitch = pitch;
    packet.roll = roll;
    packet.thro = thro;
    packet.yaw = yaw;
    packet.unlock = unlock;
    packet.mode = mode;
    packet.cmd = cmd;
    packet.head = head;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev1_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_dev1;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_dev1_MIN_LEN, MAVLINK_MSG_ID_dev1_LEN, MAVLINK_MSG_ID_dev1_CRC);
}

/**
 * @brief Pack a dev1 message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param unlock cmd LOCK_STATE
 * @param mode mode 0:normal    1:height
 * @param cmd mode 0: default  1: take off  2:landing
 * @param head 0: angle speed		1: angle
 * @param pitch pioth -500~500
 * @param roll roll -500~500
 * @param thro thro 0~500
 * @param yaw yaw -500~500
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev1_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   int8_t unlock,int8_t mode,int8_t cmd,int8_t head,int16_t pitch,int16_t roll,int16_t thro,int16_t yaw)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev1_LEN];
    _mav_put_int16_t(buf, 0, pitch);
    _mav_put_int16_t(buf, 2, roll);
    _mav_put_int16_t(buf, 4, thro);
    _mav_put_int16_t(buf, 6, yaw);
    _mav_put_int8_t(buf, 8, unlock);
    _mav_put_int8_t(buf, 9, mode);
    _mav_put_int8_t(buf, 10, cmd);
    _mav_put_int8_t(buf, 11, head);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev1_LEN);
#else
    mavlink_dev1_t packet;
    packet.pitch = pitch;
    packet.roll = roll;
    packet.thro = thro;
    packet.yaw = yaw;
    packet.unlock = unlock;
    packet.mode = mode;
    packet.cmd = cmd;
    packet.head = head;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev1_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_dev1;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_dev1_MIN_LEN, MAVLINK_MSG_ID_dev1_LEN, MAVLINK_MSG_ID_dev1_CRC);
}

/**
 * @brief Encode a dev1 struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param dev1 C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev1_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_dev1_t* dev1)
{
    return mavlink_msg_dev1_pack(system_id, component_id, msg, dev1->unlock, dev1->mode, dev1->cmd, dev1->head, dev1->pitch, dev1->roll, dev1->thro, dev1->yaw);
}

/**
 * @brief Encode a dev1 struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param dev1 C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev1_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_dev1_t* dev1)
{
    return mavlink_msg_dev1_pack_chan(system_id, component_id, chan, msg, dev1->unlock, dev1->mode, dev1->cmd, dev1->head, dev1->pitch, dev1->roll, dev1->thro, dev1->yaw);
}

/**
 * @brief Send a dev1 message
 * @param chan MAVLink channel to send the message
 *
 * @param unlock cmd LOCK_STATE
 * @param mode mode 0:normal    1:height
 * @param cmd mode 0: default  1: take off  2:landing
 * @param head 0: angle speed		1: angle
 * @param pitch pioth -500~500
 * @param roll roll -500~500
 * @param thro thro 0~500
 * @param yaw yaw -500~500
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_dev1_send(mavlink_channel_t chan, int8_t unlock, int8_t mode, int8_t cmd, int8_t head, int16_t pitch, int16_t roll, int16_t thro, int16_t yaw)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev1_LEN];
    _mav_put_int16_t(buf, 0, pitch);
    _mav_put_int16_t(buf, 2, roll);
    _mav_put_int16_t(buf, 4, thro);
    _mav_put_int16_t(buf, 6, yaw);
    _mav_put_int8_t(buf, 8, unlock);
    _mav_put_int8_t(buf, 9, mode);
    _mav_put_int8_t(buf, 10, cmd);
    _mav_put_int8_t(buf, 11, head);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1, buf, MAVLINK_MSG_ID_dev1_MIN_LEN, MAVLINK_MSG_ID_dev1_LEN, MAVLINK_MSG_ID_dev1_CRC);
#else
    mavlink_dev1_t packet;
    packet.pitch = pitch;
    packet.roll = roll;
    packet.thro = thro;
    packet.yaw = yaw;
    packet.unlock = unlock;
    packet.mode = mode;
    packet.cmd = cmd;
    packet.head = head;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1, (const char *)&packet, MAVLINK_MSG_ID_dev1_MIN_LEN, MAVLINK_MSG_ID_dev1_LEN, MAVLINK_MSG_ID_dev1_CRC);
#endif
}

/**
 * @brief Send a dev1 message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_dev1_send_struct(mavlink_channel_t chan, const mavlink_dev1_t* dev1)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_dev1_send(chan, dev1->unlock, dev1->mode, dev1->cmd, dev1->head, dev1->pitch, dev1->roll, dev1->thro, dev1->yaw);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1, (const char *)dev1, MAVLINK_MSG_ID_dev1_MIN_LEN, MAVLINK_MSG_ID_dev1_LEN, MAVLINK_MSG_ID_dev1_CRC);
#endif
}

#if MAVLINK_MSG_ID_dev1_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_dev1_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  int8_t unlock, int8_t mode, int8_t cmd, int8_t head, int16_t pitch, int16_t roll, int16_t thro, int16_t yaw)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_int16_t(buf, 0, pitch);
    _mav_put_int16_t(buf, 2, roll);
    _mav_put_int16_t(buf, 4, thro);
    _mav_put_int16_t(buf, 6, yaw);
    _mav_put_int8_t(buf, 8, unlock);
    _mav_put_int8_t(buf, 9, mode);
    _mav_put_int8_t(buf, 10, cmd);
    _mav_put_int8_t(buf, 11, head);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1, buf, MAVLINK_MSG_ID_dev1_MIN_LEN, MAVLINK_MSG_ID_dev1_LEN, MAVLINK_MSG_ID_dev1_CRC);
#else
    mavlink_dev1_t *packet = (mavlink_dev1_t *)msgbuf;
    packet->pitch = pitch;
    packet->roll = roll;
    packet->thro = thro;
    packet->yaw = yaw;
    packet->unlock = unlock;
    packet->mode = mode;
    packet->cmd = cmd;
    packet->head = head;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1, (const char *)packet, MAVLINK_MSG_ID_dev1_MIN_LEN, MAVLINK_MSG_ID_dev1_LEN, MAVLINK_MSG_ID_dev1_CRC);
#endif
}
#endif

#endif

// MESSAGE dev1 UNPACKING


/**
 * @brief Get field unlock from dev1 message
 *
 * @return cmd LOCK_STATE
 */
static inline int8_t mavlink_msg_dev1_get_unlock(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  8);
}

/**
 * @brief Get field mode from dev1 message
 *
 * @return mode 0:normal    1:height
 */
static inline int8_t mavlink_msg_dev1_get_mode(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  9);
}

/**
 * @brief Get field cmd from dev1 message
 *
 * @return mode 0: default  1: take off  2:landing
 */
static inline int8_t mavlink_msg_dev1_get_cmd(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  10);
}

/**
 * @brief Get field head from dev1 message
 *
 * @return 0: angle speed		1: angle
 */
static inline int8_t mavlink_msg_dev1_get_head(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  11);
}

/**
 * @brief Get field pitch from dev1 message
 *
 * @return pioth -500~500
 */
static inline int16_t mavlink_msg_dev1_get_pitch(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  0);
}

/**
 * @brief Get field roll from dev1 message
 *
 * @return roll -500~500
 */
static inline int16_t mavlink_msg_dev1_get_roll(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  2);
}

/**
 * @brief Get field thro from dev1 message
 *
 * @return thro 0~500
 */
static inline int16_t mavlink_msg_dev1_get_thro(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  4);
}

/**
 * @brief Get field yaw from dev1 message
 *
 * @return yaw -500~500
 */
static inline int16_t mavlink_msg_dev1_get_yaw(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  6);
}

/**
 * @brief Decode a dev1 message into a struct
 *
 * @param msg The message to decode
 * @param dev1 C-struct to decode the message contents into
 */
static inline void mavlink_msg_dev1_decode(const mavlink_message_t* msg, mavlink_dev1_t* dev1)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    dev1->pitch = mavlink_msg_dev1_get_pitch(msg);
    dev1->roll = mavlink_msg_dev1_get_roll(msg);
    dev1->thro = mavlink_msg_dev1_get_thro(msg);
    dev1->yaw = mavlink_msg_dev1_get_yaw(msg);
    dev1->unlock = mavlink_msg_dev1_get_unlock(msg);
    dev1->mode = mavlink_msg_dev1_get_mode(msg);
    dev1->cmd = mavlink_msg_dev1_get_cmd(msg);
    dev1->head = mavlink_msg_dev1_get_head(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_dev1_LEN? msg->len : MAVLINK_MSG_ID_dev1_LEN;
        memset(dev1, 0, MAVLINK_MSG_ID_dev1_LEN);
    memcpy(dev1, _MAV_PAYLOAD(msg), len);
#endif
}
