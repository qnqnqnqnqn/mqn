#pragma once
// MESSAGE dev1_speed PACKING

#define MAVLINK_MSG_ID_dev1_speed 214

MAVPACKED(
typedef struct __mavlink_dev1_speed_t {
 float speed_x; /*< +- speed_x*/
 float speed_y; /*< +- speed_y*/
 float speed_z; /*< +- speed_z*/
}) mavlink_dev1_speed_t;

#define MAVLINK_MSG_ID_dev1_speed_LEN 12
#define MAVLINK_MSG_ID_dev1_speed_MIN_LEN 12
#define MAVLINK_MSG_ID_214_LEN 12
#define MAVLINK_MSG_ID_214_MIN_LEN 12

#define MAVLINK_MSG_ID_dev1_speed_CRC 244
#define MAVLINK_MSG_ID_214_CRC 244



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_dev1_speed { \
    214, \
    "dev1_speed", \
    3, \
    {  { "speed_x", NULL, MAVLINK_TYPE_FLOAT, 0, 0, offsetof(mavlink_dev1_speed_t, speed_x) }, \
         { "speed_y", NULL, MAVLINK_TYPE_FLOAT, 0, 4, offsetof(mavlink_dev1_speed_t, speed_y) }, \
         { "speed_z", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_dev1_speed_t, speed_z) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_dev1_speed { \
    "dev1_speed", \
    3, \
    {  { "speed_x", NULL, MAVLINK_TYPE_FLOAT, 0, 0, offsetof(mavlink_dev1_speed_t, speed_x) }, \
         { "speed_y", NULL, MAVLINK_TYPE_FLOAT, 0, 4, offsetof(mavlink_dev1_speed_t, speed_y) }, \
         { "speed_z", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_dev1_speed_t, speed_z) }, \
         } \
}
#endif

/**
 * @brief Pack a dev1_speed message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param speed_x +- speed_x
 * @param speed_y +- speed_y
 * @param speed_z +- speed_z
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev1_speed_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               float speed_x, float speed_y, float speed_z)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev1_speed_LEN];
    _mav_put_float(buf, 0, speed_x);
    _mav_put_float(buf, 4, speed_y);
    _mav_put_float(buf, 8, speed_z);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev1_speed_LEN);
#else
    mavlink_dev1_speed_t packet;
    packet.speed_x = speed_x;
    packet.speed_y = speed_y;
    packet.speed_z = speed_z;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev1_speed_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_dev1_speed;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_dev1_speed_MIN_LEN, MAVLINK_MSG_ID_dev1_speed_LEN, MAVLINK_MSG_ID_dev1_speed_CRC);
}

/**
 * @brief Pack a dev1_speed message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param speed_x +- speed_x
 * @param speed_y +- speed_y
 * @param speed_z +- speed_z
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev1_speed_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   float speed_x,float speed_y,float speed_z)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev1_speed_LEN];
    _mav_put_float(buf, 0, speed_x);
    _mav_put_float(buf, 4, speed_y);
    _mav_put_float(buf, 8, speed_z);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev1_speed_LEN);
#else
    mavlink_dev1_speed_t packet;
    packet.speed_x = speed_x;
    packet.speed_y = speed_y;
    packet.speed_z = speed_z;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev1_speed_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_dev1_speed;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_dev1_speed_MIN_LEN, MAVLINK_MSG_ID_dev1_speed_LEN, MAVLINK_MSG_ID_dev1_speed_CRC);
}

/**
 * @brief Encode a dev1_speed struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param dev1_speed C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev1_speed_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_dev1_speed_t* dev1_speed)
{
    return mavlink_msg_dev1_speed_pack(system_id, component_id, msg, dev1_speed->speed_x, dev1_speed->speed_y, dev1_speed->speed_z);
}

/**
 * @brief Encode a dev1_speed struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param dev1_speed C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev1_speed_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_dev1_speed_t* dev1_speed)
{
    return mavlink_msg_dev1_speed_pack_chan(system_id, component_id, chan, msg, dev1_speed->speed_x, dev1_speed->speed_y, dev1_speed->speed_z);
}

/**
 * @brief Send a dev1_speed message
 * @param chan MAVLink channel to send the message
 *
 * @param speed_x +- speed_x
 * @param speed_y +- speed_y
 * @param speed_z +- speed_z
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_dev1_speed_send(mavlink_channel_t chan, float speed_x, float speed_y, float speed_z)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev1_speed_LEN];
    _mav_put_float(buf, 0, speed_x);
    _mav_put_float(buf, 4, speed_y);
    _mav_put_float(buf, 8, speed_z);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_speed, buf, MAVLINK_MSG_ID_dev1_speed_MIN_LEN, MAVLINK_MSG_ID_dev1_speed_LEN, MAVLINK_MSG_ID_dev1_speed_CRC);
#else
    mavlink_dev1_speed_t packet;
    packet.speed_x = speed_x;
    packet.speed_y = speed_y;
    packet.speed_z = speed_z;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_speed, (const char *)&packet, MAVLINK_MSG_ID_dev1_speed_MIN_LEN, MAVLINK_MSG_ID_dev1_speed_LEN, MAVLINK_MSG_ID_dev1_speed_CRC);
#endif
}

/**
 * @brief Send a dev1_speed message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_dev1_speed_send_struct(mavlink_channel_t chan, const mavlink_dev1_speed_t* dev1_speed)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_dev1_speed_send(chan, dev1_speed->speed_x, dev1_speed->speed_y, dev1_speed->speed_z);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_speed, (const char *)dev1_speed, MAVLINK_MSG_ID_dev1_speed_MIN_LEN, MAVLINK_MSG_ID_dev1_speed_LEN, MAVLINK_MSG_ID_dev1_speed_CRC);
#endif
}

#if MAVLINK_MSG_ID_dev1_speed_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_dev1_speed_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  float speed_x, float speed_y, float speed_z)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_float(buf, 0, speed_x);
    _mav_put_float(buf, 4, speed_y);
    _mav_put_float(buf, 8, speed_z);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_speed, buf, MAVLINK_MSG_ID_dev1_speed_MIN_LEN, MAVLINK_MSG_ID_dev1_speed_LEN, MAVLINK_MSG_ID_dev1_speed_CRC);
#else
    mavlink_dev1_speed_t *packet = (mavlink_dev1_speed_t *)msgbuf;
    packet->speed_x = speed_x;
    packet->speed_y = speed_y;
    packet->speed_z = speed_z;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev1_speed, (const char *)packet, MAVLINK_MSG_ID_dev1_speed_MIN_LEN, MAVLINK_MSG_ID_dev1_speed_LEN, MAVLINK_MSG_ID_dev1_speed_CRC);
#endif
}
#endif

#endif

// MESSAGE dev1_speed UNPACKING


/**
 * @brief Get field speed_x from dev1_speed message
 *
 * @return +- speed_x
 */
static inline float mavlink_msg_dev1_speed_get_speed_x(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  0);
}

/**
 * @brief Get field speed_y from dev1_speed message
 *
 * @return +- speed_y
 */
static inline float mavlink_msg_dev1_speed_get_speed_y(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  4);
}

/**
 * @brief Get field speed_z from dev1_speed message
 *
 * @return +- speed_z
 */
static inline float mavlink_msg_dev1_speed_get_speed_z(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  8);
}

/**
 * @brief Decode a dev1_speed message into a struct
 *
 * @param msg The message to decode
 * @param dev1_speed C-struct to decode the message contents into
 */
static inline void mavlink_msg_dev1_speed_decode(const mavlink_message_t* msg, mavlink_dev1_speed_t* dev1_speed)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    dev1_speed->speed_x = mavlink_msg_dev1_speed_get_speed_x(msg);
    dev1_speed->speed_y = mavlink_msg_dev1_speed_get_speed_y(msg);
    dev1_speed->speed_z = mavlink_msg_dev1_speed_get_speed_z(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_dev1_speed_LEN? msg->len : MAVLINK_MSG_ID_dev1_speed_LEN;
        memset(dev1_speed, 0, MAVLINK_MSG_ID_dev1_speed_LEN);
    memcpy(dev1_speed, _MAV_PAYLOAD(msg), len);
#endif
}
