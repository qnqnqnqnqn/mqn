#pragma once
// MESSAGE dev2 PACKING

#define MAVLINK_MSG_ID_dev2 203

MAVPACKED(
typedef struct __mavlink_dev2_t {
 int16_t thro; /*< thro -500~500*/
 int16_t orientation; /*< orientation -500~500*/
 int8_t lock; /*< cmd LOCK_STATE*/
}) mavlink_dev2_t;

#define MAVLINK_MSG_ID_dev2_LEN 5
#define MAVLINK_MSG_ID_dev2_MIN_LEN 5
#define MAVLINK_MSG_ID_203_LEN 5
#define MAVLINK_MSG_ID_203_MIN_LEN 5

#define MAVLINK_MSG_ID_dev2_CRC 193
#define MAVLINK_MSG_ID_203_CRC 193



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_dev2 { \
    203, \
    "dev2", \
    3, \
    {  { "lock", NULL, MAVLINK_TYPE_INT8_T, 0, 4, offsetof(mavlink_dev2_t, lock) }, \
         { "thro", NULL, MAVLINK_TYPE_INT16_T, 0, 0, offsetof(mavlink_dev2_t, thro) }, \
         { "orientation", NULL, MAVLINK_TYPE_INT16_T, 0, 2, offsetof(mavlink_dev2_t, orientation) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_dev2 { \
    "dev2", \
    3, \
    {  { "lock", NULL, MAVLINK_TYPE_INT8_T, 0, 4, offsetof(mavlink_dev2_t, lock) }, \
         { "thro", NULL, MAVLINK_TYPE_INT16_T, 0, 0, offsetof(mavlink_dev2_t, thro) }, \
         { "orientation", NULL, MAVLINK_TYPE_INT16_T, 0, 2, offsetof(mavlink_dev2_t, orientation) }, \
         } \
}
#endif

/**
 * @brief Pack a dev2 message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param lock cmd LOCK_STATE
 * @param thro thro -500~500
 * @param orientation orientation -500~500
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev2_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               int8_t lock, int16_t thro, int16_t orientation)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev2_LEN];
    _mav_put_int16_t(buf, 0, thro);
    _mav_put_int16_t(buf, 2, orientation);
    _mav_put_int8_t(buf, 4, lock);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev2_LEN);
#else
    mavlink_dev2_t packet;
    packet.thro = thro;
    packet.orientation = orientation;
    packet.lock = lock;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev2_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_dev2;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_dev2_MIN_LEN, MAVLINK_MSG_ID_dev2_LEN, MAVLINK_MSG_ID_dev2_CRC);
}

/**
 * @brief Pack a dev2 message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param lock cmd LOCK_STATE
 * @param thro thro -500~500
 * @param orientation orientation -500~500
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev2_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   int8_t lock,int16_t thro,int16_t orientation)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev2_LEN];
    _mav_put_int16_t(buf, 0, thro);
    _mav_put_int16_t(buf, 2, orientation);
    _mav_put_int8_t(buf, 4, lock);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev2_LEN);
#else
    mavlink_dev2_t packet;
    packet.thro = thro;
    packet.orientation = orientation;
    packet.lock = lock;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev2_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_dev2;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_dev2_MIN_LEN, MAVLINK_MSG_ID_dev2_LEN, MAVLINK_MSG_ID_dev2_CRC);
}

/**
 * @brief Encode a dev2 struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param dev2 C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev2_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_dev2_t* dev2)
{
    return mavlink_msg_dev2_pack(system_id, component_id, msg, dev2->lock, dev2->thro, dev2->orientation);
}

/**
 * @brief Encode a dev2 struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param dev2 C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev2_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_dev2_t* dev2)
{
    return mavlink_msg_dev2_pack_chan(system_id, component_id, chan, msg, dev2->lock, dev2->thro, dev2->orientation);
}

/**
 * @brief Send a dev2 message
 * @param chan MAVLink channel to send the message
 *
 * @param lock cmd LOCK_STATE
 * @param thro thro -500~500
 * @param orientation orientation -500~500
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_dev2_send(mavlink_channel_t chan, int8_t lock, int16_t thro, int16_t orientation)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev2_LEN];
    _mav_put_int16_t(buf, 0, thro);
    _mav_put_int16_t(buf, 2, orientation);
    _mav_put_int8_t(buf, 4, lock);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev2, buf, MAVLINK_MSG_ID_dev2_MIN_LEN, MAVLINK_MSG_ID_dev2_LEN, MAVLINK_MSG_ID_dev2_CRC);
#else
    mavlink_dev2_t packet;
    packet.thro = thro;
    packet.orientation = orientation;
    packet.lock = lock;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev2, (const char *)&packet, MAVLINK_MSG_ID_dev2_MIN_LEN, MAVLINK_MSG_ID_dev2_LEN, MAVLINK_MSG_ID_dev2_CRC);
#endif
}

/**
 * @brief Send a dev2 message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_dev2_send_struct(mavlink_channel_t chan, const mavlink_dev2_t* dev2)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_dev2_send(chan, dev2->lock, dev2->thro, dev2->orientation);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev2, (const char *)dev2, MAVLINK_MSG_ID_dev2_MIN_LEN, MAVLINK_MSG_ID_dev2_LEN, MAVLINK_MSG_ID_dev2_CRC);
#endif
}

#if MAVLINK_MSG_ID_dev2_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_dev2_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  int8_t lock, int16_t thro, int16_t orientation)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_int16_t(buf, 0, thro);
    _mav_put_int16_t(buf, 2, orientation);
    _mav_put_int8_t(buf, 4, lock);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev2, buf, MAVLINK_MSG_ID_dev2_MIN_LEN, MAVLINK_MSG_ID_dev2_LEN, MAVLINK_MSG_ID_dev2_CRC);
#else
    mavlink_dev2_t *packet = (mavlink_dev2_t *)msgbuf;
    packet->thro = thro;
    packet->orientation = orientation;
    packet->lock = lock;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev2, (const char *)packet, MAVLINK_MSG_ID_dev2_MIN_LEN, MAVLINK_MSG_ID_dev2_LEN, MAVLINK_MSG_ID_dev2_CRC);
#endif
}
#endif

#endif

// MESSAGE dev2 UNPACKING


/**
 * @brief Get field lock from dev2 message
 *
 * @return cmd LOCK_STATE
 */
static inline int8_t mavlink_msg_dev2_get_lock(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  4);
}

/**
 * @brief Get field thro from dev2 message
 *
 * @return thro -500~500
 */
static inline int16_t mavlink_msg_dev2_get_thro(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  0);
}

/**
 * @brief Get field orientation from dev2 message
 *
 * @return orientation -500~500
 */
static inline int16_t mavlink_msg_dev2_get_orientation(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  2);
}

/**
 * @brief Decode a dev2 message into a struct
 *
 * @param msg The message to decode
 * @param dev2 C-struct to decode the message contents into
 */
static inline void mavlink_msg_dev2_decode(const mavlink_message_t* msg, mavlink_dev2_t* dev2)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    dev2->thro = mavlink_msg_dev2_get_thro(msg);
    dev2->orientation = mavlink_msg_dev2_get_orientation(msg);
    dev2->lock = mavlink_msg_dev2_get_lock(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_dev2_LEN? msg->len : MAVLINK_MSG_ID_dev2_LEN;
        memset(dev2, 0, MAVLINK_MSG_ID_dev2_LEN);
    memcpy(dev2, _MAV_PAYLOAD(msg), len);
#endif
}
