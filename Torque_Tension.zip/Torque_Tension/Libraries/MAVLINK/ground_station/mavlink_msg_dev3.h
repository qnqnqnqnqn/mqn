#pragma once
// MESSAGE dev3 PACKING

#define MAVLINK_MSG_ID_dev3 205

MAVPACKED(
typedef struct __mavlink_dev3_t {
 uint16_t angle; /*< angle 0~1999 -> -90~90*/
 uint16_t speed; /*< speed 0~2399*/
 uint8_t lock; /*< cmd LOCK_STATE*/
}) mavlink_dev3_t;

#define MAVLINK_MSG_ID_dev3_LEN 5
#define MAVLINK_MSG_ID_dev3_MIN_LEN 5
#define MAVLINK_MSG_ID_205_LEN 5
#define MAVLINK_MSG_ID_205_MIN_LEN 5

#define MAVLINK_MSG_ID_dev3_CRC 112
#define MAVLINK_MSG_ID_205_CRC 112



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_dev3 { \
    205, \
    "dev3", \
    3, \
    {  { "lock", NULL, MAVLINK_TYPE_UINT8_T, 0, 4, offsetof(mavlink_dev3_t, lock) }, \
         { "angle", NULL, MAVLINK_TYPE_UINT16_T, 0, 0, offsetof(mavlink_dev3_t, angle) }, \
         { "speed", NULL, MAVLINK_TYPE_UINT16_T, 0, 2, offsetof(mavlink_dev3_t, speed) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_dev3 { \
    "dev3", \
    3, \
    {  { "lock", NULL, MAVLINK_TYPE_UINT8_T, 0, 4, offsetof(mavlink_dev3_t, lock) }, \
         { "angle", NULL, MAVLINK_TYPE_UINT16_T, 0, 0, offsetof(mavlink_dev3_t, angle) }, \
         { "speed", NULL, MAVLINK_TYPE_UINT16_T, 0, 2, offsetof(mavlink_dev3_t, speed) }, \
         } \
}
#endif

/**
 * @brief Pack a dev3 message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param lock cmd LOCK_STATE
 * @param angle angle 0~1999 -> -90~90
 * @param speed speed 0~2399
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev3_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t lock, uint16_t angle, uint16_t speed)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev3_LEN];
    _mav_put_uint16_t(buf, 0, angle);
    _mav_put_uint16_t(buf, 2, speed);
    _mav_put_uint8_t(buf, 4, lock);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev3_LEN);
#else
    mavlink_dev3_t packet;
    packet.angle = angle;
    packet.speed = speed;
    packet.lock = lock;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev3_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_dev3;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_dev3_MIN_LEN, MAVLINK_MSG_ID_dev3_LEN, MAVLINK_MSG_ID_dev3_CRC);
}

/**
 * @brief Pack a dev3 message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param lock cmd LOCK_STATE
 * @param angle angle 0~1999 -> -90~90
 * @param speed speed 0~2399
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev3_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t lock,uint16_t angle,uint16_t speed)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev3_LEN];
    _mav_put_uint16_t(buf, 0, angle);
    _mav_put_uint16_t(buf, 2, speed);
    _mav_put_uint8_t(buf, 4, lock);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev3_LEN);
#else
    mavlink_dev3_t packet;
    packet.angle = angle;
    packet.speed = speed;
    packet.lock = lock;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev3_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_dev3;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_dev3_MIN_LEN, MAVLINK_MSG_ID_dev3_LEN, MAVLINK_MSG_ID_dev3_CRC);
}

/**
 * @brief Encode a dev3 struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param dev3 C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev3_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_dev3_t* dev3)
{
    return mavlink_msg_dev3_pack(system_id, component_id, msg, dev3->lock, dev3->angle, dev3->speed);
}

/**
 * @brief Encode a dev3 struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param dev3 C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev3_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_dev3_t* dev3)
{
    return mavlink_msg_dev3_pack_chan(system_id, component_id, chan, msg, dev3->lock, dev3->angle, dev3->speed);
}

/**
 * @brief Send a dev3 message
 * @param chan MAVLink channel to send the message
 *
 * @param lock cmd LOCK_STATE
 * @param angle angle 0~1999 -> -90~90
 * @param speed speed 0~2399
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_dev3_send(mavlink_channel_t chan, uint8_t lock, uint16_t angle, uint16_t speed)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev3_LEN];
    _mav_put_uint16_t(buf, 0, angle);
    _mav_put_uint16_t(buf, 2, speed);
    _mav_put_uint8_t(buf, 4, lock);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev3, buf, MAVLINK_MSG_ID_dev3_MIN_LEN, MAVLINK_MSG_ID_dev3_LEN, MAVLINK_MSG_ID_dev3_CRC);
#else
    mavlink_dev3_t packet;
    packet.angle = angle;
    packet.speed = speed;
    packet.lock = lock;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev3, (const char *)&packet, MAVLINK_MSG_ID_dev3_MIN_LEN, MAVLINK_MSG_ID_dev3_LEN, MAVLINK_MSG_ID_dev3_CRC);
#endif
}

/**
 * @brief Send a dev3 message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_dev3_send_struct(mavlink_channel_t chan, const mavlink_dev3_t* dev3)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_dev3_send(chan, dev3->lock, dev3->angle, dev3->speed);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev3, (const char *)dev3, MAVLINK_MSG_ID_dev3_MIN_LEN, MAVLINK_MSG_ID_dev3_LEN, MAVLINK_MSG_ID_dev3_CRC);
#endif
}

#if MAVLINK_MSG_ID_dev3_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_dev3_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t lock, uint16_t angle, uint16_t speed)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint16_t(buf, 0, angle);
    _mav_put_uint16_t(buf, 2, speed);
    _mav_put_uint8_t(buf, 4, lock);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev3, buf, MAVLINK_MSG_ID_dev3_MIN_LEN, MAVLINK_MSG_ID_dev3_LEN, MAVLINK_MSG_ID_dev3_CRC);
#else
    mavlink_dev3_t *packet = (mavlink_dev3_t *)msgbuf;
    packet->angle = angle;
    packet->speed = speed;
    packet->lock = lock;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev3, (const char *)packet, MAVLINK_MSG_ID_dev3_MIN_LEN, MAVLINK_MSG_ID_dev3_LEN, MAVLINK_MSG_ID_dev3_CRC);
#endif
}
#endif

#endif

// MESSAGE dev3 UNPACKING


/**
 * @brief Get field lock from dev3 message
 *
 * @return cmd LOCK_STATE
 */
static inline uint8_t mavlink_msg_dev3_get_lock(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  4);
}

/**
 * @brief Get field angle from dev3 message
 *
 * @return angle 0~1999 -> -90~90
 */
static inline uint16_t mavlink_msg_dev3_get_angle(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  0);
}

/**
 * @brief Get field speed from dev3 message
 *
 * @return speed 0~2399
 */
static inline uint16_t mavlink_msg_dev3_get_speed(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  2);
}

/**
 * @brief Decode a dev3 message into a struct
 *
 * @param msg The message to decode
 * @param dev3 C-struct to decode the message contents into
 */
static inline void mavlink_msg_dev3_decode(const mavlink_message_t* msg, mavlink_dev3_t* dev3)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    dev3->angle = mavlink_msg_dev3_get_angle(msg);
    dev3->speed = mavlink_msg_dev3_get_speed(msg);
    dev3->lock = mavlink_msg_dev3_get_lock(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_dev3_LEN? msg->len : MAVLINK_MSG_ID_dev3_LEN;
        memset(dev3, 0, MAVLINK_MSG_ID_dev3_LEN);
    memcpy(dev3, _MAV_PAYLOAD(msg), len);
#endif
}
