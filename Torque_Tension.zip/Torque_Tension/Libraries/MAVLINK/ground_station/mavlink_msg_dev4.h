#pragma once
// MESSAGE dev4 PACKING

#define MAVLINK_MSG_ID_dev4 207

MAVPACKED(
typedef struct __mavlink_dev4_t {
 uint16_t angle; /*< speed 0~19999 -> 0~180*/
 uint8_t enable; /*< cmd ENABLE_STAT*/
}) mavlink_dev4_t;

#define MAVLINK_MSG_ID_dev4_LEN 3
#define MAVLINK_MSG_ID_dev4_MIN_LEN 3
#define MAVLINK_MSG_ID_207_LEN 3
#define MAVLINK_MSG_ID_207_MIN_LEN 3

#define MAVLINK_MSG_ID_dev4_CRC 250
#define MAVLINK_MSG_ID_207_CRC 250



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_dev4 { \
    207, \
    "dev4", \
    2, \
    {  { "enable", NULL, MAVLINK_TYPE_UINT8_T, 0, 2, offsetof(mavlink_dev4_t, enable) }, \
         { "angle", NULL, MAVLINK_TYPE_UINT16_T, 0, 0, offsetof(mavlink_dev4_t, angle) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_dev4 { \
    "dev4", \
    2, \
    {  { "enable", NULL, MAVLINK_TYPE_UINT8_T, 0, 2, offsetof(mavlink_dev4_t, enable) }, \
         { "angle", NULL, MAVLINK_TYPE_UINT16_T, 0, 0, offsetof(mavlink_dev4_t, angle) }, \
         } \
}
#endif

/**
 * @brief Pack a dev4 message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param enable cmd ENABLE_STAT
 * @param angle speed 0~19999 -> 0~180
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev4_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t enable, uint16_t angle)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev4_LEN];
    _mav_put_uint16_t(buf, 0, angle);
    _mav_put_uint8_t(buf, 2, enable);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev4_LEN);
#else
    mavlink_dev4_t packet;
    packet.angle = angle;
    packet.enable = enable;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev4_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_dev4;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_dev4_MIN_LEN, MAVLINK_MSG_ID_dev4_LEN, MAVLINK_MSG_ID_dev4_CRC);
}

/**
 * @brief Pack a dev4 message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param enable cmd ENABLE_STAT
 * @param angle speed 0~19999 -> 0~180
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev4_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t enable,uint16_t angle)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev4_LEN];
    _mav_put_uint16_t(buf, 0, angle);
    _mav_put_uint8_t(buf, 2, enable);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev4_LEN);
#else
    mavlink_dev4_t packet;
    packet.angle = angle;
    packet.enable = enable;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev4_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_dev4;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_dev4_MIN_LEN, MAVLINK_MSG_ID_dev4_LEN, MAVLINK_MSG_ID_dev4_CRC);
}

/**
 * @brief Encode a dev4 struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param dev4 C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev4_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_dev4_t* dev4)
{
    return mavlink_msg_dev4_pack(system_id, component_id, msg, dev4->enable, dev4->angle);
}

/**
 * @brief Encode a dev4 struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param dev4 C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev4_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_dev4_t* dev4)
{
    return mavlink_msg_dev4_pack_chan(system_id, component_id, chan, msg, dev4->enable, dev4->angle);
}

/**
 * @brief Send a dev4 message
 * @param chan MAVLink channel to send the message
 *
 * @param enable cmd ENABLE_STAT
 * @param angle speed 0~19999 -> 0~180
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_dev4_send(mavlink_channel_t chan, uint8_t enable, uint16_t angle)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev4_LEN];
    _mav_put_uint16_t(buf, 0, angle);
    _mav_put_uint8_t(buf, 2, enable);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev4, buf, MAVLINK_MSG_ID_dev4_MIN_LEN, MAVLINK_MSG_ID_dev4_LEN, MAVLINK_MSG_ID_dev4_CRC);
#else
    mavlink_dev4_t packet;
    packet.angle = angle;
    packet.enable = enable;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev4, (const char *)&packet, MAVLINK_MSG_ID_dev4_MIN_LEN, MAVLINK_MSG_ID_dev4_LEN, MAVLINK_MSG_ID_dev4_CRC);
#endif
}

/**
 * @brief Send a dev4 message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_dev4_send_struct(mavlink_channel_t chan, const mavlink_dev4_t* dev4)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_dev4_send(chan, dev4->enable, dev4->angle);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev4, (const char *)dev4, MAVLINK_MSG_ID_dev4_MIN_LEN, MAVLINK_MSG_ID_dev4_LEN, MAVLINK_MSG_ID_dev4_CRC);
#endif
}

#if MAVLINK_MSG_ID_dev4_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_dev4_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t enable, uint16_t angle)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint16_t(buf, 0, angle);
    _mav_put_uint8_t(buf, 2, enable);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev4, buf, MAVLINK_MSG_ID_dev4_MIN_LEN, MAVLINK_MSG_ID_dev4_LEN, MAVLINK_MSG_ID_dev4_CRC);
#else
    mavlink_dev4_t *packet = (mavlink_dev4_t *)msgbuf;
    packet->angle = angle;
    packet->enable = enable;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev4, (const char *)packet, MAVLINK_MSG_ID_dev4_MIN_LEN, MAVLINK_MSG_ID_dev4_LEN, MAVLINK_MSG_ID_dev4_CRC);
#endif
}
#endif

#endif

// MESSAGE dev4 UNPACKING


/**
 * @brief Get field enable from dev4 message
 *
 * @return cmd ENABLE_STAT
 */
static inline uint8_t mavlink_msg_dev4_get_enable(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  2);
}

/**
 * @brief Get field angle from dev4 message
 *
 * @return speed 0~19999 -> 0~180
 */
static inline uint16_t mavlink_msg_dev4_get_angle(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  0);
}

/**
 * @brief Decode a dev4 message into a struct
 *
 * @param msg The message to decode
 * @param dev4 C-struct to decode the message contents into
 */
static inline void mavlink_msg_dev4_decode(const mavlink_message_t* msg, mavlink_dev4_t* dev4)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    dev4->angle = mavlink_msg_dev4_get_angle(msg);
    dev4->enable = mavlink_msg_dev4_get_enable(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_dev4_LEN? msg->len : MAVLINK_MSG_ID_dev4_LEN;
        memset(dev4, 0, MAVLINK_MSG_ID_dev4_LEN);
    memcpy(dev4, _MAV_PAYLOAD(msg), len);
#endif
}
