#pragma once
// MESSAGE dev6 PACKING

#define MAVLINK_MSG_ID_dev6 211

MAVPACKED(
typedef struct __mavlink_dev6_t {
 uint32_t msgid; /*< */
}) mavlink_dev6_t;

#define MAVLINK_MSG_ID_dev6_LEN 4
#define MAVLINK_MSG_ID_dev6_MIN_LEN 4
#define MAVLINK_MSG_ID_211_LEN 4
#define MAVLINK_MSG_ID_211_MIN_LEN 4

#define MAVLINK_MSG_ID_dev6_CRC 160
#define MAVLINK_MSG_ID_211_CRC 160



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_dev6 { \
    211, \
    "dev6", \
    1, \
    {  { "msgid", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_dev6_t, msgid) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_dev6 { \
    "dev6", \
    1, \
    {  { "msgid", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_dev6_t, msgid) }, \
         } \
}
#endif

/**
 * @brief Pack a dev6 message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param msgid 
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev6_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint32_t msgid)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev6_LEN];
    _mav_put_uint32_t(buf, 0, msgid);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev6_LEN);
#else
    mavlink_dev6_t packet;
    packet.msgid = msgid;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev6_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_dev6;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_dev6_MIN_LEN, MAVLINK_MSG_ID_dev6_LEN, MAVLINK_MSG_ID_dev6_CRC);
}

/**
 * @brief Pack a dev6 message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param msgid 
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev6_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint32_t msgid)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev6_LEN];
    _mav_put_uint32_t(buf, 0, msgid);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev6_LEN);
#else
    mavlink_dev6_t packet;
    packet.msgid = msgid;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev6_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_dev6;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_dev6_MIN_LEN, MAVLINK_MSG_ID_dev6_LEN, MAVLINK_MSG_ID_dev6_CRC);
}

/**
 * @brief Encode a dev6 struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param dev6 C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev6_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_dev6_t* dev6)
{
    return mavlink_msg_dev6_pack(system_id, component_id, msg, dev6->msgid);
}

/**
 * @brief Encode a dev6 struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param dev6 C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev6_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_dev6_t* dev6)
{
    return mavlink_msg_dev6_pack_chan(system_id, component_id, chan, msg, dev6->msgid);
}

/**
 * @brief Send a dev6 message
 * @param chan MAVLink channel to send the message
 *
 * @param msgid 
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_dev6_send(mavlink_channel_t chan, uint32_t msgid)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev6_LEN];
    _mav_put_uint32_t(buf, 0, msgid);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev6, buf, MAVLINK_MSG_ID_dev6_MIN_LEN, MAVLINK_MSG_ID_dev6_LEN, MAVLINK_MSG_ID_dev6_CRC);
#else
    mavlink_dev6_t packet;
    packet.msgid = msgid;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev6, (const char *)&packet, MAVLINK_MSG_ID_dev6_MIN_LEN, MAVLINK_MSG_ID_dev6_LEN, MAVLINK_MSG_ID_dev6_CRC);
#endif
}

/**
 * @brief Send a dev6 message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_dev6_send_struct(mavlink_channel_t chan, const mavlink_dev6_t* dev6)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_dev6_send(chan, dev6->msgid);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev6, (const char *)dev6, MAVLINK_MSG_ID_dev6_MIN_LEN, MAVLINK_MSG_ID_dev6_LEN, MAVLINK_MSG_ID_dev6_CRC);
#endif
}

#if MAVLINK_MSG_ID_dev6_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_dev6_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t msgid)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint32_t(buf, 0, msgid);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev6, buf, MAVLINK_MSG_ID_dev6_MIN_LEN, MAVLINK_MSG_ID_dev6_LEN, MAVLINK_MSG_ID_dev6_CRC);
#else
    mavlink_dev6_t *packet = (mavlink_dev6_t *)msgbuf;
    packet->msgid = msgid;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev6, (const char *)packet, MAVLINK_MSG_ID_dev6_MIN_LEN, MAVLINK_MSG_ID_dev6_LEN, MAVLINK_MSG_ID_dev6_CRC);
#endif
}
#endif

#endif

// MESSAGE dev6 UNPACKING


/**
 * @brief Get field msgid from dev6 message
 *
 * @return 
 */
static inline uint32_t mavlink_msg_dev6_get_msgid(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Decode a dev6 message into a struct
 *
 * @param msg The message to decode
 * @param dev6 C-struct to decode the message contents into
 */
static inline void mavlink_msg_dev6_decode(const mavlink_message_t* msg, mavlink_dev6_t* dev6)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    dev6->msgid = mavlink_msg_dev6_get_msgid(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_dev6_LEN? msg->len : MAVLINK_MSG_ID_dev6_LEN;
        memset(dev6, 0, MAVLINK_MSG_ID_dev6_LEN);
    memcpy(dev6, _MAV_PAYLOAD(msg), len);
#endif
}
