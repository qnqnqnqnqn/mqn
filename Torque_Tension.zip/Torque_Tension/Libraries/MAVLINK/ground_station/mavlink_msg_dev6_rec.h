#pragma once
// MESSAGE dev6_rec PACKING

#define MAVLINK_MSG_ID_dev6_rec 212

MAVPACKED(
typedef struct __mavlink_dev6_rec_t {
 uint32_t time; /*< time*/
 uint32_t time_ms; /*< time_ms*/
 uint16_t voltage; /*< voltage*/
}) mavlink_dev6_rec_t;

#define MAVLINK_MSG_ID_dev6_rec_LEN 10
#define MAVLINK_MSG_ID_dev6_rec_MIN_LEN 10
#define MAVLINK_MSG_ID_212_LEN 10
#define MAVLINK_MSG_ID_212_MIN_LEN 10

#define MAVLINK_MSG_ID_dev6_rec_CRC 206
#define MAVLINK_MSG_ID_212_CRC 206



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_dev6_rec { \
    212, \
    "dev6_rec", \
    3, \
    {  { "time", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_dev6_rec_t, time) }, \
         { "time_ms", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_dev6_rec_t, time_ms) }, \
         { "voltage", NULL, MAVLINK_TYPE_UINT16_T, 0, 8, offsetof(mavlink_dev6_rec_t, voltage) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_dev6_rec { \
    "dev6_rec", \
    3, \
    {  { "time", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_dev6_rec_t, time) }, \
         { "time_ms", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_dev6_rec_t, time_ms) }, \
         { "voltage", NULL, MAVLINK_TYPE_UINT16_T, 0, 8, offsetof(mavlink_dev6_rec_t, voltage) }, \
         } \
}
#endif

/**
 * @brief Pack a dev6_rec message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param time time
 * @param time_ms time_ms
 * @param voltage voltage
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev6_rec_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint32_t time, uint32_t time_ms, uint16_t voltage)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev6_rec_LEN];
    _mav_put_uint32_t(buf, 0, time);
    _mav_put_uint32_t(buf, 4, time_ms);
    _mav_put_uint16_t(buf, 8, voltage);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev6_rec_LEN);
#else
    mavlink_dev6_rec_t packet;
    packet.time = time;
    packet.time_ms = time_ms;
    packet.voltage = voltage;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev6_rec_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_dev6_rec;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_dev6_rec_MIN_LEN, MAVLINK_MSG_ID_dev6_rec_LEN, MAVLINK_MSG_ID_dev6_rec_CRC);
}

/**
 * @brief Pack a dev6_rec message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param time time
 * @param time_ms time_ms
 * @param voltage voltage
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev6_rec_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint32_t time,uint32_t time_ms,uint16_t voltage)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev6_rec_LEN];
    _mav_put_uint32_t(buf, 0, time);
    _mav_put_uint32_t(buf, 4, time_ms);
    _mav_put_uint16_t(buf, 8, voltage);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev6_rec_LEN);
#else
    mavlink_dev6_rec_t packet;
    packet.time = time;
    packet.time_ms = time_ms;
    packet.voltage = voltage;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev6_rec_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_dev6_rec;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_dev6_rec_MIN_LEN, MAVLINK_MSG_ID_dev6_rec_LEN, MAVLINK_MSG_ID_dev6_rec_CRC);
}

/**
 * @brief Encode a dev6_rec struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param dev6_rec C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev6_rec_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_dev6_rec_t* dev6_rec)
{
    return mavlink_msg_dev6_rec_pack(system_id, component_id, msg, dev6_rec->time, dev6_rec->time_ms, dev6_rec->voltage);
}

/**
 * @brief Encode a dev6_rec struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param dev6_rec C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev6_rec_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_dev6_rec_t* dev6_rec)
{
    return mavlink_msg_dev6_rec_pack_chan(system_id, component_id, chan, msg, dev6_rec->time, dev6_rec->time_ms, dev6_rec->voltage);
}

/**
 * @brief Send a dev6_rec message
 * @param chan MAVLink channel to send the message
 *
 * @param time time
 * @param time_ms time_ms
 * @param voltage voltage
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_dev6_rec_send(mavlink_channel_t chan, uint32_t time, uint32_t time_ms, uint16_t voltage)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev6_rec_LEN];
    _mav_put_uint32_t(buf, 0, time);
    _mav_put_uint32_t(buf, 4, time_ms);
    _mav_put_uint16_t(buf, 8, voltage);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev6_rec, buf, MAVLINK_MSG_ID_dev6_rec_MIN_LEN, MAVLINK_MSG_ID_dev6_rec_LEN, MAVLINK_MSG_ID_dev6_rec_CRC);
#else
    mavlink_dev6_rec_t packet;
    packet.time = time;
    packet.time_ms = time_ms;
    packet.voltage = voltage;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev6_rec, (const char *)&packet, MAVLINK_MSG_ID_dev6_rec_MIN_LEN, MAVLINK_MSG_ID_dev6_rec_LEN, MAVLINK_MSG_ID_dev6_rec_CRC);
#endif
}

/**
 * @brief Send a dev6_rec message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_dev6_rec_send_struct(mavlink_channel_t chan, const mavlink_dev6_rec_t* dev6_rec)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_dev6_rec_send(chan, dev6_rec->time, dev6_rec->time_ms, dev6_rec->voltage);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev6_rec, (const char *)dev6_rec, MAVLINK_MSG_ID_dev6_rec_MIN_LEN, MAVLINK_MSG_ID_dev6_rec_LEN, MAVLINK_MSG_ID_dev6_rec_CRC);
#endif
}

#if MAVLINK_MSG_ID_dev6_rec_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_dev6_rec_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t time, uint32_t time_ms, uint16_t voltage)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint32_t(buf, 0, time);
    _mav_put_uint32_t(buf, 4, time_ms);
    _mav_put_uint16_t(buf, 8, voltage);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev6_rec, buf, MAVLINK_MSG_ID_dev6_rec_MIN_LEN, MAVLINK_MSG_ID_dev6_rec_LEN, MAVLINK_MSG_ID_dev6_rec_CRC);
#else
    mavlink_dev6_rec_t *packet = (mavlink_dev6_rec_t *)msgbuf;
    packet->time = time;
    packet->time_ms = time_ms;
    packet->voltage = voltage;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev6_rec, (const char *)packet, MAVLINK_MSG_ID_dev6_rec_MIN_LEN, MAVLINK_MSG_ID_dev6_rec_LEN, MAVLINK_MSG_ID_dev6_rec_CRC);
#endif
}
#endif

#endif

// MESSAGE dev6_rec UNPACKING


/**
 * @brief Get field time from dev6_rec message
 *
 * @return time
 */
static inline uint32_t mavlink_msg_dev6_rec_get_time(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Get field time_ms from dev6_rec message
 *
 * @return time_ms
 */
static inline uint32_t mavlink_msg_dev6_rec_get_time_ms(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  4);
}

/**
 * @brief Get field voltage from dev6_rec message
 *
 * @return voltage
 */
static inline uint16_t mavlink_msg_dev6_rec_get_voltage(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  8);
}

/**
 * @brief Decode a dev6_rec message into a struct
 *
 * @param msg The message to decode
 * @param dev6_rec C-struct to decode the message contents into
 */
static inline void mavlink_msg_dev6_rec_decode(const mavlink_message_t* msg, mavlink_dev6_rec_t* dev6_rec)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    dev6_rec->time = mavlink_msg_dev6_rec_get_time(msg);
    dev6_rec->time_ms = mavlink_msg_dev6_rec_get_time_ms(msg);
    dev6_rec->voltage = mavlink_msg_dev6_rec_get_voltage(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_dev6_rec_LEN? msg->len : MAVLINK_MSG_ID_dev6_rec_LEN;
        memset(dev6_rec, 0, MAVLINK_MSG_ID_dev6_rec_LEN);
    memcpy(dev6_rec, _MAV_PAYLOAD(msg), len);
#endif
}
