#pragma once
// MESSAGE dev7 PACKING

#define MAVLINK_MSG_ID_dev7 213

MAVPACKED(
typedef struct __mavlink_dev7_t {
 uint8_t number; /*< number 0-7*/
 uint8_t range; /*< range 0-255*/
}) mavlink_dev7_t;

#define MAVLINK_MSG_ID_dev7_LEN 2
#define MAVLINK_MSG_ID_dev7_MIN_LEN 2
#define MAVLINK_MSG_ID_213_LEN 2
#define MAVLINK_MSG_ID_213_MIN_LEN 2

#define MAVLINK_MSG_ID_dev7_CRC 181
#define MAVLINK_MSG_ID_213_CRC 181



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_dev7 { \
    213, \
    "dev7", \
    2, \
    {  { "number", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_dev7_t, number) }, \
         { "range", NULL, MAVLINK_TYPE_UINT8_T, 0, 1, offsetof(mavlink_dev7_t, range) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_dev7 { \
    "dev7", \
    2, \
    {  { "number", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_dev7_t, number) }, \
         { "range", NULL, MAVLINK_TYPE_UINT8_T, 0, 1, offsetof(mavlink_dev7_t, range) }, \
         } \
}
#endif

/**
 * @brief Pack a dev7 message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param number number 0-7
 * @param range range 0-255
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev7_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t number, uint8_t range)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev7_LEN];
    _mav_put_uint8_t(buf, 0, number);
    _mav_put_uint8_t(buf, 1, range);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev7_LEN);
#else
    mavlink_dev7_t packet;
    packet.number = number;
    packet.range = range;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev7_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_dev7;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_dev7_MIN_LEN, MAVLINK_MSG_ID_dev7_LEN, MAVLINK_MSG_ID_dev7_CRC);
}

/**
 * @brief Pack a dev7 message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param number number 0-7
 * @param range range 0-255
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dev7_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t number,uint8_t range)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev7_LEN];
    _mav_put_uint8_t(buf, 0, number);
    _mav_put_uint8_t(buf, 1, range);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_dev7_LEN);
#else
    mavlink_dev7_t packet;
    packet.number = number;
    packet.range = range;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_dev7_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_dev7;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_dev7_MIN_LEN, MAVLINK_MSG_ID_dev7_LEN, MAVLINK_MSG_ID_dev7_CRC);
}

/**
 * @brief Encode a dev7 struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param dev7 C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev7_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_dev7_t* dev7)
{
    return mavlink_msg_dev7_pack(system_id, component_id, msg, dev7->number, dev7->range);
}

/**
 * @brief Encode a dev7 struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param dev7 C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dev7_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_dev7_t* dev7)
{
    return mavlink_msg_dev7_pack_chan(system_id, component_id, chan, msg, dev7->number, dev7->range);
}

/**
 * @brief Send a dev7 message
 * @param chan MAVLink channel to send the message
 *
 * @param number number 0-7
 * @param range range 0-255
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_dev7_send(mavlink_channel_t chan, uint8_t number, uint8_t range)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_dev7_LEN];
    _mav_put_uint8_t(buf, 0, number);
    _mav_put_uint8_t(buf, 1, range);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev7, buf, MAVLINK_MSG_ID_dev7_MIN_LEN, MAVLINK_MSG_ID_dev7_LEN, MAVLINK_MSG_ID_dev7_CRC);
#else
    mavlink_dev7_t packet;
    packet.number = number;
    packet.range = range;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev7, (const char *)&packet, MAVLINK_MSG_ID_dev7_MIN_LEN, MAVLINK_MSG_ID_dev7_LEN, MAVLINK_MSG_ID_dev7_CRC);
#endif
}

/**
 * @brief Send a dev7 message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_dev7_send_struct(mavlink_channel_t chan, const mavlink_dev7_t* dev7)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_dev7_send(chan, dev7->number, dev7->range);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev7, (const char *)dev7, MAVLINK_MSG_ID_dev7_MIN_LEN, MAVLINK_MSG_ID_dev7_LEN, MAVLINK_MSG_ID_dev7_CRC);
#endif
}

#if MAVLINK_MSG_ID_dev7_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_dev7_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t number, uint8_t range)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint8_t(buf, 0, number);
    _mav_put_uint8_t(buf, 1, range);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev7, buf, MAVLINK_MSG_ID_dev7_MIN_LEN, MAVLINK_MSG_ID_dev7_LEN, MAVLINK_MSG_ID_dev7_CRC);
#else
    mavlink_dev7_t *packet = (mavlink_dev7_t *)msgbuf;
    packet->number = number;
    packet->range = range;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_dev7, (const char *)packet, MAVLINK_MSG_ID_dev7_MIN_LEN, MAVLINK_MSG_ID_dev7_LEN, MAVLINK_MSG_ID_dev7_CRC);
#endif
}
#endif

#endif

// MESSAGE dev7 UNPACKING


/**
 * @brief Get field number from dev7 message
 *
 * @return number 0-7
 */
static inline uint8_t mavlink_msg_dev7_get_number(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  0);
}

/**
 * @brief Get field range from dev7 message
 *
 * @return range 0-255
 */
static inline uint8_t mavlink_msg_dev7_get_range(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  1);
}

/**
 * @brief Decode a dev7 message into a struct
 *
 * @param msg The message to decode
 * @param dev7 C-struct to decode the message contents into
 */
static inline void mavlink_msg_dev7_decode(const mavlink_message_t* msg, mavlink_dev7_t* dev7)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    dev7->number = mavlink_msg_dev7_get_number(msg);
    dev7->range = mavlink_msg_dev7_get_range(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_dev7_LEN? msg->len : MAVLINK_MSG_ID_dev7_LEN;
        memset(dev7, 0, MAVLINK_MSG_ID_dev7_LEN);
    memcpy(dev7, _MAV_PAYLOAD(msg), len);
#endif
}
