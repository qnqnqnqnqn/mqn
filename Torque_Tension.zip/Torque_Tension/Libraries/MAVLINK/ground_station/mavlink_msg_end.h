#pragma once
// MESSAGE end PACKING

#define MAVLINK_MSG_ID_end 221

MAVPACKED(
typedef struct __mavlink_end_t {
 int32_t size; /*< code size*/
 int32_t msgid; /*< message id*/
}) mavlink_end_t;

#define MAVLINK_MSG_ID_end_LEN 8
#define MAVLINK_MSG_ID_end_MIN_LEN 8
#define MAVLINK_MSG_ID_221_LEN 8
#define MAVLINK_MSG_ID_221_MIN_LEN 8

#define MAVLINK_MSG_ID_end_CRC 117
#define MAVLINK_MSG_ID_221_CRC 117



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_end { \
    221, \
    "end", \
    2, \
    {  { "size", NULL, MAVLINK_TYPE_INT32_T, 0, 0, offsetof(mavlink_end_t, size) }, \
         { "msgid", NULL, MAVLINK_TYPE_INT32_T, 0, 4, offsetof(mavlink_end_t, msgid) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_end { \
    "end", \
    2, \
    {  { "size", NULL, MAVLINK_TYPE_INT32_T, 0, 0, offsetof(mavlink_end_t, size) }, \
         { "msgid", NULL, MAVLINK_TYPE_INT32_T, 0, 4, offsetof(mavlink_end_t, msgid) }, \
         } \
}
#endif

/**
 * @brief Pack a end message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param size code size
 * @param msgid message id
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_end_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               int32_t size, int32_t msgid)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_end_LEN];
    _mav_put_int32_t(buf, 0, size);
    _mav_put_int32_t(buf, 4, msgid);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_end_LEN);
#else
    mavlink_end_t packet;
    packet.size = size;
    packet.msgid = msgid;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_end_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_end;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_end_MIN_LEN, MAVLINK_MSG_ID_end_LEN, MAVLINK_MSG_ID_end_CRC);
}

/**
 * @brief Pack a end message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param size code size
 * @param msgid message id
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_end_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   int32_t size,int32_t msgid)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_end_LEN];
    _mav_put_int32_t(buf, 0, size);
    _mav_put_int32_t(buf, 4, msgid);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_end_LEN);
#else
    mavlink_end_t packet;
    packet.size = size;
    packet.msgid = msgid;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_end_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_end;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_end_MIN_LEN, MAVLINK_MSG_ID_end_LEN, MAVLINK_MSG_ID_end_CRC);
}

/**
 * @brief Encode a end struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param end C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_end_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_end_t* end)
{
    return mavlink_msg_end_pack(system_id, component_id, msg, end->size, end->msgid);
}

/**
 * @brief Encode a end struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param end C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_end_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_end_t* end)
{
    return mavlink_msg_end_pack_chan(system_id, component_id, chan, msg, end->size, end->msgid);
}

/**
 * @brief Send a end message
 * @param chan MAVLink channel to send the message
 *
 * @param size code size
 * @param msgid message id
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_end_send(mavlink_channel_t chan, int32_t size, int32_t msgid)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_end_LEN];
    _mav_put_int32_t(buf, 0, size);
    _mav_put_int32_t(buf, 4, msgid);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_end, buf, MAVLINK_MSG_ID_end_MIN_LEN, MAVLINK_MSG_ID_end_LEN, MAVLINK_MSG_ID_end_CRC);
#else
    mavlink_end_t packet;
    packet.size = size;
    packet.msgid = msgid;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_end, (const char *)&packet, MAVLINK_MSG_ID_end_MIN_LEN, MAVLINK_MSG_ID_end_LEN, MAVLINK_MSG_ID_end_CRC);
#endif
}

/**
 * @brief Send a end message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_end_send_struct(mavlink_channel_t chan, const mavlink_end_t* end)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_end_send(chan, end->size, end->msgid);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_end, (const char *)end, MAVLINK_MSG_ID_end_MIN_LEN, MAVLINK_MSG_ID_end_LEN, MAVLINK_MSG_ID_end_CRC);
#endif
}

#if MAVLINK_MSG_ID_end_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_end_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  int32_t size, int32_t msgid)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_int32_t(buf, 0, size);
    _mav_put_int32_t(buf, 4, msgid);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_end, buf, MAVLINK_MSG_ID_end_MIN_LEN, MAVLINK_MSG_ID_end_LEN, MAVLINK_MSG_ID_end_CRC);
#else
    mavlink_end_t *packet = (mavlink_end_t *)msgbuf;
    packet->size = size;
    packet->msgid = msgid;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_end, (const char *)packet, MAVLINK_MSG_ID_end_MIN_LEN, MAVLINK_MSG_ID_end_LEN, MAVLINK_MSG_ID_end_CRC);
#endif
}
#endif

#endif

// MESSAGE end UNPACKING


/**
 * @brief Get field size from end message
 *
 * @return code size
 */
static inline int32_t mavlink_msg_end_get_size(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  0);
}

/**
 * @brief Get field msgid from end message
 *
 * @return message id
 */
static inline int32_t mavlink_msg_end_get_msgid(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  4);
}

/**
 * @brief Decode a end message into a struct
 *
 * @param msg The message to decode
 * @param end C-struct to decode the message contents into
 */
static inline void mavlink_msg_end_decode(const mavlink_message_t* msg, mavlink_end_t* end)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    end->size = mavlink_msg_end_get_size(msg);
    end->msgid = mavlink_msg_end_get_msgid(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_end_LEN? msg->len : MAVLINK_MSG_ID_end_LEN;
        memset(end, 0, MAVLINK_MSG_ID_end_LEN);
    memcpy(end, _MAV_PAYLOAD(msg), len);
#endif
}
