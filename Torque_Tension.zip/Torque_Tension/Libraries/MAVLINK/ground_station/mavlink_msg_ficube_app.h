#pragma once
// MESSAGE ficube_app PACKING

#define MAVLINK_MSG_ID_ficube_app 225

MAVPACKED(
typedef struct __mavlink_ficube_app_t {
 int32_t param1; /*< param1*/
 int32_t param2; /*< param2*/
 int32_t param3; /*< param3*/
 int32_t param4; /*< param4*/
 uint16_t num; /*< block num
					num == 0		begin
						param1	size
					num == 1		ctrl_mode
						param1	(ctrl_mode)  	0:close     1:open
					num == 2		yaw_mode
						param1	(yaw_mode)  	0:close     1:open
					num == 3		height_mode
						param1	(height_mode)  	0:close     1:open
					num == 4		gravity_mode
						param1	(gravity_mode)  	0:close     1:open
					num == 5		get_angle(0:roll      1:yaw       2:pitch)
						none
					num == 6		get_speed(0:top		1:front     2:back)
						none
					num == 7		get_acc(0:top		1:front     2:back)
						none
					num == 8		_while
						param1	(count)  	    0~99:value
						param2	(size)  	    0~99:code
					num == 9		_if
						param1	relation	0:>		1:less    2:= 		3:!=
						param2 	value1		-999~999     value2			msb_1:+-  msb_2: type(0:value, 1:num[5.6.7.14.24]) 	msb_3~16:num'param1
						param3 	value2		-999~999     value2			msb_1:+-  msb_2: type(0:value, 1:num[5.6.7.14.24])	msb_3~16:num'param1
						param4	size		code
					num == 10		move_time
						param1	speed		0:slowly		1:normal    2:fast
						param2 	direction	0:top			1:front     2:back
						param3 	time		0~9999:value(ms)
					num == 11		picture
						param1	count		1.2.3.5.10.15:value
					num == 12		video
						param1	count		5.30.45.60.90.120
					num == 13		record
						param1	cmd		 	0:start		1:pause		2:end
					num == 14		get_height
						none
					num == 15		ctrl_height
						param1	height		0~2000:value(mm)
					num == 16		move_distance
						param1	direction	0:top			1:front     2:back
						param2	distance	0~2000:value(mm)
					num == 17		rgb_ring
						param1	which		0:all	1~5:corresponding
						param2	luminance	0~100:value
					num == 18		rgb_color
						param1	rgb_color		bit23~16:rgb_r	bit15~8:rgb_g	bit7~0:rgb_b	
					num == 19		rgb_color
						param1	time		0~10000:value(ms)
						param2	rgb_color_src		bit23~16:rgb_r	bit15~8:rgb_g	bit7~0:rgb_b	
						param3	rgb_color_target	bit23~16:rgb_r	bit15~8:rgb_g	bit7~0:rgb_b
					num == 20		led
						param1	which		0:all	1~2:corresponding
						param2	luminance	0~100:value
					num == 21		led_shadow
						param1	which		0:all	1~2:corresponding
						param2	time		0~10000:value(ms)
						param3	luminance_src		0~100:value
						param4	luminance_target	0~100:value
					num == 22		note
						param1	note		0~20:value
						param2	time		0~10000:value(ms)
					num == 23		play
						param1	number		0~20:value
					num == 24		illumination
						none
					num == 25		delay
						param1	time
					num == 26		body_led
						param1	which		0:all	1~4:corresponding
						param2	luminance	0~100:value
					num == 27		infrared
						param1	frequency
					num == 0xFFFF		end
						param1	size

			*/
 uint16_t seq; /*< seq*/
 int16_t pitch; /*< pioth -500~500*/
 int16_t roll; /*< roll -500~500*/
 int16_t thro; /*< thro 0~500*/
 int16_t yaw; /*< yaw -500~500*/
 int8_t unlock; /*< cmd LOCK_STATE*/
 int8_t mode; /*< mode 0:normal    1:height*/
 int8_t cmd; /*< mode 0: default  1: take off  2:landing*/
 int8_t head; /*< 0: angle speed		1: angle*/
}) mavlink_ficube_app_t;

#define MAVLINK_MSG_ID_ficube_app_LEN 32
#define MAVLINK_MSG_ID_ficube_app_MIN_LEN 32
#define MAVLINK_MSG_ID_225_LEN 32
#define MAVLINK_MSG_ID_225_MIN_LEN 32

#define MAVLINK_MSG_ID_ficube_app_CRC 9
#define MAVLINK_MSG_ID_225_CRC 9



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_ficube_app { \
    225, \
    "ficube_app", \
    14, \
    {  { "num", NULL, MAVLINK_TYPE_UINT16_T, 0, 16, offsetof(mavlink_ficube_app_t, num) }, \
         { "seq", NULL, MAVLINK_TYPE_UINT16_T, 0, 18, offsetof(mavlink_ficube_app_t, seq) }, \
         { "param1", NULL, MAVLINK_TYPE_INT32_T, 0, 0, offsetof(mavlink_ficube_app_t, param1) }, \
         { "param2", NULL, MAVLINK_TYPE_INT32_T, 0, 4, offsetof(mavlink_ficube_app_t, param2) }, \
         { "param3", NULL, MAVLINK_TYPE_INT32_T, 0, 8, offsetof(mavlink_ficube_app_t, param3) }, \
         { "param4", NULL, MAVLINK_TYPE_INT32_T, 0, 12, offsetof(mavlink_ficube_app_t, param4) }, \
         { "unlock", NULL, MAVLINK_TYPE_INT8_T, 0, 28, offsetof(mavlink_ficube_app_t, unlock) }, \
         { "mode", NULL, MAVLINK_TYPE_INT8_T, 0, 29, offsetof(mavlink_ficube_app_t, mode) }, \
         { "cmd", NULL, MAVLINK_TYPE_INT8_T, 0, 30, offsetof(mavlink_ficube_app_t, cmd) }, \
         { "head", NULL, MAVLINK_TYPE_INT8_T, 0, 31, offsetof(mavlink_ficube_app_t, head) }, \
         { "pitch", NULL, MAVLINK_TYPE_INT16_T, 0, 20, offsetof(mavlink_ficube_app_t, pitch) }, \
         { "roll", NULL, MAVLINK_TYPE_INT16_T, 0, 22, offsetof(mavlink_ficube_app_t, roll) }, \
         { "thro", NULL, MAVLINK_TYPE_INT16_T, 0, 24, offsetof(mavlink_ficube_app_t, thro) }, \
         { "yaw", NULL, MAVLINK_TYPE_INT16_T, 0, 26, offsetof(mavlink_ficube_app_t, yaw) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_ficube_app { \
    "ficube_app", \
    14, \
    {  { "num", NULL, MAVLINK_TYPE_UINT16_T, 0, 16, offsetof(mavlink_ficube_app_t, num) }, \
         { "seq", NULL, MAVLINK_TYPE_UINT16_T, 0, 18, offsetof(mavlink_ficube_app_t, seq) }, \
         { "param1", NULL, MAVLINK_TYPE_INT32_T, 0, 0, offsetof(mavlink_ficube_app_t, param1) }, \
         { "param2", NULL, MAVLINK_TYPE_INT32_T, 0, 4, offsetof(mavlink_ficube_app_t, param2) }, \
         { "param3", NULL, MAVLINK_TYPE_INT32_T, 0, 8, offsetof(mavlink_ficube_app_t, param3) }, \
         { "param4", NULL, MAVLINK_TYPE_INT32_T, 0, 12, offsetof(mavlink_ficube_app_t, param4) }, \
         { "unlock", NULL, MAVLINK_TYPE_INT8_T, 0, 28, offsetof(mavlink_ficube_app_t, unlock) }, \
         { "mode", NULL, MAVLINK_TYPE_INT8_T, 0, 29, offsetof(mavlink_ficube_app_t, mode) }, \
         { "cmd", NULL, MAVLINK_TYPE_INT8_T, 0, 30, offsetof(mavlink_ficube_app_t, cmd) }, \
         { "head", NULL, MAVLINK_TYPE_INT8_T, 0, 31, offsetof(mavlink_ficube_app_t, head) }, \
         { "pitch", NULL, MAVLINK_TYPE_INT16_T, 0, 20, offsetof(mavlink_ficube_app_t, pitch) }, \
         { "roll", NULL, MAVLINK_TYPE_INT16_T, 0, 22, offsetof(mavlink_ficube_app_t, roll) }, \
         { "thro", NULL, MAVLINK_TYPE_INT16_T, 0, 24, offsetof(mavlink_ficube_app_t, thro) }, \
         { "yaw", NULL, MAVLINK_TYPE_INT16_T, 0, 26, offsetof(mavlink_ficube_app_t, yaw) }, \
         } \
}
#endif

/**
 * @brief Pack a ficube_app message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param num block num
					num == 0		begin
						param1	size
					num == 1		ctrl_mode
						param1	(ctrl_mode)  	0:close     1:open
					num == 2		yaw_mode
						param1	(yaw_mode)  	0:close     1:open
					num == 3		height_mode
						param1	(height_mode)  	0:close     1:open
					num == 4		gravity_mode
						param1	(gravity_mode)  	0:close     1:open
					num == 5		get_angle(0:roll      1:yaw       2:pitch)
						none
					num == 6		get_speed(0:top		1:front     2:back)
						none
					num == 7		get_acc(0:top		1:front     2:back)
						none
					num == 8		_while
						param1	(count)  	    0~99:value
						param2	(size)  	    0~99:code
					num == 9		_if
						param1	relation	0:>		1:less    2:= 		3:!=
						param2 	value1		-999~999     value2			msb_1:+-  msb_2: type(0:value, 1:num[5.6.7.14.24]) 	msb_3~16:num'param1
						param3 	value2		-999~999     value2			msb_1:+-  msb_2: type(0:value, 1:num[5.6.7.14.24])	msb_3~16:num'param1
						param4	size		code
					num == 10		move_time
						param1	speed		0:slowly		1:normal    2:fast
						param2 	direction	0:top			1:front     2:back
						param3 	time		0~9999:value(ms)
					num == 11		picture
						param1	count		1.2.3.5.10.15:value
					num == 12		video
						param1	count		5.30.45.60.90.120
					num == 13		record
						param1	cmd		 	0:start		1:pause		2:end
					num == 14		get_height
						none
					num == 15		ctrl_height
						param1	height		0~2000:value(mm)
					num == 16		move_distance
						param1	direction	0:top			1:front     2:back
						param2	distance	0~2000:value(mm)
					num == 17		rgb_ring
						param1	which		0:all	1~5:corresponding
						param2	luminance	0~100:value
					num == 18		rgb_color
						param1	rgb_color		bit23~16:rgb_r	bit15~8:rgb_g	bit7~0:rgb_b	
					num == 19		rgb_color
						param1	time		0~10000:value(ms)
						param2	rgb_color_src		bit23~16:rgb_r	bit15~8:rgb_g	bit7~0:rgb_b	
						param3	rgb_color_target	bit23~16:rgb_r	bit15~8:rgb_g	bit7~0:rgb_b
					num == 20		led
						param1	which		0:all	1~2:corresponding
						param2	luminance	0~100:value
					num == 21		led_shadow
						param1	which		0:all	1~2:corresponding
						param2	time		0~10000:value(ms)
						param3	luminance_src		0~100:value
						param4	luminance_target	0~100:value
					num == 22		note
						param1	note		0~20:value
						param2	time		0~10000:value(ms)
					num == 23		play
						param1	number		0~20:value
					num == 24		illumination
						none
					num == 25		delay
						param1	time
					num == 26		body_led
						param1	which		0:all	1~4:corresponding
						param2	luminance	0~100:value
					num == 27		infrared
						param1	frequency
					num == 0xFFFF		end
						param1	size

			
 * @param seq seq
 * @param param1 param1
 * @param param2 param2
 * @param param3 param3
 * @param param4 param4
 * @param unlock cmd LOCK_STATE
 * @param mode mode 0:normal    1:height
 * @param cmd mode 0: default  1: take off  2:landing
 * @param head 0: angle speed		1: angle
 * @param pitch pioth -500~500
 * @param roll roll -500~500
 * @param thro thro 0~500
 * @param yaw yaw -500~500
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ficube_app_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint16_t num, uint16_t seq, int32_t param1, int32_t param2, int32_t param3, int32_t param4, int8_t unlock, int8_t mode, int8_t cmd, int8_t head, int16_t pitch, int16_t roll, int16_t thro, int16_t yaw)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_ficube_app_LEN];
    _mav_put_int32_t(buf, 0, param1);
    _mav_put_int32_t(buf, 4, param2);
    _mav_put_int32_t(buf, 8, param3);
    _mav_put_int32_t(buf, 12, param4);
    _mav_put_uint16_t(buf, 16, num);
    _mav_put_uint16_t(buf, 18, seq);
    _mav_put_int16_t(buf, 20, pitch);
    _mav_put_int16_t(buf, 22, roll);
    _mav_put_int16_t(buf, 24, thro);
    _mav_put_int16_t(buf, 26, yaw);
    _mav_put_int8_t(buf, 28, unlock);
    _mav_put_int8_t(buf, 29, mode);
    _mav_put_int8_t(buf, 30, cmd);
    _mav_put_int8_t(buf, 31, head);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_ficube_app_LEN);
#else
    mavlink_ficube_app_t packet;
    packet.param1 = param1;
    packet.param2 = param2;
    packet.param3 = param3;
    packet.param4 = param4;
    packet.num = num;
    packet.seq = seq;
    packet.pitch = pitch;
    packet.roll = roll;
    packet.thro = thro;
    packet.yaw = yaw;
    packet.unlock = unlock;
    packet.mode = mode;
    packet.cmd = cmd;
    packet.head = head;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_ficube_app_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_ficube_app;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_ficube_app_MIN_LEN, MAVLINK_MSG_ID_ficube_app_LEN, MAVLINK_MSG_ID_ficube_app_CRC);
}

/**
 * @brief Pack a ficube_app message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param num block num
					num == 0		begin
						param1	size
					num == 1		ctrl_mode
						param1	(ctrl_mode)  	0:close     1:open
					num == 2		yaw_mode
						param1	(yaw_mode)  	0:close     1:open
					num == 3		height_mode
						param1	(height_mode)  	0:close     1:open
					num == 4		gravity_mode
						param1	(gravity_mode)  	0:close     1:open
					num == 5		get_angle(0:roll      1:yaw       2:pitch)
						none
					num == 6		get_speed(0:top		1:front     2:back)
						none
					num == 7		get_acc(0:top		1:front     2:back)
						none
					num == 8		_while
						param1	(count)  	    0~99:value
						param2	(size)  	    0~99:code
					num == 9		_if
						param1	relation	0:>		1:less    2:= 		3:!=
						param2 	value1		-999~999     value2			msb_1:+-  msb_2: type(0:value, 1:num[5.6.7.14.24]) 	msb_3~16:num'param1
						param3 	value2		-999~999     value2			msb_1:+-  msb_2: type(0:value, 1:num[5.6.7.14.24])	msb_3~16:num'param1
						param4	size		code
					num == 10		move_time
						param1	speed		0:slowly		1:normal    2:fast
						param2 	direction	0:top			1:front     2:back
						param3 	time		0~9999:value(ms)
					num == 11		picture
						param1	count		1.2.3.5.10.15:value
					num == 12		video
						param1	count		5.30.45.60.90.120
					num == 13		record
						param1	cmd		 	0:start		1:pause		2:end
					num == 14		get_height
						none
					num == 15		ctrl_height
						param1	height		0~2000:value(mm)
					num == 16		move_distance
						param1	direction	0:top			1:front     2:back
						param2	distance	0~2000:value(mm)
					num == 17		rgb_ring
						param1	which		0:all	1~5:corresponding
						param2	luminance	0~100:value
					num == 18		rgb_color
						param1	rgb_color		bit23~16:rgb_r	bit15~8:rgb_g	bit7~0:rgb_b	
					num == 19		rgb_color
						param1	time		0~10000:value(ms)
						param2	rgb_color_src		bit23~16:rgb_r	bit15~8:rgb_g	bit7~0:rgb_b	
						param3	rgb_color_target	bit23~16:rgb_r	bit15~8:rgb_g	bit7~0:rgb_b
					num == 20		led
						param1	which		0:all	1~2:corresponding
						param2	luminance	0~100:value
					num == 21		led_shadow
						param1	which		0:all	1~2:corresponding
						param2	time		0~10000:value(ms)
						param3	luminance_src		0~100:value
						param4	luminance_target	0~100:value
					num == 22		note
						param1	note		0~20:value
						param2	time		0~10000:value(ms)
					num == 23		play
						param1	number		0~20:value
					num == 24		illumination
						none
					num == 25		delay
						param1	time
					num == 26		body_led
						param1	which		0:all	1~4:corresponding
						param2	luminance	0~100:value
					num == 27		infrared
						param1	frequency
					num == 0xFFFF		end
						param1	size

			
 * @param seq seq
 * @param param1 param1
 * @param param2 param2
 * @param param3 param3
 * @param param4 param4
 * @param unlock cmd LOCK_STATE
 * @param mode mode 0:normal    1:height
 * @param cmd mode 0: default  1: take off  2:landing
 * @param head 0: angle speed		1: angle
 * @param pitch pioth -500~500
 * @param roll roll -500~500
 * @param thro thro 0~500
 * @param yaw yaw -500~500
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ficube_app_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint16_t num,uint16_t seq,int32_t param1,int32_t param2,int32_t param3,int32_t param4,int8_t unlock,int8_t mode,int8_t cmd,int8_t head,int16_t pitch,int16_t roll,int16_t thro,int16_t yaw)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_ficube_app_LEN];
    _mav_put_int32_t(buf, 0, param1);
    _mav_put_int32_t(buf, 4, param2);
    _mav_put_int32_t(buf, 8, param3);
    _mav_put_int32_t(buf, 12, param4);
    _mav_put_uint16_t(buf, 16, num);
    _mav_put_uint16_t(buf, 18, seq);
    _mav_put_int16_t(buf, 20, pitch);
    _mav_put_int16_t(buf, 22, roll);
    _mav_put_int16_t(buf, 24, thro);
    _mav_put_int16_t(buf, 26, yaw);
    _mav_put_int8_t(buf, 28, unlock);
    _mav_put_int8_t(buf, 29, mode);
    _mav_put_int8_t(buf, 30, cmd);
    _mav_put_int8_t(buf, 31, head);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_ficube_app_LEN);
#else
    mavlink_ficube_app_t packet;
    packet.param1 = param1;
    packet.param2 = param2;
    packet.param3 = param3;
    packet.param4 = param4;
    packet.num = num;
    packet.seq = seq;
    packet.pitch = pitch;
    packet.roll = roll;
    packet.thro = thro;
    packet.yaw = yaw;
    packet.unlock = unlock;
    packet.mode = mode;
    packet.cmd = cmd;
    packet.head = head;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_ficube_app_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_ficube_app;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_ficube_app_MIN_LEN, MAVLINK_MSG_ID_ficube_app_LEN, MAVLINK_MSG_ID_ficube_app_CRC);
}

/**
 * @brief Encode a ficube_app struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param ficube_app C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ficube_app_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_ficube_app_t* ficube_app)
{
    return mavlink_msg_ficube_app_pack(system_id, component_id, msg, ficube_app->num, ficube_app->seq, ficube_app->param1, ficube_app->param2, ficube_app->param3, ficube_app->param4, ficube_app->unlock, ficube_app->mode, ficube_app->cmd, ficube_app->head, ficube_app->pitch, ficube_app->roll, ficube_app->thro, ficube_app->yaw);
}

/**
 * @brief Encode a ficube_app struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param ficube_app C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ficube_app_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_ficube_app_t* ficube_app)
{
    return mavlink_msg_ficube_app_pack_chan(system_id, component_id, chan, msg, ficube_app->num, ficube_app->seq, ficube_app->param1, ficube_app->param2, ficube_app->param3, ficube_app->param4, ficube_app->unlock, ficube_app->mode, ficube_app->cmd, ficube_app->head, ficube_app->pitch, ficube_app->roll, ficube_app->thro, ficube_app->yaw);
}

/**
 * @brief Send a ficube_app message
 * @param chan MAVLink channel to send the message
 *
 * @param num block num
					num == 0		begin
						param1	size
					num == 1		ctrl_mode
						param1	(ctrl_mode)  	0:close     1:open
					num == 2		yaw_mode
						param1	(yaw_mode)  	0:close     1:open
					num == 3		height_mode
						param1	(height_mode)  	0:close     1:open
					num == 4		gravity_mode
						param1	(gravity_mode)  	0:close     1:open
					num == 5		get_angle(0:roll      1:yaw       2:pitch)
						none
					num == 6		get_speed(0:top		1:front     2:back)
						none
					num == 7		get_acc(0:top		1:front     2:back)
						none
					num == 8		_while
						param1	(count)  	    0~99:value
						param2	(size)  	    0~99:code
					num == 9		_if
						param1	relation	0:>		1:less    2:= 		3:!=
						param2 	value1		-999~999     value2			msb_1:+-  msb_2: type(0:value, 1:num[5.6.7.14.24]) 	msb_3~16:num'param1
						param3 	value2		-999~999     value2			msb_1:+-  msb_2: type(0:value, 1:num[5.6.7.14.24])	msb_3~16:num'param1
						param4	size		code
					num == 10		move_time
						param1	speed		0:slowly		1:normal    2:fast
						param2 	direction	0:top			1:front     2:back
						param3 	time		0~9999:value(ms)
					num == 11		picture
						param1	count		1.2.3.5.10.15:value
					num == 12		video
						param1	count		5.30.45.60.90.120
					num == 13		record
						param1	cmd		 	0:start		1:pause		2:end
					num == 14		get_height
						none
					num == 15		ctrl_height
						param1	height		0~2000:value(mm)
					num == 16		move_distance
						param1	direction	0:top			1:front     2:back
						param2	distance	0~2000:value(mm)
					num == 17		rgb_ring
						param1	which		0:all	1~5:corresponding
						param2	luminance	0~100:value
					num == 18		rgb_color
						param1	rgb_color		bit23~16:rgb_r	bit15~8:rgb_g	bit7~0:rgb_b	
					num == 19		rgb_color
						param1	time		0~10000:value(ms)
						param2	rgb_color_src		bit23~16:rgb_r	bit15~8:rgb_g	bit7~0:rgb_b	
						param3	rgb_color_target	bit23~16:rgb_r	bit15~8:rgb_g	bit7~0:rgb_b
					num == 20		led
						param1	which		0:all	1~2:corresponding
						param2	luminance	0~100:value
					num == 21		led_shadow
						param1	which		0:all	1~2:corresponding
						param2	time		0~10000:value(ms)
						param3	luminance_src		0~100:value
						param4	luminance_target	0~100:value
					num == 22		note
						param1	note		0~20:value
						param2	time		0~10000:value(ms)
					num == 23		play
						param1	number		0~20:value
					num == 24		illumination
						none
					num == 25		delay
						param1	time
					num == 26		body_led
						param1	which		0:all	1~4:corresponding
						param2	luminance	0~100:value
					num == 27		infrared
						param1	frequency
					num == 0xFFFF		end
						param1	size

			
 * @param seq seq
 * @param param1 param1
 * @param param2 param2
 * @param param3 param3
 * @param param4 param4
 * @param unlock cmd LOCK_STATE
 * @param mode mode 0:normal    1:height
 * @param cmd mode 0: default  1: take off  2:landing
 * @param head 0: angle speed		1: angle
 * @param pitch pioth -500~500
 * @param roll roll -500~500
 * @param thro thro 0~500
 * @param yaw yaw -500~500
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_ficube_app_send(mavlink_channel_t chan, uint16_t num, uint16_t seq, int32_t param1, int32_t param2, int32_t param3, int32_t param4, int8_t unlock, int8_t mode, int8_t cmd, int8_t head, int16_t pitch, int16_t roll, int16_t thro, int16_t yaw)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_ficube_app_LEN];
    _mav_put_int32_t(buf, 0, param1);
    _mav_put_int32_t(buf, 4, param2);
    _mav_put_int32_t(buf, 8, param3);
    _mav_put_int32_t(buf, 12, param4);
    _mav_put_uint16_t(buf, 16, num);
    _mav_put_uint16_t(buf, 18, seq);
    _mav_put_int16_t(buf, 20, pitch);
    _mav_put_int16_t(buf, 22, roll);
    _mav_put_int16_t(buf, 24, thro);
    _mav_put_int16_t(buf, 26, yaw);
    _mav_put_int8_t(buf, 28, unlock);
    _mav_put_int8_t(buf, 29, mode);
    _mav_put_int8_t(buf, 30, cmd);
    _mav_put_int8_t(buf, 31, head);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_ficube_app, buf, MAVLINK_MSG_ID_ficube_app_MIN_LEN, MAVLINK_MSG_ID_ficube_app_LEN, MAVLINK_MSG_ID_ficube_app_CRC);
#else
    mavlink_ficube_app_t packet;
    packet.param1 = param1;
    packet.param2 = param2;
    packet.param3 = param3;
    packet.param4 = param4;
    packet.num = num;
    packet.seq = seq;
    packet.pitch = pitch;
    packet.roll = roll;
    packet.thro = thro;
    packet.yaw = yaw;
    packet.unlock = unlock;
    packet.mode = mode;
    packet.cmd = cmd;
    packet.head = head;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_ficube_app, (const char *)&packet, MAVLINK_MSG_ID_ficube_app_MIN_LEN, MAVLINK_MSG_ID_ficube_app_LEN, MAVLINK_MSG_ID_ficube_app_CRC);
#endif
}

/**
 * @brief Send a ficube_app message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_ficube_app_send_struct(mavlink_channel_t chan, const mavlink_ficube_app_t* ficube_app)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_ficube_app_send(chan, ficube_app->num, ficube_app->seq, ficube_app->param1, ficube_app->param2, ficube_app->param3, ficube_app->param4, ficube_app->unlock, ficube_app->mode, ficube_app->cmd, ficube_app->head, ficube_app->pitch, ficube_app->roll, ficube_app->thro, ficube_app->yaw);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_ficube_app, (const char *)ficube_app, MAVLINK_MSG_ID_ficube_app_MIN_LEN, MAVLINK_MSG_ID_ficube_app_LEN, MAVLINK_MSG_ID_ficube_app_CRC);
#endif
}

#if MAVLINK_MSG_ID_ficube_app_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_ficube_app_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint16_t num, uint16_t seq, int32_t param1, int32_t param2, int32_t param3, int32_t param4, int8_t unlock, int8_t mode, int8_t cmd, int8_t head, int16_t pitch, int16_t roll, int16_t thro, int16_t yaw)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_int32_t(buf, 0, param1);
    _mav_put_int32_t(buf, 4, param2);
    _mav_put_int32_t(buf, 8, param3);
    _mav_put_int32_t(buf, 12, param4);
    _mav_put_uint16_t(buf, 16, num);
    _mav_put_uint16_t(buf, 18, seq);
    _mav_put_int16_t(buf, 20, pitch);
    _mav_put_int16_t(buf, 22, roll);
    _mav_put_int16_t(buf, 24, thro);
    _mav_put_int16_t(buf, 26, yaw);
    _mav_put_int8_t(buf, 28, unlock);
    _mav_put_int8_t(buf, 29, mode);
    _mav_put_int8_t(buf, 30, cmd);
    _mav_put_int8_t(buf, 31, head);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_ficube_app, buf, MAVLINK_MSG_ID_ficube_app_MIN_LEN, MAVLINK_MSG_ID_ficube_app_LEN, MAVLINK_MSG_ID_ficube_app_CRC);
#else
    mavlink_ficube_app_t *packet = (mavlink_ficube_app_t *)msgbuf;
    packet->param1 = param1;
    packet->param2 = param2;
    packet->param3 = param3;
    packet->param4 = param4;
    packet->num = num;
    packet->seq = seq;
    packet->pitch = pitch;
    packet->roll = roll;
    packet->thro = thro;
    packet->yaw = yaw;
    packet->unlock = unlock;
    packet->mode = mode;
    packet->cmd = cmd;
    packet->head = head;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_ficube_app, (const char *)packet, MAVLINK_MSG_ID_ficube_app_MIN_LEN, MAVLINK_MSG_ID_ficube_app_LEN, MAVLINK_MSG_ID_ficube_app_CRC);
#endif
}
#endif

#endif

// MESSAGE ficube_app UNPACKING


/**
 * @brief Get field num from ficube_app message
 *
 * @return block num
					num == 0		begin
						param1	size
					num == 1		ctrl_mode
						param1	(ctrl_mode)  	0:close     1:open
					num == 2		yaw_mode
						param1	(yaw_mode)  	0:close     1:open
					num == 3		height_mode
						param1	(height_mode)  	0:close     1:open
					num == 4		gravity_mode
						param1	(gravity_mode)  	0:close     1:open
					num == 5		get_angle(0:roll      1:yaw       2:pitch)
						none
					num == 6		get_speed(0:top		1:front     2:back)
						none
					num == 7		get_acc(0:top		1:front     2:back)
						none
					num == 8		_while
						param1	(count)  	    0~99:value
						param2	(size)  	    0~99:code
					num == 9		_if
						param1	relation	0:>		1:less    2:= 		3:!=
						param2 	value1		-999~999     value2			msb_1:+-  msb_2: type(0:value, 1:num[5.6.7.14.24]) 	msb_3~16:num'param1
						param3 	value2		-999~999     value2			msb_1:+-  msb_2: type(0:value, 1:num[5.6.7.14.24])	msb_3~16:num'param1
						param4	size		code
					num == 10		move_time
						param1	speed		0:slowly		1:normal    2:fast
						param2 	direction	0:top			1:front     2:back
						param3 	time		0~9999:value(ms)
					num == 11		picture
						param1	count		1.2.3.5.10.15:value
					num == 12		video
						param1	count		5.30.45.60.90.120
					num == 13		record
						param1	cmd		 	0:start		1:pause		2:end
					num == 14		get_height
						none
					num == 15		ctrl_height
						param1	height		0~2000:value(mm)
					num == 16		move_distance
						param1	direction	0:top			1:front     2:back
						param2	distance	0~2000:value(mm)
					num == 17		rgb_ring
						param1	which		0:all	1~5:corresponding
						param2	luminance	0~100:value
					num == 18		rgb_color
						param1	rgb_color		bit23~16:rgb_r	bit15~8:rgb_g	bit7~0:rgb_b	
					num == 19		rgb_color
						param1	time		0~10000:value(ms)
						param2	rgb_color_src		bit23~16:rgb_r	bit15~8:rgb_g	bit7~0:rgb_b	
						param3	rgb_color_target	bit23~16:rgb_r	bit15~8:rgb_g	bit7~0:rgb_b
					num == 20		led
						param1	which		0:all	1~2:corresponding
						param2	luminance	0~100:value
					num == 21		led_shadow
						param1	which		0:all	1~2:corresponding
						param2	time		0~10000:value(ms)
						param3	luminance_src		0~100:value
						param4	luminance_target	0~100:value
					num == 22		note
						param1	note		0~20:value
						param2	time		0~10000:value(ms)
					num == 23		play
						param1	number		0~20:value
					num == 24		illumination
						none
					num == 25		delay
						param1	time
					num == 26		body_led
						param1	which		0:all	1~4:corresponding
						param2	luminance	0~100:value
					num == 27		infrared
						param1	frequency
					num == 0xFFFF		end
						param1	size

			
 */
static inline uint16_t mavlink_msg_ficube_app_get_num(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  16);
}

/**
 * @brief Get field seq from ficube_app message
 *
 * @return seq
 */
static inline uint16_t mavlink_msg_ficube_app_get_seq(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  18);
}

/**
 * @brief Get field param1 from ficube_app message
 *
 * @return param1
 */
static inline int32_t mavlink_msg_ficube_app_get_param1(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  0);
}

/**
 * @brief Get field param2 from ficube_app message
 *
 * @return param2
 */
static inline int32_t mavlink_msg_ficube_app_get_param2(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  4);
}

/**
 * @brief Get field param3 from ficube_app message
 *
 * @return param3
 */
static inline int32_t mavlink_msg_ficube_app_get_param3(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  8);
}

/**
 * @brief Get field param4 from ficube_app message
 *
 * @return param4
 */
static inline int32_t mavlink_msg_ficube_app_get_param4(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  12);
}

/**
 * @brief Get field unlock from ficube_app message
 *
 * @return cmd LOCK_STATE
 */
static inline int8_t mavlink_msg_ficube_app_get_unlock(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  28);
}

/**
 * @brief Get field mode from ficube_app message
 *
 * @return mode 0:normal    1:height
 */
static inline int8_t mavlink_msg_ficube_app_get_mode(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  29);
}

/**
 * @brief Get field cmd from ficube_app message
 *
 * @return mode 0: default  1: take off  2:landing
 */
static inline int8_t mavlink_msg_ficube_app_get_cmd(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  30);
}

/**
 * @brief Get field head from ficube_app message
 *
 * @return 0: angle speed		1: angle
 */
static inline int8_t mavlink_msg_ficube_app_get_head(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int8_t(msg,  31);
}

/**
 * @brief Get field pitch from ficube_app message
 *
 * @return pioth -500~500
 */
static inline int16_t mavlink_msg_ficube_app_get_pitch(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  20);
}

/**
 * @brief Get field roll from ficube_app message
 *
 * @return roll -500~500
 */
static inline int16_t mavlink_msg_ficube_app_get_roll(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  22);
}

/**
 * @brief Get field thro from ficube_app message
 *
 * @return thro 0~500
 */
static inline int16_t mavlink_msg_ficube_app_get_thro(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  24);
}

/**
 * @brief Get field yaw from ficube_app message
 *
 * @return yaw -500~500
 */
static inline int16_t mavlink_msg_ficube_app_get_yaw(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int16_t(msg,  26);
}

/**
 * @brief Decode a ficube_app message into a struct
 *
 * @param msg The message to decode
 * @param ficube_app C-struct to decode the message contents into
 */
static inline void mavlink_msg_ficube_app_decode(const mavlink_message_t* msg, mavlink_ficube_app_t* ficube_app)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    ficube_app->param1 = mavlink_msg_ficube_app_get_param1(msg);
    ficube_app->param2 = mavlink_msg_ficube_app_get_param2(msg);
    ficube_app->param3 = mavlink_msg_ficube_app_get_param3(msg);
    ficube_app->param4 = mavlink_msg_ficube_app_get_param4(msg);
    ficube_app->num = mavlink_msg_ficube_app_get_num(msg);
    ficube_app->seq = mavlink_msg_ficube_app_get_seq(msg);
    ficube_app->pitch = mavlink_msg_ficube_app_get_pitch(msg);
    ficube_app->roll = mavlink_msg_ficube_app_get_roll(msg);
    ficube_app->thro = mavlink_msg_ficube_app_get_thro(msg);
    ficube_app->yaw = mavlink_msg_ficube_app_get_yaw(msg);
    ficube_app->unlock = mavlink_msg_ficube_app_get_unlock(msg);
    ficube_app->mode = mavlink_msg_ficube_app_get_mode(msg);
    ficube_app->cmd = mavlink_msg_ficube_app_get_cmd(msg);
    ficube_app->head = mavlink_msg_ficube_app_get_head(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_ficube_app_LEN? msg->len : MAVLINK_MSG_ID_ficube_app_LEN;
        memset(ficube_app, 0, MAVLINK_MSG_ID_ficube_app_LEN);
    memcpy(ficube_app, _MAV_PAYLOAD(msg), len);
#endif
}
