#pragma once
// MESSAGE led_matrix PACKING

#define MAVLINK_MSG_ID_led_matrix 223

MAVPACKED(
typedef struct __mavlink_led_matrix_t {
 int32_t num; /*< block num
					num == 1		_set_variate
						param1	(variate)		0~4
						param2	(value)			0~999

					num == 2		_change_state
						param1	(variate_row)	0~99
						param2	(variate_col)	0~99
						param3	(switcher)		0:on	1:off

					num == 3		_duartion
						param1	(duartion)		0~9999

					num == 4		_change_variate
						param1	(operation)		0~4
						param2	(value)			0~99
						param3	(variate)		0~4
						
					num == 5		_while
						param1	(count)
						param2	(size)

					num == 6		_until
						param1	(variate1)
						param2	(operation)
						param3	(variate2)
						param4	(size)						
						
					num == 7		_if
						param1	(variate1)
						param2	(operation)
						param3	(variate2)
						param4	(size)

					num == 8		_function
						param1	(_function)
						param2	(size)
					
					num == 9		_invoke
						param1	(_function)			invoke function id
			*/
 int32_t param1; /*< param1*/
 int32_t param2; /*< param2*/
 int32_t param3; /*< param3*/
 int32_t param4; /*< param4*/
}) mavlink_led_matrix_t;

#define MAVLINK_MSG_ID_led_matrix_LEN 20
#define MAVLINK_MSG_ID_led_matrix_MIN_LEN 20
#define MAVLINK_MSG_ID_223_LEN 20
#define MAVLINK_MSG_ID_223_MIN_LEN 20

#define MAVLINK_MSG_ID_led_matrix_CRC 197
#define MAVLINK_MSG_ID_223_CRC 197



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_led_matrix { \
    223, \
    "led_matrix", \
    5, \
    {  { "num", NULL, MAVLINK_TYPE_INT32_T, 0, 0, offsetof(mavlink_led_matrix_t, num) }, \
         { "param1", NULL, MAVLINK_TYPE_INT32_T, 0, 4, offsetof(mavlink_led_matrix_t, param1) }, \
         { "param2", NULL, MAVLINK_TYPE_INT32_T, 0, 8, offsetof(mavlink_led_matrix_t, param2) }, \
         { "param3", NULL, MAVLINK_TYPE_INT32_T, 0, 12, offsetof(mavlink_led_matrix_t, param3) }, \
         { "param4", NULL, MAVLINK_TYPE_INT32_T, 0, 16, offsetof(mavlink_led_matrix_t, param4) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_led_matrix { \
    "led_matrix", \
    5, \
    {  { "num", NULL, MAVLINK_TYPE_INT32_T, 0, 0, offsetof(mavlink_led_matrix_t, num) }, \
         { "param1", NULL, MAVLINK_TYPE_INT32_T, 0, 4, offsetof(mavlink_led_matrix_t, param1) }, \
         { "param2", NULL, MAVLINK_TYPE_INT32_T, 0, 8, offsetof(mavlink_led_matrix_t, param2) }, \
         { "param3", NULL, MAVLINK_TYPE_INT32_T, 0, 12, offsetof(mavlink_led_matrix_t, param3) }, \
         { "param4", NULL, MAVLINK_TYPE_INT32_T, 0, 16, offsetof(mavlink_led_matrix_t, param4) }, \
         } \
}
#endif

/**
 * @brief Pack a led_matrix message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param num block num
					num == 1		_set_variate
						param1	(variate)		0~4
						param2	(value)			0~999

					num == 2		_change_state
						param1	(variate_row)	0~99
						param2	(variate_col)	0~99
						param3	(switcher)		0:on	1:off

					num == 3		_duartion
						param1	(duartion)		0~9999

					num == 4		_change_variate
						param1	(operation)		0~4
						param2	(value)			0~99
						param3	(variate)		0~4
						
					num == 5		_while
						param1	(count)
						param2	(size)

					num == 6		_until
						param1	(variate1)
						param2	(operation)
						param3	(variate2)
						param4	(size)						
						
					num == 7		_if
						param1	(variate1)
						param2	(operation)
						param3	(variate2)
						param4	(size)

					num == 8		_function
						param1	(_function)
						param2	(size)
					
					num == 9		_invoke
						param1	(_function)			invoke function id
			
 * @param param1 param1
 * @param param2 param2
 * @param param3 param3
 * @param param4 param4
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_led_matrix_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               int32_t num, int32_t param1, int32_t param2, int32_t param3, int32_t param4)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_led_matrix_LEN];
    _mav_put_int32_t(buf, 0, num);
    _mav_put_int32_t(buf, 4, param1);
    _mav_put_int32_t(buf, 8, param2);
    _mav_put_int32_t(buf, 12, param3);
    _mav_put_int32_t(buf, 16, param4);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_led_matrix_LEN);
#else
    mavlink_led_matrix_t packet;
    packet.num = num;
    packet.param1 = param1;
    packet.param2 = param2;
    packet.param3 = param3;
    packet.param4 = param4;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_led_matrix_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_led_matrix;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_led_matrix_MIN_LEN, MAVLINK_MSG_ID_led_matrix_LEN, MAVLINK_MSG_ID_led_matrix_CRC);
}

/**
 * @brief Pack a led_matrix message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param num block num
					num == 1		_set_variate
						param1	(variate)		0~4
						param2	(value)			0~999

					num == 2		_change_state
						param1	(variate_row)	0~99
						param2	(variate_col)	0~99
						param3	(switcher)		0:on	1:off

					num == 3		_duartion
						param1	(duartion)		0~9999

					num == 4		_change_variate
						param1	(operation)		0~4
						param2	(value)			0~99
						param3	(variate)		0~4
						
					num == 5		_while
						param1	(count)
						param2	(size)

					num == 6		_until
						param1	(variate1)
						param2	(operation)
						param3	(variate2)
						param4	(size)						
						
					num == 7		_if
						param1	(variate1)
						param2	(operation)
						param3	(variate2)
						param4	(size)

					num == 8		_function
						param1	(_function)
						param2	(size)
					
					num == 9		_invoke
						param1	(_function)			invoke function id
			
 * @param param1 param1
 * @param param2 param2
 * @param param3 param3
 * @param param4 param4
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_led_matrix_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   int32_t num,int32_t param1,int32_t param2,int32_t param3,int32_t param4)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_led_matrix_LEN];
    _mav_put_int32_t(buf, 0, num);
    _mav_put_int32_t(buf, 4, param1);
    _mav_put_int32_t(buf, 8, param2);
    _mav_put_int32_t(buf, 12, param3);
    _mav_put_int32_t(buf, 16, param4);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_led_matrix_LEN);
#else
    mavlink_led_matrix_t packet;
    packet.num = num;
    packet.param1 = param1;
    packet.param2 = param2;
    packet.param3 = param3;
    packet.param4 = param4;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_led_matrix_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_led_matrix;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_led_matrix_MIN_LEN, MAVLINK_MSG_ID_led_matrix_LEN, MAVLINK_MSG_ID_led_matrix_CRC);
}

/**
 * @brief Encode a led_matrix struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param led_matrix C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_led_matrix_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_led_matrix_t* led_matrix)
{
    return mavlink_msg_led_matrix_pack(system_id, component_id, msg, led_matrix->num, led_matrix->param1, led_matrix->param2, led_matrix->param3, led_matrix->param4);
}

/**
 * @brief Encode a led_matrix struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param led_matrix C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_led_matrix_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_led_matrix_t* led_matrix)
{
    return mavlink_msg_led_matrix_pack_chan(system_id, component_id, chan, msg, led_matrix->num, led_matrix->param1, led_matrix->param2, led_matrix->param3, led_matrix->param4);
}

/**
 * @brief Send a led_matrix message
 * @param chan MAVLink channel to send the message
 *
 * @param num block num
					num == 1		_set_variate
						param1	(variate)		0~4
						param2	(value)			0~999

					num == 2		_change_state
						param1	(variate_row)	0~99
						param2	(variate_col)	0~99
						param3	(switcher)		0:on	1:off

					num == 3		_duartion
						param1	(duartion)		0~9999

					num == 4		_change_variate
						param1	(operation)		0~4
						param2	(value)			0~99
						param3	(variate)		0~4
						
					num == 5		_while
						param1	(count)
						param2	(size)

					num == 6		_until
						param1	(variate1)
						param2	(operation)
						param3	(variate2)
						param4	(size)						
						
					num == 7		_if
						param1	(variate1)
						param2	(operation)
						param3	(variate2)
						param4	(size)

					num == 8		_function
						param1	(_function)
						param2	(size)
					
					num == 9		_invoke
						param1	(_function)			invoke function id
			
 * @param param1 param1
 * @param param2 param2
 * @param param3 param3
 * @param param4 param4
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_led_matrix_send(mavlink_channel_t chan, int32_t num, int32_t param1, int32_t param2, int32_t param3, int32_t param4)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_led_matrix_LEN];
    _mav_put_int32_t(buf, 0, num);
    _mav_put_int32_t(buf, 4, param1);
    _mav_put_int32_t(buf, 8, param2);
    _mav_put_int32_t(buf, 12, param3);
    _mav_put_int32_t(buf, 16, param4);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_led_matrix, buf, MAVLINK_MSG_ID_led_matrix_MIN_LEN, MAVLINK_MSG_ID_led_matrix_LEN, MAVLINK_MSG_ID_led_matrix_CRC);
#else
    mavlink_led_matrix_t packet;
    packet.num = num;
    packet.param1 = param1;
    packet.param2 = param2;
    packet.param3 = param3;
    packet.param4 = param4;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_led_matrix, (const char *)&packet, MAVLINK_MSG_ID_led_matrix_MIN_LEN, MAVLINK_MSG_ID_led_matrix_LEN, MAVLINK_MSG_ID_led_matrix_CRC);
#endif
}

/**
 * @brief Send a led_matrix message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_led_matrix_send_struct(mavlink_channel_t chan, const mavlink_led_matrix_t* led_matrix)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_led_matrix_send(chan, led_matrix->num, led_matrix->param1, led_matrix->param2, led_matrix->param3, led_matrix->param4);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_led_matrix, (const char *)led_matrix, MAVLINK_MSG_ID_led_matrix_MIN_LEN, MAVLINK_MSG_ID_led_matrix_LEN, MAVLINK_MSG_ID_led_matrix_CRC);
#endif
}

#if MAVLINK_MSG_ID_led_matrix_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_led_matrix_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  int32_t num, int32_t param1, int32_t param2, int32_t param3, int32_t param4)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_int32_t(buf, 0, num);
    _mav_put_int32_t(buf, 4, param1);
    _mav_put_int32_t(buf, 8, param2);
    _mav_put_int32_t(buf, 12, param3);
    _mav_put_int32_t(buf, 16, param4);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_led_matrix, buf, MAVLINK_MSG_ID_led_matrix_MIN_LEN, MAVLINK_MSG_ID_led_matrix_LEN, MAVLINK_MSG_ID_led_matrix_CRC);
#else
    mavlink_led_matrix_t *packet = (mavlink_led_matrix_t *)msgbuf;
    packet->num = num;
    packet->param1 = param1;
    packet->param2 = param2;
    packet->param3 = param3;
    packet->param4 = param4;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_led_matrix, (const char *)packet, MAVLINK_MSG_ID_led_matrix_MIN_LEN, MAVLINK_MSG_ID_led_matrix_LEN, MAVLINK_MSG_ID_led_matrix_CRC);
#endif
}
#endif

#endif

// MESSAGE led_matrix UNPACKING


/**
 * @brief Get field num from led_matrix message
 *
 * @return block num
					num == 1		_set_variate
						param1	(variate)		0~4
						param2	(value)			0~999

					num == 2		_change_state
						param1	(variate_row)	0~99
						param2	(variate_col)	0~99
						param3	(switcher)		0:on	1:off

					num == 3		_duartion
						param1	(duartion)		0~9999

					num == 4		_change_variate
						param1	(operation)		0~4
						param2	(value)			0~99
						param3	(variate)		0~4
						
					num == 5		_while
						param1	(count)
						param2	(size)

					num == 6		_until
						param1	(variate1)
						param2	(operation)
						param3	(variate2)
						param4	(size)						
						
					num == 7		_if
						param1	(variate1)
						param2	(operation)
						param3	(variate2)
						param4	(size)

					num == 8		_function
						param1	(_function)
						param2	(size)
					
					num == 9		_invoke
						param1	(_function)			invoke function id
			
 */
static inline int32_t mavlink_msg_led_matrix_get_num(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  0);
}

/**
 * @brief Get field param1 from led_matrix message
 *
 * @return param1
 */
static inline int32_t mavlink_msg_led_matrix_get_param1(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  4);
}

/**
 * @brief Get field param2 from led_matrix message
 *
 * @return param2
 */
static inline int32_t mavlink_msg_led_matrix_get_param2(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  8);
}

/**
 * @brief Get field param3 from led_matrix message
 *
 * @return param3
 */
static inline int32_t mavlink_msg_led_matrix_get_param3(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  12);
}

/**
 * @brief Get field param4 from led_matrix message
 *
 * @return param4
 */
static inline int32_t mavlink_msg_led_matrix_get_param4(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  16);
}

/**
 * @brief Decode a led_matrix message into a struct
 *
 * @param msg The message to decode
 * @param led_matrix C-struct to decode the message contents into
 */
static inline void mavlink_msg_led_matrix_decode(const mavlink_message_t* msg, mavlink_led_matrix_t* led_matrix)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    led_matrix->num = mavlink_msg_led_matrix_get_num(msg);
    led_matrix->param1 = mavlink_msg_led_matrix_get_param1(msg);
    led_matrix->param2 = mavlink_msg_led_matrix_get_param2(msg);
    led_matrix->param3 = mavlink_msg_led_matrix_get_param3(msg);
    led_matrix->param4 = mavlink_msg_led_matrix_get_param4(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_led_matrix_LEN? msg->len : MAVLINK_MSG_ID_led_matrix_LEN;
        memset(led_matrix, 0, MAVLINK_MSG_ID_led_matrix_LEN);
    memcpy(led_matrix, _MAV_PAYLOAD(msg), len);
#endif
}
