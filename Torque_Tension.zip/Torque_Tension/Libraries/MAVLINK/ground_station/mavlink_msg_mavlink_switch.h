#pragma once
// MESSAGE MAVLINK_SWITCH PACKING

#define MAVLINK_MSG_ID_MAVLINK_SWITCH 180

MAVPACKED(
typedef struct __mavlink_mavlink_switch_t {
 uint32_t mavlink_switch; /*< MAV_SWITCH*/
}) mavlink_mavlink_switch_t;

#define MAVLINK_MSG_ID_MAVLINK_SWITCH_LEN 4
#define MAVLINK_MSG_ID_MAVLINK_SWITCH_MIN_LEN 4
#define MAVLINK_MSG_ID_180_LEN 4
#define MAVLINK_MSG_ID_180_MIN_LEN 4

#define MAVLINK_MSG_ID_MAVLINK_SWITCH_CRC 134
#define MAVLINK_MSG_ID_180_CRC 134



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_MAVLINK_SWITCH { \
    180, \
    "MAVLINK_SWITCH", \
    1, \
    {  { "mavlink_switch", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_mavlink_switch_t, mavlink_switch) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_MAVLINK_SWITCH { \
    "MAVLINK_SWITCH", \
    1, \
    {  { "mavlink_switch", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_mavlink_switch_t, mavlink_switch) }, \
         } \
}
#endif

/**
 * @brief Pack a mavlink_switch message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param mavlink_switch MAV_SWITCH
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_mavlink_switch_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint32_t mavlink_switch)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_MAVLINK_SWITCH_LEN];
    _mav_put_uint32_t(buf, 0, mavlink_switch);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_MAVLINK_SWITCH_LEN);
#else
    mavlink_mavlink_switch_t packet;
    packet.mavlink_switch = mavlink_switch;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_MAVLINK_SWITCH_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_MAVLINK_SWITCH;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_MAVLINK_SWITCH_MIN_LEN, MAVLINK_MSG_ID_MAVLINK_SWITCH_LEN, MAVLINK_MSG_ID_MAVLINK_SWITCH_CRC);
}

/**
 * @brief Pack a mavlink_switch message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param mavlink_switch MAV_SWITCH
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_mavlink_switch_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint32_t mavlink_switch)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_MAVLINK_SWITCH_LEN];
    _mav_put_uint32_t(buf, 0, mavlink_switch);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_MAVLINK_SWITCH_LEN);
#else
    mavlink_mavlink_switch_t packet;
    packet.mavlink_switch = mavlink_switch;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_MAVLINK_SWITCH_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_MAVLINK_SWITCH;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_MAVLINK_SWITCH_MIN_LEN, MAVLINK_MSG_ID_MAVLINK_SWITCH_LEN, MAVLINK_MSG_ID_MAVLINK_SWITCH_CRC);
}

/**
 * @brief Encode a mavlink_switch struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param mavlink_switch C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_mavlink_switch_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_mavlink_switch_t* mavlink_switch)
{
    return mavlink_msg_mavlink_switch_pack(system_id, component_id, msg, mavlink_switch->mavlink_switch);
}

/**
 * @brief Encode a mavlink_switch struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param mavlink_switch C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_mavlink_switch_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_mavlink_switch_t* mavlink_switch)
{
    return mavlink_msg_mavlink_switch_pack_chan(system_id, component_id, chan, msg, mavlink_switch->mavlink_switch);
}

/**
 * @brief Send a mavlink_switch message
 * @param chan MAVLink channel to send the message
 *
 * @param mavlink_switch MAV_SWITCH
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_mavlink_switch_send(mavlink_channel_t chan, uint32_t mavlink_switch)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_MAVLINK_SWITCH_LEN];
    _mav_put_uint32_t(buf, 0, mavlink_switch);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_MAVLINK_SWITCH, buf, MAVLINK_MSG_ID_MAVLINK_SWITCH_MIN_LEN, MAVLINK_MSG_ID_MAVLINK_SWITCH_LEN, MAVLINK_MSG_ID_MAVLINK_SWITCH_CRC);
#else
    mavlink_mavlink_switch_t packet;
    packet.mavlink_switch = mavlink_switch;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_MAVLINK_SWITCH, (const char *)&packet, MAVLINK_MSG_ID_MAVLINK_SWITCH_MIN_LEN, MAVLINK_MSG_ID_MAVLINK_SWITCH_LEN, MAVLINK_MSG_ID_MAVLINK_SWITCH_CRC);
#endif
}

/**
 * @brief Send a mavlink_switch message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_mavlink_switch_send_struct(mavlink_channel_t chan, const mavlink_mavlink_switch_t* mavlink_switch)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_mavlink_switch_send(chan, mavlink_switch->mavlink_switch);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_MAVLINK_SWITCH, (const char *)mavlink_switch, MAVLINK_MSG_ID_MAVLINK_SWITCH_MIN_LEN, MAVLINK_MSG_ID_MAVLINK_SWITCH_LEN, MAVLINK_MSG_ID_MAVLINK_SWITCH_CRC);
#endif
}

#if MAVLINK_MSG_ID_MAVLINK_SWITCH_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_mavlink_switch_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t mavlink_switch)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint32_t(buf, 0, mavlink_switch);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_MAVLINK_SWITCH, buf, MAVLINK_MSG_ID_MAVLINK_SWITCH_MIN_LEN, MAVLINK_MSG_ID_MAVLINK_SWITCH_LEN, MAVLINK_MSG_ID_MAVLINK_SWITCH_CRC);
#else
    mavlink_mavlink_switch_t *packet = (mavlink_mavlink_switch_t *)msgbuf;
    packet->mavlink_switch = mavlink_switch;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_MAVLINK_SWITCH, (const char *)packet, MAVLINK_MSG_ID_MAVLINK_SWITCH_MIN_LEN, MAVLINK_MSG_ID_MAVLINK_SWITCH_LEN, MAVLINK_MSG_ID_MAVLINK_SWITCH_CRC);
#endif
}
#endif

#endif

// MESSAGE MAVLINK_SWITCH UNPACKING


/**
 * @brief Get field mavlink_switch from mavlink_switch message
 *
 * @return MAV_SWITCH
 */
static inline uint32_t mavlink_msg_mavlink_switch_get_mavlink_switch(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Decode a mavlink_switch message into a struct
 *
 * @param msg The message to decode
 * @param mavlink_switch C-struct to decode the message contents into
 */
static inline void mavlink_msg_mavlink_switch_decode(const mavlink_message_t* msg, mavlink_mavlink_switch_t* mavlink_switch)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_switch->mavlink_switch = mavlink_msg_mavlink_switch_get_mavlink_switch(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_MAVLINK_SWITCH_LEN? msg->len : MAVLINK_MSG_ID_MAVLINK_SWITCH_LEN;
        memset(mavlink_switch, 0, MAVLINK_MSG_ID_MAVLINK_SWITCH_LEN);
    memcpy(mavlink_switch, _MAV_PAYLOAD(msg), len);
#endif
}
