#pragma once
// MESSAGE motor_control PACKING

#define MAVLINK_MSG_ID_motor_control 189

MAVPACKED(
typedef struct __mavlink_motor_control_t {
 uint16_t parameter; /*< parameter*/
 uint16_t number; /*<  The motor serial number*/
}) mavlink_motor_control_t;

#define MAVLINK_MSG_ID_motor_control_LEN 4
#define MAVLINK_MSG_ID_motor_control_MIN_LEN 4
#define MAVLINK_MSG_ID_189_LEN 4
#define MAVLINK_MSG_ID_189_MIN_LEN 4

#define MAVLINK_MSG_ID_motor_control_CRC 56
#define MAVLINK_MSG_ID_189_CRC 56



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_motor_control { \
    189, \
    "motor_control", \
    2, \
    {  { "parameter", NULL, MAVLINK_TYPE_UINT16_T, 0, 0, offsetof(mavlink_motor_control_t, parameter) }, \
         { "number", NULL, MAVLINK_TYPE_UINT16_T, 0, 2, offsetof(mavlink_motor_control_t, number) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_motor_control { \
    "motor_control", \
    2, \
    {  { "parameter", NULL, MAVLINK_TYPE_UINT16_T, 0, 0, offsetof(mavlink_motor_control_t, parameter) }, \
         { "number", NULL, MAVLINK_TYPE_UINT16_T, 0, 2, offsetof(mavlink_motor_control_t, number) }, \
         } \
}
#endif

/**
 * @brief Pack a motor_control message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param parameter parameter
 * @param number  The motor serial number
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_motor_control_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint16_t parameter, uint16_t number)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_motor_control_LEN];
    _mav_put_uint16_t(buf, 0, parameter);
    _mav_put_uint16_t(buf, 2, number);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_motor_control_LEN);
#else
    mavlink_motor_control_t packet;
    packet.parameter = parameter;
    packet.number = number;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_motor_control_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_motor_control;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_motor_control_MIN_LEN, MAVLINK_MSG_ID_motor_control_LEN, MAVLINK_MSG_ID_motor_control_CRC);
}

/**
 * @brief Pack a motor_control message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param parameter parameter
 * @param number  The motor serial number
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_motor_control_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint16_t parameter,uint16_t number)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_motor_control_LEN];
    _mav_put_uint16_t(buf, 0, parameter);
    _mav_put_uint16_t(buf, 2, number);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_motor_control_LEN);
#else
    mavlink_motor_control_t packet;
    packet.parameter = parameter;
    packet.number = number;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_motor_control_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_motor_control;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_motor_control_MIN_LEN, MAVLINK_MSG_ID_motor_control_LEN, MAVLINK_MSG_ID_motor_control_CRC);
}

/**
 * @brief Encode a motor_control struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param motor_control C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_motor_control_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_motor_control_t* motor_control)
{
    return mavlink_msg_motor_control_pack(system_id, component_id, msg, motor_control->parameter, motor_control->number);
}

/**
 * @brief Encode a motor_control struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param motor_control C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_motor_control_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_motor_control_t* motor_control)
{
    return mavlink_msg_motor_control_pack_chan(system_id, component_id, chan, msg, motor_control->parameter, motor_control->number);
}

/**
 * @brief Send a motor_control message
 * @param chan MAVLink channel to send the message
 *
 * @param parameter parameter
 * @param number  The motor serial number
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_motor_control_send(mavlink_channel_t chan, uint16_t parameter, uint16_t number)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_motor_control_LEN];
    _mav_put_uint16_t(buf, 0, parameter);
    _mav_put_uint16_t(buf, 2, number);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_motor_control, buf, MAVLINK_MSG_ID_motor_control_MIN_LEN, MAVLINK_MSG_ID_motor_control_LEN, MAVLINK_MSG_ID_motor_control_CRC);
#else
    mavlink_motor_control_t packet;
    packet.parameter = parameter;
    packet.number = number;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_motor_control, (const char *)&packet, MAVLINK_MSG_ID_motor_control_MIN_LEN, MAVLINK_MSG_ID_motor_control_LEN, MAVLINK_MSG_ID_motor_control_CRC);
#endif
}

/**
 * @brief Send a motor_control message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_motor_control_send_struct(mavlink_channel_t chan, const mavlink_motor_control_t* motor_control)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_motor_control_send(chan, motor_control->parameter, motor_control->number);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_motor_control, (const char *)motor_control, MAVLINK_MSG_ID_motor_control_MIN_LEN, MAVLINK_MSG_ID_motor_control_LEN, MAVLINK_MSG_ID_motor_control_CRC);
#endif
}

#if MAVLINK_MSG_ID_motor_control_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_motor_control_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint16_t parameter, uint16_t number)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint16_t(buf, 0, parameter);
    _mav_put_uint16_t(buf, 2, number);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_motor_control, buf, MAVLINK_MSG_ID_motor_control_MIN_LEN, MAVLINK_MSG_ID_motor_control_LEN, MAVLINK_MSG_ID_motor_control_CRC);
#else
    mavlink_motor_control_t *packet = (mavlink_motor_control_t *)msgbuf;
    packet->parameter = parameter;
    packet->number = number;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_motor_control, (const char *)packet, MAVLINK_MSG_ID_motor_control_MIN_LEN, MAVLINK_MSG_ID_motor_control_LEN, MAVLINK_MSG_ID_motor_control_CRC);
#endif
}
#endif

#endif

// MESSAGE motor_control UNPACKING


/**
 * @brief Get field parameter from motor_control message
 *
 * @return parameter
 */
static inline uint16_t mavlink_msg_motor_control_get_parameter(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  0);
}

/**
 * @brief Get field number from motor_control message
 *
 * @return  The motor serial number
 */
static inline uint16_t mavlink_msg_motor_control_get_number(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  2);
}

/**
 * @brief Decode a motor_control message into a struct
 *
 * @param msg The message to decode
 * @param motor_control C-struct to decode the message contents into
 */
static inline void mavlink_msg_motor_control_decode(const mavlink_message_t* msg, mavlink_motor_control_t* motor_control)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    motor_control->parameter = mavlink_msg_motor_control_get_parameter(msg);
    motor_control->number = mavlink_msg_motor_control_get_number(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_motor_control_LEN? msg->len : MAVLINK_MSG_ID_motor_control_LEN;
        memset(motor_control, 0, MAVLINK_MSG_ID_motor_control_LEN);
    memcpy(motor_control, _MAV_PAYLOAD(msg), len);
#endif
}
