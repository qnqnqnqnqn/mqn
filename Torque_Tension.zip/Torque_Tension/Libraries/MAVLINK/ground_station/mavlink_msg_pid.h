#pragma once
// MESSAGE PID PACKING

#define MAVLINK_MSG_ID_PID 181

MAVPACKED(
typedef struct __mavlink_pid_t {
 uint32_t number; /*< 0 :get all pid
												 1 :set stable_loop.pid.roll
												 2 :set stable_loop.pid.pitch
												 3 :set stable_loop.pid.yaw
												 4 :set rate_loop.pid.roll
												 5 :set rate_loop.pid.pitch
												 6 :set rate_loop.pid.yaw
												 7 :set location.pid.x  
												 8 :set location.pid.y
												 9 :set location.pid.z
												 10:set speed.pid.x
												 11:set speed.pid.y
												 12:set speed.pid.z
												*/
 float PID_P; /*< PID_P*/
 float PID_I; /*< PID_I*/
 float PID_D; /*< PID_D*/
}) mavlink_pid_t;

#define MAVLINK_MSG_ID_PID_LEN 16
#define MAVLINK_MSG_ID_PID_MIN_LEN 16
#define MAVLINK_MSG_ID_181_LEN 16
#define MAVLINK_MSG_ID_181_MIN_LEN 16

#define MAVLINK_MSG_ID_PID_CRC 197
#define MAVLINK_MSG_ID_181_CRC 197



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_PID { \
    181, \
    "PID", \
    4, \
    {  { "number", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_pid_t, number) }, \
         { "PID_P", NULL, MAVLINK_TYPE_FLOAT, 0, 4, offsetof(mavlink_pid_t, PID_P) }, \
         { "PID_I", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_pid_t, PID_I) }, \
         { "PID_D", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_pid_t, PID_D) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_PID { \
    "PID", \
    4, \
    {  { "number", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_pid_t, number) }, \
         { "PID_P", NULL, MAVLINK_TYPE_FLOAT, 0, 4, offsetof(mavlink_pid_t, PID_P) }, \
         { "PID_I", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_pid_t, PID_I) }, \
         { "PID_D", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_pid_t, PID_D) }, \
         } \
}
#endif

/**
 * @brief Pack a pid message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param number 0 :get all pid
												 1 :set stable_loop.pid.roll
												 2 :set stable_loop.pid.pitch
												 3 :set stable_loop.pid.yaw
												 4 :set rate_loop.pid.roll
												 5 :set rate_loop.pid.pitch
												 6 :set rate_loop.pid.yaw
												 7 :set location.pid.x  
												 8 :set location.pid.y
												 9 :set location.pid.z
												 10:set speed.pid.x
												 11:set speed.pid.y
												 12:set speed.pid.z
												
 * @param PID_P PID_P
 * @param PID_I PID_I
 * @param PID_D PID_D
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_pid_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint32_t number, float PID_P, float PID_I, float PID_D)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_PID_LEN];
    _mav_put_uint32_t(buf, 0, number);
    _mav_put_float(buf, 4, PID_P);
    _mav_put_float(buf, 8, PID_I);
    _mav_put_float(buf, 12, PID_D);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_PID_LEN);
#else
    mavlink_pid_t packet;
    packet.number = number;
    packet.PID_P = PID_P;
    packet.PID_I = PID_I;
    packet.PID_D = PID_D;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_PID_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_PID;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_PID_MIN_LEN, MAVLINK_MSG_ID_PID_LEN, MAVLINK_MSG_ID_PID_CRC);
}

/**
 * @brief Pack a pid message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param number 0 :get all pid
												 1 :set stable_loop.pid.roll
												 2 :set stable_loop.pid.pitch
												 3 :set stable_loop.pid.yaw
												 4 :set rate_loop.pid.roll
												 5 :set rate_loop.pid.pitch
												 6 :set rate_loop.pid.yaw
												 7 :set location.pid.x  
												 8 :set location.pid.y
												 9 :set location.pid.z
												 10:set speed.pid.x
												 11:set speed.pid.y
												 12:set speed.pid.z
												
 * @param PID_P PID_P
 * @param PID_I PID_I
 * @param PID_D PID_D
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_pid_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint32_t number,float PID_P,float PID_I,float PID_D)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_PID_LEN];
    _mav_put_uint32_t(buf, 0, number);
    _mav_put_float(buf, 4, PID_P);
    _mav_put_float(buf, 8, PID_I);
    _mav_put_float(buf, 12, PID_D);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_PID_LEN);
#else
    mavlink_pid_t packet;
    packet.number = number;
    packet.PID_P = PID_P;
    packet.PID_I = PID_I;
    packet.PID_D = PID_D;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_PID_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_PID;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_PID_MIN_LEN, MAVLINK_MSG_ID_PID_LEN, MAVLINK_MSG_ID_PID_CRC);
}

/**
 * @brief Encode a pid struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param pid C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_pid_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_pid_t* pid)
{
    return mavlink_msg_pid_pack(system_id, component_id, msg, pid->number, pid->PID_P, pid->PID_I, pid->PID_D);
}

/**
 * @brief Encode a pid struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param pid C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_pid_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_pid_t* pid)
{
    return mavlink_msg_pid_pack_chan(system_id, component_id, chan, msg, pid->number, pid->PID_P, pid->PID_I, pid->PID_D);
}

/**
 * @brief Send a pid message
 * @param chan MAVLink channel to send the message
 *
 * @param number 0 :get all pid
												 1 :set stable_loop.pid.roll
												 2 :set stable_loop.pid.pitch
												 3 :set stable_loop.pid.yaw
												 4 :set rate_loop.pid.roll
												 5 :set rate_loop.pid.pitch
												 6 :set rate_loop.pid.yaw
												 7 :set location.pid.x  
												 8 :set location.pid.y
												 9 :set location.pid.z
												 10:set speed.pid.x
												 11:set speed.pid.y
												 12:set speed.pid.z
												
 * @param PID_P PID_P
 * @param PID_I PID_I
 * @param PID_D PID_D
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_pid_send(mavlink_channel_t chan, uint32_t number, float PID_P, float PID_I, float PID_D)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_PID_LEN];
    _mav_put_uint32_t(buf, 0, number);
    _mav_put_float(buf, 4, PID_P);
    _mav_put_float(buf, 8, PID_I);
    _mav_put_float(buf, 12, PID_D);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_PID, buf, MAVLINK_MSG_ID_PID_MIN_LEN, MAVLINK_MSG_ID_PID_LEN, MAVLINK_MSG_ID_PID_CRC);
#else
    mavlink_pid_t packet;
    packet.number = number;
    packet.PID_P = PID_P;
    packet.PID_I = PID_I;
    packet.PID_D = PID_D;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_PID, (const char *)&packet, MAVLINK_MSG_ID_PID_MIN_LEN, MAVLINK_MSG_ID_PID_LEN, MAVLINK_MSG_ID_PID_CRC);
#endif
}

/**
 * @brief Send a pid message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_pid_send_struct(mavlink_channel_t chan, const mavlink_pid_t* pid)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_pid_send(chan, pid->number, pid->PID_P, pid->PID_I, pid->PID_D);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_PID, (const char *)pid, MAVLINK_MSG_ID_PID_MIN_LEN, MAVLINK_MSG_ID_PID_LEN, MAVLINK_MSG_ID_PID_CRC);
#endif
}

#if MAVLINK_MSG_ID_PID_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_pid_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t number, float PID_P, float PID_I, float PID_D)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint32_t(buf, 0, number);
    _mav_put_float(buf, 4, PID_P);
    _mav_put_float(buf, 8, PID_I);
    _mav_put_float(buf, 12, PID_D);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_PID, buf, MAVLINK_MSG_ID_PID_MIN_LEN, MAVLINK_MSG_ID_PID_LEN, MAVLINK_MSG_ID_PID_CRC);
#else
    mavlink_pid_t *packet = (mavlink_pid_t *)msgbuf;
    packet->number = number;
    packet->PID_P = PID_P;
    packet->PID_I = PID_I;
    packet->PID_D = PID_D;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_PID, (const char *)packet, MAVLINK_MSG_ID_PID_MIN_LEN, MAVLINK_MSG_ID_PID_LEN, MAVLINK_MSG_ID_PID_CRC);
#endif
}
#endif

#endif

// MESSAGE PID UNPACKING


/**
 * @brief Get field number from pid message
 *
 * @return 0 :get all pid
												 1 :set stable_loop.pid.roll
												 2 :set stable_loop.pid.pitch
												 3 :set stable_loop.pid.yaw
												 4 :set rate_loop.pid.roll
												 5 :set rate_loop.pid.pitch
												 6 :set rate_loop.pid.yaw
												 7 :set location.pid.x  
												 8 :set location.pid.y
												 9 :set location.pid.z
												 10:set speed.pid.x
												 11:set speed.pid.y
												 12:set speed.pid.z
												
 */
static inline uint32_t mavlink_msg_pid_get_number(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Get field PID_P from pid message
 *
 * @return PID_P
 */
static inline float mavlink_msg_pid_get_PID_P(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  4);
}

/**
 * @brief Get field PID_I from pid message
 *
 * @return PID_I
 */
static inline float mavlink_msg_pid_get_PID_I(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  8);
}

/**
 * @brief Get field PID_D from pid message
 *
 * @return PID_D
 */
static inline float mavlink_msg_pid_get_PID_D(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  12);
}

/**
 * @brief Decode a pid message into a struct
 *
 * @param msg The message to decode
 * @param pid C-struct to decode the message contents into
 */
static inline void mavlink_msg_pid_decode(const mavlink_message_t* msg, mavlink_pid_t* pid)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    pid->number = mavlink_msg_pid_get_number(msg);
    pid->PID_P = mavlink_msg_pid_get_PID_P(msg);
    pid->PID_I = mavlink_msg_pid_get_PID_I(msg);
    pid->PID_D = mavlink_msg_pid_get_PID_D(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_PID_LEN? msg->len : MAVLINK_MSG_ID_PID_LEN;
        memset(pid, 0, MAVLINK_MSG_ID_PID_LEN);
    memcpy(pid, _MAV_PAYLOAD(msg), len);
#endif
}
