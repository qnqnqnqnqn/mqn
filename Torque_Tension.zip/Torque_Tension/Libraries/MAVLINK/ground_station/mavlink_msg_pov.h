#pragma once
// MESSAGE pov PACKING

#define MAVLINK_MSG_ID_pov 222

MAVPACKED(
typedef struct __mavlink_pov_t {
 int32_t num; /*< block num
					num == 1		_shape
						param1	(shape)
						param2	(state)
					
					num == 2		_text
						param1	(text)
						param2	(state)

					num == 3		_duartion
						param1	(duartion)

					num == 4		_while
						param1	(count)
						param2	(size)

					num == 5		_function
						param1	(_function)
						param2	(size)
					
					num == 6		_invoke
						param1	(_function)
			*/
 int32_t param1; /*< param1*/
 int32_t param2; /*< param2*/
}) mavlink_pov_t;

#define MAVLINK_MSG_ID_pov_LEN 12
#define MAVLINK_MSG_ID_pov_MIN_LEN 12
#define MAVLINK_MSG_ID_222_LEN 12
#define MAVLINK_MSG_ID_222_MIN_LEN 12

#define MAVLINK_MSG_ID_pov_CRC 130
#define MAVLINK_MSG_ID_222_CRC 130



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_pov { \
    222, \
    "pov", \
    3, \
    {  { "num", NULL, MAVLINK_TYPE_INT32_T, 0, 0, offsetof(mavlink_pov_t, num) }, \
         { "param1", NULL, MAVLINK_TYPE_INT32_T, 0, 4, offsetof(mavlink_pov_t, param1) }, \
         { "param2", NULL, MAVLINK_TYPE_INT32_T, 0, 8, offsetof(mavlink_pov_t, param2) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_pov { \
    "pov", \
    3, \
    {  { "num", NULL, MAVLINK_TYPE_INT32_T, 0, 0, offsetof(mavlink_pov_t, num) }, \
         { "param1", NULL, MAVLINK_TYPE_INT32_T, 0, 4, offsetof(mavlink_pov_t, param1) }, \
         { "param2", NULL, MAVLINK_TYPE_INT32_T, 0, 8, offsetof(mavlink_pov_t, param2) }, \
         } \
}
#endif

/**
 * @brief Pack a pov message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param num block num
					num == 1		_shape
						param1	(shape)
						param2	(state)
					
					num == 2		_text
						param1	(text)
						param2	(state)

					num == 3		_duartion
						param1	(duartion)

					num == 4		_while
						param1	(count)
						param2	(size)

					num == 5		_function
						param1	(_function)
						param2	(size)
					
					num == 6		_invoke
						param1	(_function)
			
 * @param param1 param1
 * @param param2 param2
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_pov_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               int32_t num, int32_t param1, int32_t param2)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_pov_LEN];
    _mav_put_int32_t(buf, 0, num);
    _mav_put_int32_t(buf, 4, param1);
    _mav_put_int32_t(buf, 8, param2);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_pov_LEN);
#else
    mavlink_pov_t packet;
    packet.num = num;
    packet.param1 = param1;
    packet.param2 = param2;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_pov_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_pov;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_pov_MIN_LEN, MAVLINK_MSG_ID_pov_LEN, MAVLINK_MSG_ID_pov_CRC);
}

/**
 * @brief Pack a pov message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param num block num
					num == 1		_shape
						param1	(shape)
						param2	(state)
					
					num == 2		_text
						param1	(text)
						param2	(state)

					num == 3		_duartion
						param1	(duartion)

					num == 4		_while
						param1	(count)
						param2	(size)

					num == 5		_function
						param1	(_function)
						param2	(size)
					
					num == 6		_invoke
						param1	(_function)
			
 * @param param1 param1
 * @param param2 param2
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_pov_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   int32_t num,int32_t param1,int32_t param2)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_pov_LEN];
    _mav_put_int32_t(buf, 0, num);
    _mav_put_int32_t(buf, 4, param1);
    _mav_put_int32_t(buf, 8, param2);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_pov_LEN);
#else
    mavlink_pov_t packet;
    packet.num = num;
    packet.param1 = param1;
    packet.param2 = param2;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_pov_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_pov;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_pov_MIN_LEN, MAVLINK_MSG_ID_pov_LEN, MAVLINK_MSG_ID_pov_CRC);
}

/**
 * @brief Encode a pov struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param pov C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_pov_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_pov_t* pov)
{
    return mavlink_msg_pov_pack(system_id, component_id, msg, pov->num, pov->param1, pov->param2);
}

/**
 * @brief Encode a pov struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param pov C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_pov_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_pov_t* pov)
{
    return mavlink_msg_pov_pack_chan(system_id, component_id, chan, msg, pov->num, pov->param1, pov->param2);
}

/**
 * @brief Send a pov message
 * @param chan MAVLink channel to send the message
 *
 * @param num block num
					num == 1		_shape
						param1	(shape)
						param2	(state)
					
					num == 2		_text
						param1	(text)
						param2	(state)

					num == 3		_duartion
						param1	(duartion)

					num == 4		_while
						param1	(count)
						param2	(size)

					num == 5		_function
						param1	(_function)
						param2	(size)
					
					num == 6		_invoke
						param1	(_function)
			
 * @param param1 param1
 * @param param2 param2
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_pov_send(mavlink_channel_t chan, int32_t num, int32_t param1, int32_t param2)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_pov_LEN];
    _mav_put_int32_t(buf, 0, num);
    _mav_put_int32_t(buf, 4, param1);
    _mav_put_int32_t(buf, 8, param2);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_pov, buf, MAVLINK_MSG_ID_pov_MIN_LEN, MAVLINK_MSG_ID_pov_LEN, MAVLINK_MSG_ID_pov_CRC);
#else
    mavlink_pov_t packet;
    packet.num = num;
    packet.param1 = param1;
    packet.param2 = param2;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_pov, (const char *)&packet, MAVLINK_MSG_ID_pov_MIN_LEN, MAVLINK_MSG_ID_pov_LEN, MAVLINK_MSG_ID_pov_CRC);
#endif
}

/**
 * @brief Send a pov message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_pov_send_struct(mavlink_channel_t chan, const mavlink_pov_t* pov)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_pov_send(chan, pov->num, pov->param1, pov->param2);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_pov, (const char *)pov, MAVLINK_MSG_ID_pov_MIN_LEN, MAVLINK_MSG_ID_pov_LEN, MAVLINK_MSG_ID_pov_CRC);
#endif
}

#if MAVLINK_MSG_ID_pov_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_pov_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  int32_t num, int32_t param1, int32_t param2)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_int32_t(buf, 0, num);
    _mav_put_int32_t(buf, 4, param1);
    _mav_put_int32_t(buf, 8, param2);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_pov, buf, MAVLINK_MSG_ID_pov_MIN_LEN, MAVLINK_MSG_ID_pov_LEN, MAVLINK_MSG_ID_pov_CRC);
#else
    mavlink_pov_t *packet = (mavlink_pov_t *)msgbuf;
    packet->num = num;
    packet->param1 = param1;
    packet->param2 = param2;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_pov, (const char *)packet, MAVLINK_MSG_ID_pov_MIN_LEN, MAVLINK_MSG_ID_pov_LEN, MAVLINK_MSG_ID_pov_CRC);
#endif
}
#endif

#endif

// MESSAGE pov UNPACKING


/**
 * @brief Get field num from pov message
 *
 * @return block num
					num == 1		_shape
						param1	(shape)
						param2	(state)
					
					num == 2		_text
						param1	(text)
						param2	(state)

					num == 3		_duartion
						param1	(duartion)

					num == 4		_while
						param1	(count)
						param2	(size)

					num == 5		_function
						param1	(_function)
						param2	(size)
					
					num == 6		_invoke
						param1	(_function)
			
 */
static inline int32_t mavlink_msg_pov_get_num(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  0);
}

/**
 * @brief Get field param1 from pov message
 *
 * @return param1
 */
static inline int32_t mavlink_msg_pov_get_param1(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  4);
}

/**
 * @brief Get field param2 from pov message
 *
 * @return param2
 */
static inline int32_t mavlink_msg_pov_get_param2(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  8);
}

/**
 * @brief Decode a pov message into a struct
 *
 * @param msg The message to decode
 * @param pov C-struct to decode the message contents into
 */
static inline void mavlink_msg_pov_decode(const mavlink_message_t* msg, mavlink_pov_t* pov)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    pov->num = mavlink_msg_pov_get_num(msg);
    pov->param1 = mavlink_msg_pov_get_param1(msg);
    pov->param2 = mavlink_msg_pov_get_param2(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_pov_LEN? msg->len : MAVLINK_MSG_ID_pov_LEN;
        memset(pov, 0, MAVLINK_MSG_ID_pov_LEN);
    memcpy(pov, _MAV_PAYLOAD(msg), len);
#endif
}
